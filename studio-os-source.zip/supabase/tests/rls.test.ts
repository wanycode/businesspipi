/**
 * Vérifie le schéma, les contraintes et les policies RLS sur un vrai PostgreSQL
 * (PGlite / WASM). Usage : npm run test:db
 */
import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

process.on("uncaughtException", (error) => {
  console.error("\n✗ Erreur inattendue :", (error as Error).message);
  process.exit(1);
});
process.on("unhandledRejection", (error) => {
  console.error("\n✗ Erreur inattendue :", (error as Error)?.message ?? error);
  process.exit(1);
});

const here = dirname(fileURLToPath(import.meta.url));
const migrations = join(here, "..", "migrations");

let passed = 0;
const failures: string[] = [];

function assert(label: string, condition: boolean, detail = "") {
  if (condition) {
    passed += 1;
    console.log(`  ✓ ${label}`);
  } else {
    failures.push(`${label}${detail ? ` — ${detail}` : ""}`);
    console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ""}`);
  }
}

async function expectRejects(label: string, fn: () => Promise<unknown>) {
  try {
    await fn();
    assert(label, false, "l'opération aurait dû être refusée");
  } catch {
    assert(label, true);
  }
}

/** RLS filtre silencieusement : on attend 0 ligne touchée. */
async function expectNoRows(label: string, sql: string, params: unknown[] = []) {
  try {
    const r = await db.query(sql, params as never[]);
    assert(label, r.rows.length === 0, `${r.rows.length} ligne(s) accessible(s)`);
  } catch {
    assert(label, true);
  }
}
async function expectRows(label: string, sql: string, expected: number, params: unknown[] = []) {
  const r = await db.query(sql, params as never[]);
  assert(label, r.rows.length === expected, `${r.rows.length} ligne(s)`);
}

const db = new PGlite();

// --- Stub du schéma auth de Supabase ---------------------------------------
await db.exec(`
  create schema if not exists auth;
  create table auth.users (
    id uuid primary key,
    email text unique,
    raw_user_meta_data jsonb default '{}'::jsonb
  );
  create or replace function auth.uid() returns uuid
  language sql stable
  as $$
    select nullif(current_setting('request.jwt.claims', true)::jsonb ->> 'sub', '')::uuid;
  $$;
  create or replace function auth.role() returns text
  language sql stable
  as $$
    select nullif(current_setting('request.jwt.claims', true)::jsonb ->> 'role', '');
  $$;
  do $$ begin
    if not exists (select 1 from pg_roles where rolname = 'authenticated') then
      create role authenticated nologin;
    end if;
    if not exists (select 1 from pg_roles where rolname = 'anon') then
      create role anon nologin;
    end if;
  end $$;
  grant usage on schema auth to authenticated, anon;
  grant select on auth.users to authenticated;
`);

for (const file of ["0001_init.sql", "0002_message_templates.sql"]) {
  const sql = readFileSync(join(migrations, file), "utf8");
  try {
    await db.exec(sql);
    console.log(`\nMigration appliquée : ${file}`);
  } catch (error) {
    console.error(`\n✗ Échec de la migration ${file}\n`, error);
    process.exit(1);
  }
}

// --- Utilisateurs -----------------------------------------------------------
const ADMIN = "11111111-1111-4111-8111-111111111111";
const ALICE = "22222222-2222-4222-8222-222222222222";
const BOB = "33333333-3333-4333-8333-333333333333";

await db.query(`insert into auth.users (id, email) values ($1, $2)`, [ADMIN, "boss@studio.test"]);
await db.query(`insert into auth.users (id, email) values ($1, $2)`, [ALICE, "alice@studio.test"]);
await db.query(`insert into auth.users (id, email) values ($1, $2)`, [BOB, "bob@studio.test"]);

async function actAs(id: string | null, role: "authenticated" | "anon" | "postgres" = "authenticated") {
  await db.exec(`reset role;`);
  await db.query(`select set_config('request.jwt.claims', $1, false)`, [
    JSON.stringify(id ? { sub: id, role } : { role }),
  ]);
  await db.exec(`set role ${role};`);
}

console.log("\nProfil & rôles");
const adminProfile = await db.query<{ role: string; is_active: boolean }>(
  `select role, is_active from public.profiles where id = $1`,
  [ADMIN],
);
assert("le premier compte devient admin actif", adminProfile.rows[0]?.role === "admin" && adminProfile.rows[0]?.is_active === true);

const aliceProfile = await db.query<{ role: string; is_active: boolean }>(
  `select role, is_active from public.profiles where id = $1`,
  [ALICE],
);
assert("le deuxième compte est membre inactif", aliceProfile.rows[0]?.role === "member" && aliceProfile.rows[0]?.is_active === false);

const settings = await db.query<{ n: number }>(`select count(*)::int as n from public.team_settings`);
assert("team_settings est créé pour chaque profil", settings.rows[0]?.n === 3);

// --- Invitation -------------------------------------------------------------
console.log("\nInvitation");
await actAs(ADMIN);
const invite = await db.query<{ token: string }>(
  `insert into public.team_invites (email, role, daily_dm_target, created_by)
   values ('alice@studio.test', 'member', 45, $1) returning token`,
  [ADMIN],
);
const token = invite.rows[0]!.token;

await actAs(ALICE);
await expectNoRows("un membre ne peut pas lire les invitations", `select id from public.team_invites`);

await db.query(`select public.claim_invite($1)`, [token]);
await actAs(ADMIN);
const afterClaim = await db.query<{ is_active: boolean; target: number }>(
  `select p.is_active, t.daily_dm_target as target
     from public.profiles p join public.team_settings t on t.user_id = p.id
    where p.id = $1`,
  [ALICE],
);
assert("l'invitation active le membre et applique l'objectif", afterClaim.rows[0]?.is_active === true && afterClaim.rows[0]?.target === 45);

await actAs(BOB);
await expectRejects("un token ne peut pas être utilisé par un autre email", async () => {
  await db.query(`select public.claim_invite($1)`, [token]);
});

await actAs(ADMIN);
await db.query(`update public.profiles set is_active = true where id = $1`, [BOB]);

// --- Activités --------------------------------------------------------------
console.log("\nActivités quotidiennes");
await actAs(ALICE);
await db.query(
  `insert into public.daily_activities (user_id, activity_date, dms_sent, replies_received, interested_prospects, followups_sent, meetings_booked)
   values ($1, current_date, 40, 8, 3, 5, 1)`,
  [ALICE],
);
await expectRejects("contrainte unique (user_id, activity_date)", async () => {
  await db.query(
    `insert into public.daily_activities (user_id, activity_date, dms_sent) values ($1, current_date, 1)`,
    [ALICE],
  );
});
await expectRejects("les nombres négatifs sont refusés", async () => {
  await db.query(
    `insert into public.daily_activities (user_id, activity_date, dms_sent) values ($1, current_date - 5, -3)`,
    [ALICE],
  );
});
await expectRejects("impossible de saisir une activité pour un autre membre", async () => {
  await db.query(
    `insert into public.daily_activities (user_id, activity_date, dms_sent) values ($1, current_date - 2, 10)`,
    [BOB],
  );
});

await actAs(BOB);
await db.query(
  `insert into public.daily_activities (user_id, activity_date, dms_sent) values ($1, current_date, 12)`,
  [BOB],
);

await actAs(ALICE);
const ownActivities = await db.query<{ user_id: string }>(`select user_id from public.daily_activities`);
assert("un membre ne voit que ses propres activités", ownActivities.rows.length === 1 && ownActivities.rows[0]?.user_id === ALICE);

const updateOthers = await db.query(`update public.daily_activities set dms_sent = 9999 where user_id = $1 returning id`, [BOB]);
assert("un membre ne peut pas modifier les activités d'un autre", updateOthers.rows.length === 0);

const deleteOwn = await db.query(`delete from public.daily_activities where user_id = $1 returning id`, [ALICE]);
assert("un membre ne peut pas supprimer son historique", deleteOwn.rows.length === 0);

await actAs(ADMIN);
const allActivities = await db.query(`select id from public.daily_activities`);
assert("l'admin voit toutes les activités", allActivities.rows.length === 2);

// --- Escalade de privilèges -------------------------------------------------
console.log("\nEscalade de privilèges");
await actAs(ALICE);
await db.query(`update public.profiles set role = 'admin', is_active = true where id = $1`, [ALICE]);
const attempted = await db.query<{ role: string }>(`select role from public.profiles where id = $1`, [ALICE]);
assert("un membre ne peut pas se promouvoir admin", attempted.rows[0]?.role === "member");

// --- Prospects --------------------------------------------------------------
console.log("\nProspects & CRM");
await actAs(ALICE);
await db.query(
  `insert into public.prospects (name, instagram_username, assigned_user_id, status, estimated_value)
   values ('Coach Karim', 'coach.karim', $1, 'contacted', 59.99)`,
  [ALICE],
);
await expectRejects("doublon d'identifiant Instagram refusé", async () => {
  await db.query(
    `insert into public.prospects (name, instagram_username, assigned_user_id) values ('Autre', 'Coach.Karim', $1)`,
    [ALICE],
  );
});
await expectRejects("un membre ne peut pas créer un prospect pour un autre", async () => {
  await db.query(
    `insert into public.prospects (name, instagram_username, assigned_user_id) values ('Test', 'autre.prospect', $1)`,
    [BOB],
  );
});
await expectRejects("statut inconnu refusé", async () => {
  await db.query(
    `insert into public.prospects (name, instagram_username, assigned_user_id, status) values ('Test2', 'test.two', $1, 'pas_un_statut')`,
    [ALICE],
  );
});

await actAs(BOB);
const bobProspects = await db.query(`select id from public.prospects`);
assert("un membre ne voit pas les prospects des autres", bobProspects.rows.length === 0);

await actAs(ADMIN);
const adminProspects = await db.query<{ id: string }>(`select id from public.prospects`);
assert("l'admin voit tous les prospects", adminProspects.rows.length === 1);

// --- Interactions -----------------------------------------------------------
console.log("\nInteractions");
const prospectId = adminProspects.rows[0]!.id;
await actAs(ALICE);
await db.query(
  `insert into public.prospect_interactions (prospect_id, user_id, interaction_type, notes)
   values ($1, $2, 'dm', 'Premier message envoyé')`,
  [prospectId, ALICE],
);
await actAs(BOB);
const bobInteractions = await db.query(`select id from public.prospect_interactions`);
assert("un membre ne voit pas les interactions des autres prospects", bobInteractions.rows.length === 0);

// --- Deals ------------------------------------------------------------------
console.log("\nVentes");
await actAs(ALICE);
await db.query(
  `insert into public.deals (prospect_id, client_name, assigned_user_id, package, deal_amount, deal_status, payment_status, amount_paid, won_at)
   values ($1, 'Karim', $2, 'PRO', 59.99, 'won', 'paid', 59.99, current_date)`,
  [prospectId, ALICE],
);
await expectRejects("un deal payé ne peut pas être incohérent", async () => {
  await db.query(
    `insert into public.deals (client_name, assigned_user_id, package, deal_amount, deal_status, payment_status, amount_paid, won_at)
     values ('X', $1, 'START', 29.99, 'won', 'paid', 5, current_date)`,
    [ALICE],
  );
});
await expectRejects("un deal gagné doit avoir une date", async () => {
  await db.query(
    `insert into public.deals (client_name, assigned_user_id, package, deal_amount, deal_status)
     values ('Y', $1, 'START', 29.99, 'won')`,
    [ALICE],
  );
});

await actAs(BOB);
const bobDeals = await db.query(`select id from public.deals`);
assert("un membre ne voit pas les ventes des autres", bobDeals.rows.length === 0);

// --- Messages ---------------------------------------------------------------
console.log("\nBibliothèque de messages");
const messages = await db.query<{ language_code: string; message_content: string }>(
  `select language_code, message_content from public.message_templates order by sort_order`,
);
assert("10 langues sont disponibles", messages.rows.length === 10, `${messages.rows.length} trouvées`);
assert(
  "chaque message contient les 3 prix et le lien portfolio",
  messages.rows.every((m) => ["€29.99", "€59.99", "€99.99", "€9.99", "https://urlr.me/39XCEx"].every((s) => m.message_content.includes(s))),
);
assert("aucune traduction placeholder", messages.rows.every((m) => !/translation goes here|traduction/i.test(m.message_content)));

await actAs(ALICE);
await expectNoRows(
  "un membre ne peut pas modifier un message",
  `update public.message_templates set message_content = message_content || ' hack' returning id`,
);
await actAs(ADMIN);
const adminEdit = await db.query(`update public.message_templates set message_content = message_content || ' ' where language_code = 'fr' returning id`);
assert("l'admin peut modifier un message", adminEdit.rows.length === 1);

// --- Anon -------------------------------------------------------------------
console.log("\nAccès anonyme");
await db.exec(`reset role;`);
await db.query(`select set_config('request.jwt.claims', $1, false)`, [JSON.stringify({ role: "anon" })]);
await db.exec(`set role anon;`);
await expectRejects("anon ne peut rien lire", async () => {
  await db.query(`select * from public.profiles`);
});

await db.exec(`reset role;`);

console.log(`\n${passed} vérifications passées, ${failures.length} échec(s).`);
if (failures.length > 0) {
  console.error("\nÉchecs:");
  for (const f of failures) console.error(` - ${f}`);
  process.exit(1);
}
