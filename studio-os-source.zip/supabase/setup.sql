-- Studio OS — installation complète (0001 + 0002).
-- Colle TOUT ce fichier dans Supabase → SQL Editor → Run.

-- ============================================================================
-- Studio OS — 0001_init.sql
-- Schéma complet, contraintes, triggers et Row Level Security (Supabase).
-- À exécuter dans le SQL Editor de Supabase, puis 0002_message_templates.sql.
-- ============================================================================

-- gen_random_uuid() est natif depuis PostgreSQL 13 (aucune extension requise).

-- ---------------------------------------------------------------------------
-- profiles
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  display_name text not null check (char_length(trim(display_name)) between 1 and 80),
  email        text not null,
  role         text not null default 'member' check (role in ('admin', 'member')),
  is_active    boolean not null default true,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create unique index if not exists profiles_email_key on public.profiles (lower(email));

-- ---------------------------------------------------------------------------
-- Helpers (SECURITY DEFINER pour éviter la récursion des policies sur profiles)
-- ---------------------------------------------------------------------------
create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select p.is_active from public.profiles p where p.id = auth.uid()),
    false
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select p.role = 'admin' and p.is_active
       from public.profiles p
      where p.id = auth.uid()),
    false
  );
$$;

-- ---------------------------------------------------------------------------
-- team_settings (objectif quotidien de DM)
-- ---------------------------------------------------------------------------
create table if not exists public.team_settings (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null unique references public.profiles (id) on delete cascade,
  daily_dm_target integer not null default 30 check (daily_dm_target between 0 and 5000),
  commission_rate numeric(5, 2) not null default 20 check (commission_rate between 0 and 100),
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- team_invites
-- ---------------------------------------------------------------------------
create table if not exists public.team_invites (
  id              uuid primary key default gen_random_uuid(),
  email           text not null,
  role            text not null default 'member' check (role in ('admin', 'member')),
  daily_dm_target integer not null default 30 check (daily_dm_target between 0 and 5000),
  token           uuid not null unique default gen_random_uuid(),
  created_by      uuid references public.profiles (id) on delete set null,
  expires_at      timestamptz not null default (now() + interval '14 days'),
  accepted_at     timestamptz,
  accepted_by     uuid references public.profiles (id) on delete set null,
  created_at      timestamptz not null default now()
);

create index if not exists team_invites_email_idx on public.team_invites (lower(email));

-- ---------------------------------------------------------------------------
-- daily_activities
-- ---------------------------------------------------------------------------
create table if not exists public.daily_activities (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references public.profiles (id) on delete cascade,
  activity_date       date not null default current_date,
  dms_sent            integer not null default 0 check (dms_sent >= 0),
  replies_received    integer not null default 0 check (replies_received >= 0),
  interested_prospects integer not null default 0 check (interested_prospects >= 0),
  followups_sent      integer not null default 0 check (followups_sent >= 0),
  meetings_booked     integer not null default 0 check (meetings_booked >= 0),
  sales_closed        integer not null default 0 check (sales_closed >= 0),
  notes               text,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  constraint daily_activities_user_date_key unique (user_id, activity_date),
  constraint daily_activities_no_future check (activity_date <= current_date + 1),
  constraint daily_activities_not_ancient check (activity_date >= date '2020-01-01'),
  constraint daily_activities_coherent check (
    replies_received <= dms_sent + followups_sent
    and interested_prospects <= replies_received
  )
);

create index if not exists daily_activities_date_idx on public.daily_activities (activity_date desc);
create index if not exists daily_activities_user_date_idx on public.daily_activities (user_id, activity_date desc);

-- ---------------------------------------------------------------------------
-- prospects
-- ---------------------------------------------------------------------------
create table if not exists public.prospects (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null check (char_length(trim(name)) between 1 and 120),
  instagram_username  text not null check (char_length(trim(instagram_username)) between 1 and 60),
  instagram_url       text,
  country             text,
  language            text default 'en',
  niche               text,
  assigned_user_id    uuid not null references public.profiles (id) on delete restrict,
  status              text not null default 'to_contact' check (status in (
                        'to_contact', 'contacted', 'followup', 'replied',
                        'interested', 'negotiating', 'won', 'lost'
                      )),
  first_contacted_at  date,
  last_contacted_at   date,
  next_followup_at    date,
  estimated_value     numeric(10, 2) check (estimated_value >= 0),
  notes               text,
  archived_at         timestamptz,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

create unique index if not exists prospects_instagram_unique
  on public.prospects (lower(instagram_username))
  where archived_at is null;
create index if not exists prospects_assignee_idx on public.prospects (assigned_user_id);
create index if not exists prospects_status_idx on public.prospects (status);
create index if not exists prospects_followup_idx on public.prospects (next_followup_at nulls last);

-- ---------------------------------------------------------------------------
-- prospect_interactions
-- ---------------------------------------------------------------------------
create table if not exists public.prospect_interactions (
  id               uuid primary key default gen_random_uuid(),
  prospect_id      uuid not null references public.prospects (id) on delete cascade,
  user_id          uuid not null references public.profiles (id) on delete cascade,
  interaction_type text not null default 'dm' check (interaction_type in (
                     'dm', 'reply', 'followup', 'call', 'meeting', 'note', 'sale'
                   )),
  notes            text,
  interaction_date timestamptz not null default now(),
  created_at       timestamptz not null default now()
);

create index if not exists prospect_interactions_prospect_idx
  on public.prospect_interactions (prospect_id, interaction_date desc);

-- ---------------------------------------------------------------------------
-- package pricing + studio settings
-- ---------------------------------------------------------------------------
create table if not exists public.package_pricing (
  code       text primary key check (code in ('START', 'PRO', 'PREMIUM')),
  label      text not null,
  price      numeric(10, 2) not null check (price >= 0),
  sort_order integer not null default 0,
  updated_at timestamptz not null default now()
);

insert into public.package_pricing (code, label, price, sort_order) values
  ('START', 'START', 29.99, 1),
  ('PRO', 'PRO', 59.99, 2),
  ('PREMIUM', 'PREMIUM', 99.99, 3)
on conflict (code) do nothing;

create table if not exists public.studio_settings (
  id                boolean primary key default true check (id),
  studio_name       text not null default 'Studio',
  currency          text not null default 'EUR',
  maintenance_price numeric(10, 2) not null default 9.99 check (maintenance_price >= 0),
  portfolio_url     text not null default 'https://urlr.me/39XCEx',
  updated_at        timestamptz not null default now()
);

insert into public.studio_settings (id) values (true) on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- deals
-- ---------------------------------------------------------------------------
create table if not exists public.deals (
  id                uuid primary key default gen_random_uuid(),
  prospect_id       uuid references public.prospects (id) on delete set null,
  client_name       text not null check (char_length(trim(client_name)) between 1 and 120),
  assigned_user_id  uuid not null references public.profiles (id) on delete restrict,
  package           text not null check (package in ('START', 'PRO', 'PREMIUM')),
  deal_amount       numeric(10, 2) not null check (deal_amount >= 0),
  deal_status       text not null default 'proposed' check (deal_status in (
                      'proposed', 'won', 'lost'
                    )),
  payment_status    text not null default 'unpaid' check (payment_status in (
                      'unpaid', 'partial', 'paid'
                    )),
  amount_paid       numeric(10, 2) not null default 0 check (amount_paid >= 0),
  maintenance_active boolean not null default false,
  won_at            date,
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint deals_paid_lte_amount check (amount_paid <= deal_amount),
  constraint deals_won_at_required check (deal_status <> 'won' or won_at is not null),
  constraint deals_payment_coherent check (
    (payment_status = 'paid' and amount_paid = deal_amount)
    or (payment_status = 'partial' and amount_paid > 0 and amount_paid < deal_amount)
    or (payment_status = 'unpaid' and amount_paid = 0)
    or (deal_status <> 'won')
  )
);

create index if not exists deals_assignee_idx on public.deals (assigned_user_id);
create index if not exists deals_won_idx on public.deals (won_at desc);

-- ---------------------------------------------------------------------------
-- message_templates
-- ---------------------------------------------------------------------------
create table if not exists public.message_templates (
  id              uuid primary key default gen_random_uuid(),
  language_code   text not null unique check (char_length(language_code) between 2 and 10),
  language_name   text not null,
  message_content text not null check (char_length(message_content) > 20),
  default_content text,
  is_default      boolean not null default true,
  sort_order      integer not null default 0,
  is_rtl          boolean not null default false,
  updated_at      timestamptz not null default now(),
  updated_by      uuid references public.profiles (id) on delete set null
);

-- Conserve la version d'origine pour l'action « Rétablir l'original ».
create or replace function public.set_message_default_content()
returns trigger
language plpgsql
as $$
begin
  if new.default_content is null then
    new.default_content := new.message_content;
  end if;
  return new;
end;
$$;

drop trigger if exists message_default_content on public.message_templates;
create trigger message_default_content
  before insert on public.message_templates
  for each row execute function public.set_message_default_content();

-- ---------------------------------------------------------------------------
-- updated_at
-- ---------------------------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array[
    'profiles', 'team_settings', 'daily_activities', 'prospects',
    'package_pricing', 'studio_settings', 'deals'
  ] loop
    execute format('drop trigger if exists %I_touch on public.%I', t, t);
    execute format(
      'create trigger %I_touch before update on public.%I
         for each row execute function public.touch_updated_at()', t, t
    );
  end loop;
end;
$$;

-- ---------------------------------------------------------------------------
-- Nouvel utilisateur → profil. Le 1er compte devient admin actif,
-- les suivants sont membres inactifs jusqu'à acceptation d'une invitation.
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  is_first boolean;
  new_role text;
begin
  select not exists (select 1 from public.profiles) into is_first;
  new_role := case when is_first then 'admin' else 'member' end;

  insert into public.profiles (id, email, display_name, role, is_active)
  values (
    new.id,
    coalesce(new.email, ''),
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), split_part(coalesce(new.email, 'membre'), '@', 1)),
    new_role,
    is_first
  )
  on conflict (id) do nothing;

  insert into public.team_settings (user_id, daily_dm_target, is_active)
  values (new.id, 30, is_first)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Garde-fou : un membre ne peut pas changer son rôle, son activation ni son email.
-- Fonction volontairement en SECURITY INVOKER : `current_user` vaut alors le rôle
-- réel du client (`authenticated`) et non le propriétaire de la fonction, sinon
-- le garde-fou ne s'appliquerait jamais. Les fonctions SECURITY DEFINER
-- (claim_invite) s'exécutent en `postgres` et passent donc leur tour.
create or replace function public.protect_profile_columns()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if current_user in ('authenticated', 'anon') and not public.is_admin() then
    new.role := old.role;
    new.is_active := old.is_active;
    new.email := old.email;
  end if;
  new.id := old.id;
  return new;
end;
$$;

drop trigger if exists profiles_protect on public.profiles;
create trigger profiles_protect
  before update on public.profiles
  for each row execute function public.protect_profile_columns();

-- Miroir is_active vers team_settings.
create or replace function public.sync_team_settings_active()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.team_settings
     set is_active = new.is_active
   where user_id = new.id and is_active is distinct from new.is_active;
  return new;
end;
$$;

drop trigger if exists profiles_sync_active on public.profiles;
create trigger profiles_sync_active
  after update of is_active on public.profiles
  for each row execute function public.sync_team_settings_active();

-- ---------------------------------------------------------------------------
-- Interactions : confort (prospect accessible ?)
-- ---------------------------------------------------------------------------
create or replace function public.can_access_prospect(p_prospect_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
      from public.prospects p
     where p.id = p_prospect_id
       and (p.assigned_user_id = auth.uid() or public.is_admin())
  );
$$;

-- ---------------------------------------------------------------------------
-- Acceptation d'une invitation (l'admin ne peut pas créer de mot de passe)
-- ---------------------------------------------------------------------------
create or replace function public.claim_invite(p_token uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_email text;
  inv public.team_invites;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED' using errcode = '42501';
  end if;

  select email into caller_email from auth.users where id = auth.uid();

  select * into inv
    from public.team_invites
   where token = p_token
     and accepted_at is null
     and expires_at > now()
     and lower(email) = lower(coalesce(caller_email, ''))
   for update;

  if inv.id is null then
    raise exception 'INVALID_INVITE' using errcode = '22023';
  end if;

  update public.profiles
     set role = inv.role,
         is_active = true,
         display_name = coalesce(nullif(trim(display_name), ''), split_part(inv.email, '@', 1))
   where id = auth.uid();

  update public.team_settings
     set daily_dm_target = inv.daily_dm_target,
         is_active = true
   where user_id = auth.uid();

  update public.team_invites
     set accepted_at = now(), accepted_by = auth.uid()
   where id = inv.id;

  return jsonb_build_object('ok', true, 'role', inv.role);
end;
$$;

revoke all on function public.claim_invite(uuid) from public;
grant execute on function public.claim_invite(uuid) to authenticated;

-- ---------------------------------------------------------------------------
-- ROW LEVEL SECURITY
-- ---------------------------------------------------------------------------
alter table public.profiles            enable row level security;
alter table public.team_settings       enable row level security;
alter table public.team_invites        enable row level security;
alter table public.daily_activities    enable row level security;
alter table public.prospects           enable row level security;
alter table public.prospect_interactions enable row level security;
alter table public.deals               enable row level security;
alter table public.message_templates   enable row level security;
alter table public.package_pricing     enable row level security;
alter table public.studio_settings     enable row level security;

-- profiles
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles
  for select to authenticated
  using (id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles
  for update to authenticated
  using (id = (select auth.uid()) or (select public.is_admin()))
  with check (id = (select auth.uid()) or (select public.is_admin()));

-- team_settings : lecture perso / admin, écriture admin
drop policy if exists team_settings_select on public.team_settings;
create policy team_settings_select on public.team_settings
  for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists team_settings_admin_write on public.team_settings;
create policy team_settings_admin_write on public.team_settings
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- team_invites : admin uniquement
drop policy if exists team_invites_admin on public.team_invites;
create policy team_invites_admin on public.team_invites
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- daily_activities
drop policy if exists activities_select on public.daily_activities;
create policy activities_select on public.daily_activities
  for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists activities_insert on public.daily_activities;
create policy activities_insert on public.daily_activities
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and (select public.is_active_user())
  );

drop policy if exists activities_update on public.daily_activities;
create policy activities_update on public.daily_activities
  for update to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()))
  with check (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists activities_delete on public.daily_activities;
create policy activities_delete on public.daily_activities
  for delete to authenticated
  using ((select public.is_admin()));

-- prospects
drop policy if exists prospects_select on public.prospects;
create policy prospects_select on public.prospects
  for select to authenticated
  using (assigned_user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists prospects_insert on public.prospects;
create policy prospects_insert on public.prospects
  for insert to authenticated
  with check (
    (assigned_user_id = (select auth.uid()) or (select public.is_admin()))
    and (select public.is_active_user())
  );

drop policy if exists prospects_update on public.prospects;
create policy prospects_update on public.prospects
  for update to authenticated
  using (assigned_user_id = (select auth.uid()) or (select public.is_admin()))
  with check (assigned_user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists prospects_delete on public.prospects;
create policy prospects_delete on public.prospects
  for delete to authenticated
  using ((select public.is_admin()));

-- prospect_interactions
drop policy if exists interactions_select on public.prospect_interactions;
create policy interactions_select on public.prospect_interactions
  for select to authenticated
  using (user_id = (select auth.uid()) or (select public.can_access_prospect(prospect_id)));

drop policy if exists interactions_insert on public.prospect_interactions;
create policy interactions_insert on public.prospect_interactions
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and (select public.can_access_prospect(prospect_id))
  );

drop policy if exists interactions_update on public.prospect_interactions;
create policy interactions_update on public.prospect_interactions
  for update to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()))
  with check (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists interactions_delete on public.prospect_interactions;
create policy interactions_delete on public.prospect_interactions
  for delete to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

-- deals
drop policy if exists deals_select on public.deals;
create policy deals_select on public.deals
  for select to authenticated
  using (assigned_user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists deals_insert on public.deals;
create policy deals_insert on public.deals
  for insert to authenticated
  with check (
    (assigned_user_id = (select auth.uid()) or (select public.is_admin()))
    and (select public.is_active_user())
  );

drop policy if exists deals_update on public.deals;
create policy deals_update on public.deals
  for update to authenticated
  using (assigned_user_id = (select auth.uid()) or (select public.is_admin()))
  with check (assigned_user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists deals_delete on public.deals;
create policy deals_delete on public.deals
  for delete to authenticated
  using ((select public.is_admin()));

-- message_templates : tous les membres actifs lisent, admin écrit
drop policy if exists messages_select on public.message_templates;
create policy messages_select on public.message_templates
  for select to authenticated
  using ((select public.is_active_user()) or (select public.is_admin()));

drop policy if exists messages_admin_write on public.message_templates;
create policy messages_admin_write on public.message_templates
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- tarifs & réglages studio
drop policy if exists pricing_select on public.package_pricing;
create policy pricing_select on public.package_pricing
  for select to authenticated using (true);

drop policy if exists pricing_admin_write on public.package_pricing;
create policy pricing_admin_write on public.package_pricing
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

drop policy if exists studio_settings_select on public.studio_settings;
create policy studio_settings_select on public.studio_settings
  for select to authenticated using (true);

drop policy if exists studio_settings_admin_write on public.studio_settings;
create policy studio_settings_admin_write on public.studio_settings
  for all to authenticated
  using ((select public.is_admin()))
  with check ((select public.is_admin()));

-- ---------------------------------------------------------------------------
-- Privilèges
-- ---------------------------------------------------------------------------
revoke all on all tables in schema public from anon;
grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;


-- ============================================================================
-- Studio OS — 0002_message_templates.sql
-- Bibliothèque de messages d'approche Instagram, 10 langues natives.
-- Le message anglais est la source. Les noms START / PRO / PREMIUM et les
-- prix restent identiques dans toutes les langues.
-- ============================================================================

insert into public.message_templates
  (language_code, language_name, message_content, is_default, sort_order, is_rtl)
values
  ('en', 'English', $msg$Hey! I came across your Instagram profile 👀

I build modern, custom websites for football coaches, personal trainers and other sports professionals, and I thought it might be something you'd be interested in.

I offer 3 packages:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Maintenance available if needed: €9.99/month

I'm 16 and building my own web studio alongside my studies, so I'm working on getting my name out there and growing my client base.

And if you know someone else who's looking for a website, I'll give you 50% off yours if you refer them to me 🤝

If you'd like to see some of my work, I've put a few examples here 👇🏽
https://urlr.me/39XCEx$msg$, true, 1, false),

  ('fr', 'Français', $msg$Salut ! Je suis tombé sur ton profil Instagram 👀

Je crée des sites web modernes et sur mesure pour des coachs de foot, des coachs sportifs et d'autres pros du sport, et je me suis dit que ça pourrait t'intéresser.

Je propose 3 formules :
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Maintenance possible si besoin : €9.99/mois

J'ai 16 ans et je développe mon propre studio web en parallèle de mes études, donc je travaille à me faire connaître et à développer ma clientèle.

Et si tu connais quelqu'un qui cherche un site, je t'offre 50 % de réduction sur le tien si tu me le recommandes 🤝

Si tu veux voir quelques-unes de mes réalisations, j'ai mis des exemples ici 👇🏽
https://urlr.me/39XCEx$msg$, true, 2, false),

  ('es', 'Español', $msg$¡Hola! Me topé con tu perfil de Instagram 👀

Creo páginas web modernas y personalizadas para entrenadores de fútbol, entrenadores personales y otros profesionales del deporte, y pensé que podría interesarte.

Ofrezco 3 paquetes:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Mantenimiento disponible si lo necesitas: €9.99/mes

Tengo 16 años y estoy montando mi propio estudio web mientras estudio, así que estoy trabajando en darme a conocer y en hacer crecer mi cartera de clientes.

Y si conoces a alguien que esté buscando una web, te hago un 50 % de descuento en la tuya si me lo recomiendas 🤝

Si quieres ver algunos de mis trabajos, dejé unos ejemplos aquí 👇🏽
https://urlr.me/39XCEx$msg$, true, 3, false),

  ('de', 'Deutsch', $msg$Hey! Ich bin auf dein Instagram-Profil gestoßen 👀

Ich baue moderne, individuelle Websites für Fußballtrainer, Personal Trainer und andere Sportprofis – und dachte, das könnte dich interessieren.

Ich biete 3 Pakete an:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Wartung auf Wunsch verfügbar: €9.99/Monat

Ich bin 16 und baue neben der Schule mein eigenes Webstudio auf, deshalb arbeite ich gerade daran, mich bekannt zu machen und meinen Kundenstamm aufzubauen.

Und wenn du jemanden kennst, der eine Website sucht: Wenn du mich weiterempfiehlst, bekommst du 50 % Rabatt auf deine 🤝

Wenn du ein paar meiner Arbeiten sehen willst, hier sind ein paar Beispiele 👇🏽
https://urlr.me/39XCEx$msg$, true, 4, false),

  ('it', 'Italiano', $msg$Ciao! Mi sono imbattuto nel tuo profilo Instagram 👀

Realizzo siti web moderni e su misura per allenatori di calcio, personal trainer e altri professionisti dello sport, e ho pensato che potesse interessarti.

Offro 3 pacchetti:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Manutenzione disponibile se serve: €9.99/mese

Ho 16 anni e sto costruendo il mio studio web mentre studio, quindi sto lavorando per farmi conoscere e ampliare la mia clientela.

E se conosci qualcuno che cerca un sito, ti faccio il 50% di sconto sul tuo se mi presenti 🤝

Se vuoi vedere alcuni dei miei lavori, ho messo qualche esempio qui 👇🏽
https://urlr.me/39XCEx$msg$, true, 5, false),

  ('pt', 'Português', $msg$Oi! Me deparei com o seu perfil no Instagram 👀

Eu crio sites modernos e personalizados para treinadores de futebol, personal trainers e outros profissionais do esporte, e achei que poderia te interessar.

Ofereço 3 pacotes:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Manutenção disponível se precisar: €9.99/mês

Tenho 16 anos e estou construindo meu próprio estúdio web junto com os estudos, então estou trabalhando para divulgar meu nome e crescer minha base de clientes.

E se você conhecer alguém procurando um site, te dou 50% de desconto no seu se me indicar 🤝

Se quiser ver alguns dos meus trabalhos, coloquei alguns exemplos aqui 👇🏽
https://urlr.me/39XCEx$msg$, true, 6, false),

  ('nl', 'Nederlands', $msg$Hoi! Ik kwam je Instagram-profiel tegen 👀

Ik bouw moderne, op maat gemaakte websites voor voetbaltrainers, personal trainers en andere sportprofessionals, en ik dacht dat dit misschien iets voor jou is.

Ik bied 3 pakketten aan:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Onderhoud beschikbaar indien nodig: €9.99/maand

Ik ben 16 en bouw naast mijn studie mijn eigen webstudio op, dus ik ben bezig om mijn naam bekend te maken en mijn klantenbestand te laten groeien.

En ken je iemand die een website zoekt? Dan krijg je 50% korting op die van jou als je me doorverwijst 🤝

Als je wat van mijn werk wilt zien, heb ik hier een paar voorbeelden gezet 👇🏽
https://urlr.me/39XCEx$msg$, true, 7, false),

  ('ar', 'العربية', $msg$مرحباً! صادفت ملفك على إنستغرام 👀

أصمم مواقع إلكترونية حديثة ومخصصة لمدربي كرة القدم والمدربين الشخصيين وغيرهم من محترفي الرياضة، وفكرت أن هذا قد يهمك.

أقدم 3 باقات:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

الصيانة متوفرة عند الحاجة: €9.99 شهرياً

عمري 16 عاماً وأبني استوديو الويب الخاص بي إلى جانب دراستي، لذلك أعمل على التعريف باسمي وتوسيع قاعدة عملائي.

وإذا كنت تعرف شخصاً يبحث عن موقع، سأمنحك خصم 50% على موقعك إذا رشحتني له 🤝

إذا أردت رؤية بعض أعمالي، وضعت بعض الأمثلة هنا 👇🏽
https://urlr.me/39XCEx$msg$, true, 8, true),

  ('pl', 'Polski', $msg$Cześć! Trafiłem na Twój profil na Instagramie 👀

Tworzę nowoczesne, indywidualne strony internetowe dla trenerów piłki nożnej, trenerów personalnych i innych osób związanych ze sportem — pomyślałem, że może Cię to zainteresować.

Oferuję 3 pakiety:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Serwis dostępny w razie potrzeby: €9.99/miesiąc

Mam 16 lat i rozwijam własne studio webowe równolegle ze szkołą, więc staram się wypromować swoje nazwisko i powiększyć bazę klientów.

A jeśli znasz kogoś, kto szuka strony, dam Ci 50% zniżki na Twoją, jeśli mnie polecisz 🤝

Jeśli chcesz zobaczyć moje prace, kilka przykładów wrzuciłem tutaj 👇🏽
https://urlr.me/39XCEx$msg$, true, 9, false),

  ('tr', 'Türkçe', $msg$Selam! Instagram profiline denk geldim 👀

Futbol antrenörleri, kişisel antrenörler ve diğer spor profesyonelleri için modern, kişiye özel web siteleri tasarlıyorum ve bunun ilgini çekebileceğini düşündüm.

3 paket sunuyorum:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

İhtiyaç halinde bakım hizmeti: ayda €9.99

16 yaşındayım ve okulumun yanında kendi web stüdyomu kuruyorum, bu yüzden adımı duyurmaya ve müşteri kitlemi büyütmeye çalışıyorum.

Ve eğer site arayan birini tanıyorsan, beni önerirsen seninkinde %50 indirim yaparım 🤝

Çalışmalarımdan bazılarını görmek istersen buraya birkaç örnek koydum 👇🏽
https://urlr.me/39XCEx$msg$, true, 10, false)
on conflict (language_code) do nothing;
