-- ============================================================================
-- Studio OS — 0002_message_templates.sql
-- Bibliothèque de messages d'approche Instagram, 10 langues natives.
-- Le message anglais est la source. Les noms START / PRO / PREMIUM et les
-- prix restent identiques dans toutes les langues.
-- ============================================================================

insert into public.message_templates
  (language_code, language_name, message_content, is_default, sort_order, is_rtl)
values
  ('en', 'English', $msg$Hey! I came across your Instagram profile 👀

I build modern, custom websites for football coaches, personal trainers and other sports professionals, and I thought it might be something you'd be interested in.

I offer 3 packages:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Maintenance available if needed: €9.99/month

I'm 16 and building my own web studio alongside my studies, so I'm working on getting my name out there and growing my client base.

And if you know someone else who's looking for a website, I'll give you 50% off yours if you refer them to me 🤝

If you'd like to see some of my work, I've put a few examples here 👇🏽
https://urlr.me/39XCEx$msg$, true, 1, false),

  ('fr', 'Français', $msg$Salut ! Je suis tombé sur ton profil Instagram 👀

Je crée des sites web modernes et sur mesure pour des coachs de foot, des coachs sportifs et d'autres pros du sport, et je me suis dit que ça pourrait t'intéresser.

Je propose 3 formules :
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Maintenance possible si besoin : €9.99/mois

J'ai 16 ans et je développe mon propre studio web en parallèle de mes études, donc je travaille à me faire connaître et à développer ma clientèle.

Et si tu connais quelqu'un qui cherche un site, je t'offre 50 % de réduction sur le tien si tu me le recommandes 🤝

Si tu veux voir quelques-unes de mes réalisations, j'ai mis des exemples ici 👇🏽
https://urlr.me/39XCEx$msg$, true, 2, false),

  ('es', 'Español', $msg$¡Hola! Me topé con tu perfil de Instagram 👀

Creo páginas web modernas y personalizadas para entrenadores de fútbol, entrenadores personales y otros profesionales del deporte, y pensé que podría interesarte.

Ofrezco 3 paquetes:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Mantenimiento disponible si lo necesitas: €9.99/mes

Tengo 16 años y estoy montando mi propio estudio web mientras estudio, así que estoy trabajando en darme a conocer y en hacer crecer mi cartera de clientes.

Y si conoces a alguien que esté buscando una web, te hago un 50 % de descuento en la tuya si me lo recomiendas 🤝

Si quieres ver algunos de mis trabajos, dejé unos ejemplos aquí 👇🏽
https://urlr.me/39XCEx$msg$, true, 3, false),

  ('de', 'Deutsch', $msg$Hey! Ich bin auf dein Instagram-Profil gestoßen 👀

Ich baue moderne, individuelle Websites für Fußballtrainer, Personal Trainer und andere Sportprofis – und dachte, das könnte dich interessieren.

Ich biete 3 Pakete an:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Wartung auf Wunsch verfügbar: €9.99/Monat

Ich bin 16 und baue neben der Schule mein eigenes Webstudio auf, deshalb arbeite ich gerade daran, mich bekannt zu machen und meinen Kundenstamm aufzubauen.

Und wenn du jemanden kennst, der eine Website sucht: Wenn du mich weiterempfiehlst, bekommst du 50 % Rabatt auf deine 🤝

Wenn du ein paar meiner Arbeiten sehen willst, hier sind ein paar Beispiele 👇🏽
https://urlr.me/39XCEx$msg$, true, 4, false),

  ('it', 'Italiano', $msg$Ciao! Mi sono imbattuto nel tuo profilo Instagram 👀

Realizzo siti web moderni e su misura per allenatori di calcio, personal trainer e altri professionisti dello sport, e ho pensato che potesse interessarti.

Offro 3 pacchetti:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Manutenzione disponibile se serve: €9.99/mese

Ho 16 anni e sto costruendo il mio studio web mentre studio, quindi sto lavorando per farmi conoscere e ampliare la mia clientela.

E se conosci qualcuno che cerca un sito, ti faccio il 50% di sconto sul tuo se mi presenti 🤝

Se vuoi vedere alcuni dei miei lavori, ho messo qualche esempio qui 👇🏽
https://urlr.me/39XCEx$msg$, true, 5, false),

  ('pt', 'Português', $msg$Oi! Me deparei com o seu perfil no Instagram 👀

Eu crio sites modernos e personalizados para treinadores de futebol, personal trainers e outros profissionais do esporte, e achei que poderia te interessar.

Ofereço 3 pacotes:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Manutenção disponível se precisar: €9.99/mês

Tenho 16 anos e estou construindo meu próprio estúdio web junto com os estudos, então estou trabalhando para divulgar meu nome e crescer minha base de clientes.

E se você conhecer alguém procurando um site, te dou 50% de desconto no seu se me indicar 🤝

Se quiser ver alguns dos meus trabalhos, coloquei alguns exemplos aqui 👇🏽
https://urlr.me/39XCEx$msg$, true, 6, false),

  ('nl', 'Nederlands', $msg$Hoi! Ik kwam je Instagram-profiel tegen 👀

Ik bouw moderne, op maat gemaakte websites voor voetbaltrainers, personal trainers en andere sportprofessionals, en ik dacht dat dit misschien iets voor jou is.

Ik bied 3 pakketten aan:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Onderhoud beschikbaar indien nodig: €9.99/maand

Ik ben 16 en bouw naast mijn studie mijn eigen webstudio op, dus ik ben bezig om mijn naam bekend te maken en mijn klantenbestand te laten groeien.

En ken je iemand die een website zoekt? Dan krijg je 50% korting op die van jou als je me doorverwijst 🤝

Als je wat van mijn werk wilt zien, heb ik hier een paar voorbeelden gezet 👇🏽
https://urlr.me/39XCEx$msg$, true, 7, false),

  ('ar', 'العربية', $msg$مرحباً! صادفت ملفك على إنستغرام 👀

أصمم مواقع إلكترونية حديثة ومخصصة لمدربي كرة القدم والمدربين الشخصيين وغيرهم من محترفي الرياضة، وفكرت أن هذا قد يهمك.

أقدم 3 باقات:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

الصيانة متوفرة عند الحاجة: €9.99 شهرياً

عمري 16 عاماً وأبني استوديو الويب الخاص بي إلى جانب دراستي، لذلك أعمل على التعريف باسمي وتوسيع قاعدة عملائي.

وإذا كنت تعرف شخصاً يبحث عن موقع، سأمنحك خصم 50% على موقعك إذا رشحتني له 🤝

إذا أردت رؤية بعض أعمالي، وضعت بعض الأمثلة هنا 👇🏽
https://urlr.me/39XCEx$msg$, true, 8, true),

  ('pl', 'Polski', $msg$Cześć! Trafiłem na Twój profil na Instagramie 👀

Tworzę nowoczesne, indywidualne strony internetowe dla trenerów piłki nożnej, trenerów personalnych i innych osób związanych ze sportem — pomyślałem, że może Cię to zainteresować.

Oferuję 3 pakiety:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

Serwis dostępny w razie potrzeby: €9.99/miesiąc

Mam 16 lat i rozwijam własne studio webowe równolegle ze szkołą, więc staram się wypromować swoje nazwisko i powiększyć bazę klientów.

A jeśli znasz kogoś, kto szuka strony, dam Ci 50% zniżki na Twoją, jeśli mnie polecisz 🤝

Jeśli chcesz zobaczyć moje prace, kilka przykładów wrzuciłem tutaj 👇🏽
https://urlr.me/39XCEx$msg$, true, 9, false),

  ('tr', 'Türkçe', $msg$Selam! Instagram profiline denk geldim 👀

Futbol antrenörleri, kişisel antrenörler ve diğer spor profesyonelleri için modern, kişiye özel web siteleri tasarlıyorum ve bunun ilgini çekebileceğini düşündüm.

3 paket sunuyorum:
🟢 START — €29.99
🔵 PRO — €59.99
🟣 PREMIUM — €99.99

İhtiyaç halinde bakım hizmeti: ayda €9.99

16 yaşındayım ve okulumun yanında kendi web stüdyomu kuruyorum, bu yüzden adımı duyurmaya ve müşteri kitlemi büyütmeye çalışıyorum.

Ve eğer site arayan birini tanıyorsan, beni önerirsen seninkinde %50 indirim yaparım 🤝

Çalışmalarımdan bazılarını görmek istersen buraya birkaç örnek koydum 👇🏽
https://urlr.me/39XCEx$msg$, true, 10, false)
on conflict (language_code) do nothing;
