# Studio OS

Plateforme interne de gestion du studio web : prospection Instagram de l'équipe, CRM, ventes, commissions et bibliothèque de messages en 10 langues.

**Le site tient dans un seul fichier : [`index.html`](index.html) (1,4 Mo).** Double-clic → il s'ouvre dans ton navigateur, sans serveur, sans installation. Tout est embarqué : JavaScript, CSS, polices, icônes.

Stack : React 18 + TypeScript + Vite + Tailwind CSS v4 + Supabase (PostgreSQL, Auth, Row Level Security) + Recharts + TanStack Query.

---

## 1. Mise en route

### 1.1 Base Supabase (~2 minutes, une seule fois)

1. Projet Supabase → **SQL Editor** → **New query**.
2. Colle **tout** [`supabase/setup.sql`](supabase/setup.sql) → **Run**.

Cela crée les 10 tables, les contraintes, les triggers, les policies RLS et les 10 messages traduits.

La clé publishable et l'URL du projet sont déjà dans `index.html` (elles sont publiques par nature). Si tu changes de projet :

```bash
# .env.local
VITE_SUPABASE_URL=https://<ref>.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_xxx
npm run build            # régénère index.html
```

> La clé `service_role` n'est jamais utilisée : elle ne doit jamais apparaître dans un fichier frontend.

### 1.2 Compte administrateur

Ouvre `index.html`, clique **Créer un compte** avec ton email et un mot de passe (6 caractères minimum). **Le premier compte créé devient administrateur automatiquement.**

Vérification dans Supabase :

```sql
select email, role, is_active from public.profiles;
```

Si un autre compte a été créé avant le tien :

```sql
update public.profiles set role = 'admin', is_active = true
where lower(email) = lower('ton@email.com');
```

### 1.3 Inviter un membre

**Gestion d'équipe → Inviter un membre** (email, rôle, objectif quotidien). L'app génère un **lien** et un **code**.

- Si tout le monde ouvre le même `index.html` déployé en ligne → envoie le lien.
- En version fichier local → envoie le **code** (le lien pointerait vers un fichier sur ton ordinateur). Le membre ouvre son `index.html`, va sur **Activer mon compte**, colle le code.
- Le membre crée son compte **avec l'email invité**, l'accès s'active tout seul.

Le code est valable 14 jours, utilisable une seule fois, et uniquement avec l'email invité.

---

## 2. Rôles et sécurité

Toutes les permissions sont appliquées **dans PostgreSQL** via Row Level Security. Modifier le JavaScript ne donne aucun accès supplémentaire.

| Table | Membre | Admin |
| --- | --- | --- |
| `profiles` | lit / modifie **son** profil (`role`, `is_active`, `email` verrouillés par trigger) | tout |
| `team_settings` | lit son objectif et son taux de commission | lit et écrit tout |
| `daily_activities` | ses lignes uniquement, pas de suppression | tout |
| `prospects` / `prospect_interactions` | uniquement ceux qui lui sont assignés | tout |
| `deals` | uniquement les siennes | tout |
| `message_templates` | lecture | lecture + écriture |
| `team_invites` | rien | tout |
| `package_pricing`, `studio_settings` | lecture | écriture |
| `anon` | **aucun privilège** (révoqué) | — |

Garde-fous : `protect_profile_columns()` bloque toute auto-promotion (fonction en SECURITY INVOKER, donc `current_user` vaut réellement `authenticated`), `handle_new_user()` n'accorde `admin` qu'au premier compte, `claim_invite()` vérifie jeton + email. Contraintes de cohérence : `replies_received <= dms_sent + followups_sent`, `interested_prospects <= replies_received`, `unique (user_id, activity_date)`, `amount_paid <= deal_amount`, etc.

### Vérifier toi-même

```bash
npm run test:db      # 29 tests de schéma + RLS sur un vrai PostgreSQL (WASM)
npm run test:file    # ouvre index.html en file:// et vérifie qu'il fonctionne
```

`test:file` lance un Chromium headless sur `file://…/index.html` : rendu, polices embarquées, absence d'erreur JS, connectivité Supabase depuis une origine `null`, routage par hash, redirection des routes protégées.

---

## 3. Fonctionnalités

**Membre** — tableau de bord (DMs du jour, objectif, 7 jours, réponses, intéressés, rendez-vous, clients, conversion, série), saisie quotidienne en moins de 30 secondes avec compteurs, historique modifiable, CRM personnel, ventes et commissions.

**Admin** — KPIs équipe (aujourd'hui / 7 j / 30 j, leads actifs, clients, revenu, valeur signée), tableau de performance par membre avec statut, 5 graphiques, filtres de période, analytique par membre avec correction des saisies, invitations, objectifs, taux de commission, activation/désactivation, prix des formules et réglages studio.

**Messages** — 10 langues (EN source, FR, ES, DE, IT, PT, NL, AR en RTL, PL, TR), copie en un clic, aperçu complet, édition admin, rétablissement de l'original, ajout de langues.

**Calculs** — revenu = `amount_paid` des deals `won` uniquement ; valeur signée = `deal_amount` ; reste à encaisser = différence ; commission = `amount_paid × taux / 100` ; conversion = prospects gagnés / prospects contactés. Les dates sont des `date` (aucun décalage de fuseau), « aujourd'hui » suit la date locale du navigateur.

---

## 4. Deux façons de distribuer

| Mode | Comment | Commande |
| --- | --- | --- |
| **Fichier local** (par défaut) | `index.html` à la racine, double-clic | `npm run build` |
| **En ligne** | build multi-fichiers optimisé cache | `npm run build:hosted` → dossier `dist/` |

Le routage utilise le **hash** (`index.html#/prospects`), donc aucune règle de rewrite n'est nécessaire, ni en local ni en ligne.

Les mêmes fichiers servent au développement : `app.html` est l'entrée Vite.

```bash
npm install
npm run dev        # http://localhost:5199/app.html
```

---

## 5. Scripts

| Commande | Rôle |
| --- | --- |
| `npm run dev` | serveur de développement (`/app.html`) |
| `npm run build` | génère `index.html` autonome (le livrable) |
| `npm run build:hosted` | build multi-fichiers dans `dist/` |
| `npm run typecheck` | TypeScript strict |
| `npm run test:db` | 29 tests schéma + RLS |
| `npm run test:file` | test du fichier unique en `file://` |

---

## 6. Limites connues

- **Session en local** : elle est stockée dans le `localStorage` du navigateur. Chrome et Firefox l'autorisent sur `file://` ; si un navigateur le bloque, l'app fonctionne quand même mais tu devras te reconnecter à chaque ouverture.
- **Invitations** : pas d'email transactionnel. En local, transmets le **code** ; en ligne, le lien.
- **Commission** : le taux courant est appliqué aux deals passés (pas d'historique de taux figé par deal).
- **Prix des formules** : modifiables dans Réglages ; ils ne réécrivent pas les deals déjà enregistrés (le montant du deal reste celui negocié).
