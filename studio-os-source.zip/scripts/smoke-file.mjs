/**
 * Vérifie que index.html fonctionne réellement en file:// (double-clic).
 * - le routeur par hash affiche la page de connexion
 * - l'app parle bien à Supabase (erreur d'identifiants, pas erreur réseau)
 * - les routes hash et le copier-coller du code d'invitation fonctionnent
 * Usage : npm run test:file
 */
import { chromium } from "playwright-core";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { homedir } from "node:os";
import { readdirSync } from "node:fs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const target = join(root, "index.html");
const shots = join(root, "screenshots");

if (!existsSync(target)) {
  console.error("✗ index.html manquant — lance `npm run build:standalone`.");
  process.exit(1);
}

function findChromium() {
  const candidates = [
    process.env.CHROMIUM_PATH,
    join(homedir(), "Library/Caches/ms-playwright"),
  ].filter(Boolean);
  const base = candidates.find((path) => path && existsSync(path));
  if (!base) return null;
  for (const dir of readdirSync(base)) {
    if (!dir.startsWith("chromium")) continue;
    for (const relative of ["chrome-mac/headless_shell", "chrome-mac/Chromium", "chrome-linux/headless_shell"]) {
      const full = join(base, dir, relative);
      if (existsSync(full)) return full;
    }
  }
  return null;
}

const executablePath = findChromium();
if (!executablePath) {
  console.error("✗ Chromium introuvable. Définis CHROMIUM_PATH.");
  process.exit(1);
}

let failures = 0;
const check = (label, ok, detail = "") => {
  if (ok) console.log(`  ✓ ${label}`);
  else {
    failures += 1;
    console.log(`  ✗ ${label}${detail ? ` — ${detail}` : ""}`);
  }
};

const browser = await chromium.launch({ executablePath, args: ["--no-sandbox"] });
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });

const pageErrors = [];
const failedRequests = [];
page.on("pageerror", (error) => pageErrors.push(error.message));
page.on("requestfailed", (request) => failedRequests.push(`${request.url()} — ${request.failure()?.errorText}`));

const fileUrl = pathToFileURL(target).href;

console.log("\nOuverture du fichier local");
await page.goto(fileUrl, { waitUntil: "load" });
await page.waitForTimeout(800);

check("le titre de l'app est présent", (await page.title()).includes("Studio OS"));
check(
  "la page de connexion s'affiche sans serveur",
  await page.getByRole("heading", { name: "Content de te revoir" }).isVisible(),
);
check("aucune erreur JavaScript", pageErrors.length === 0, pageErrors.join(" | "));

const fontState = await page.evaluate(() => ({
  count: document.fonts.size,
  inter: document.fonts.check('16px "Inter Variable"'),
  family: getComputedStyle(document.body).fontFamily,
}));
check(
  "la police Inter est embarquée (pas de CDN)",
  fontState.count > 0 && fontState.family.includes("Inter"),
  `familles: ${fontState.count}, appliquée: ${fontState.inter}`,
);

await page.screenshot({ path: join(shots, "10-fichier-local.png"), fullPage: false });

console.log("\nConnectivité Supabase depuis file://");
await page.fill("#email", "personne-inexistante@studio.test");
await page.fill("#password", "motdepasse123");
await page.getByRole("button", { name: "Connexion" }).click();
await page.waitForTimeout(2500);
const errorText = await page.locator("p.text-danger").first().textContent().catch(() => "");
check(
  "l'API répond (identifiants invalides, pas erreur réseau)",
  Boolean(errorText && /incorrect/i.test(errorText)),
  errorText || "aucun message d'erreur",
);

console.log("\nRoutage par hash");
await page.goto(`${fileUrl}#/inscription`, { waitUntil: "load" });
await page.waitForTimeout(600);
check(
  "la création du compte admin est accessible",
  await page.getByRole("heading", { name: "Créer un compte" }).isVisible(),
);

await page.goto(`${fileUrl}#/invitation/11111111-1111-4111-8111-111111111111`, { waitUntil: "load" });
await page.waitForTimeout(600);
check(
  "le lien d'invitation ouvre la bonne page",
  await page.getByRole("heading", { name: "Activer mon compte" }).isVisible(),
);

await page.goto(`${fileUrl}#/reglages`, { waitUntil: "load" });
await page.waitForTimeout(600);
check(
  "une route protégée redirige vers la connexion",
  page.url().includes("#/connexion"),
  page.url(),
);

console.log("\nRéseau");
check(
  "aucune requête réseau en échec (hors API)",
  failedRequests.filter((line) => !line.includes("supabase.co")).length === 0,
  failedRequests.join(" | "),
);
check("aucune erreur JavaScript après navigation", pageErrors.length === 0, pageErrors.join(" | "));

await browser.close();

console.log(`\n${failures === 0 ? "✓ Fichier autonome opérationnel" : `✗ ${failures} échec(s)`}`);
process.exit(failures === 0 ? 0 : 1);
