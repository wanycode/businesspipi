/**
 * Transforme le build Vite en un fichier unique autonome.
 * Entrée : dist-standalone/app.html + assets
 * Sortie  : index.html à la racine du projet (ouvrable par double-clic, file://)
 */
import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dist = join(root, "dist-standalone");

let html;
try {
  html = readFileSync(join(dist, "app.html"), "utf8");
} catch {
  console.error("✗ dist-standalone/app.html introuvable — lance `vite build --mode standalone` d'abord.");
  process.exit(1);
}

const assetsDir = join(dist, "assets");
const assets = readdirSync(assetsDir).sort();

const jsFiles = assets.filter((file) => file.endsWith(".js"));
const cssFiles = assets.filter((file) => file.endsWith(".css"));

if (jsFiles.length !== 1) {
  console.error(`✗ Attendu 1 fichier JS, trouvé ${jsFiles.length}. Le bundle n'est pas unique.`);
  process.exit(1);
}

const js = readFileSync(join(assetsDir, jsFiles[0]), "utf8").replaceAll("</script", "<\\/script");
const css = cssFiles
  .map((file) => readFileSync(join(assetsDir, file), "utf8"))
  .join("\n")
  .replaceAll("</style", "<\\/style");

// Retire les balises qui déclenchent des requêtes réseau.
html = html.replace(/\s*<link rel="modulepreload"[^>]*>/g, "");

let injectedStyle = false;
html = html.replace(/<link[^>]+rel="stylesheet"[^>]*>/g, () => {
  injectedStyle = true;
  return `<style>\n${css}\n</style>`;
});

let injectedScript = false;
html = html.replace(/<script[^>]*src="[^"]*"[^>]*><\/script>/g, () => {
  injectedScript = true;
  return `<script type="module">\n${js}\n</script>`;
});

if (!injectedStyle || !injectedScript) {
  console.error(
    `✗ Injection incomplète (style: ${injectedStyle}, script: ${injectedScript}). Vérifie la sortie de build.`,
  );
  process.exit(1);
}

if (/<(script|link)[^>]+(src|href)="(?!data:)/.test(html)) {
  console.error("✗ Il reste une ressource externe dans le HTML : le fichier ne serait pas autonome.");
  process.exit(1);
}

const target = join(root, "index.html");
writeFileSync(target, html, "utf8");

const size = Buffer.byteLength(html, "utf8");
console.log(`✓ index.html généré (${(size / 1024 / 1024).toFixed(2)} Mo, tout inclus : JS, CSS, polices)`);
