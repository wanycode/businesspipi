import { useCallback } from "react";
import { useI18n, type TranslationKey } from "@/lib/i18n";
import { readableError } from "@/lib/utils";

/**
 * Traduit une erreur Supabase/Postgres en message lisible dans la langue
 * courante. Les messages inconnus sont renvoyés tels quels.
 */
export function useErrorText() {
  const { t } = useI18n();
  return useCallback(
    (error: unknown) => {
      const message = readableError(error);
      if (!message) return t("errors.generic");
      if (/^(auth|errors)\./.test(message)) return t(message as TranslationKey);
      return message;
    },
    [t],
  );
}
