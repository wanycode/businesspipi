export type Role = "admin" | "member";

export type ProspectStatus =
  | "to_contact"
  | "contacted"
  | "followup"
  | "replied"
  | "interested"
  | "negotiating"
  | "won"
  | "lost";

export type DealStatus = "proposed" | "won" | "lost";
export type PaymentStatus = "unpaid" | "partial" | "paid";
export type PackageCode = "START" | "PRO" | "PREMIUM";
export type InteractionType = "dm" | "reply" | "followup" | "call" | "meeting" | "note" | "sale";

export interface Profile {
  id: string;
  display_name: string;
  email: string;
  role: Role;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TeamSettings {
  id: string;
  user_id: string;
  daily_dm_target: number;
  commission_rate: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TeamMember extends Profile {
  daily_dm_target: number;
  commission_rate: number;
}

export interface TeamInvite {
  id: string;
  email: string;
  role: Role;
  daily_dm_target: number;
  token: string;
  created_by: string | null;
  expires_at: string;
  accepted_at: string | null;
  accepted_by: string | null;
  created_at: string;
}

export interface DailyActivity {
  id: string;
  user_id: string;
  activity_date: string;
  dms_sent: number;
  replies_received: number;
  interested_prospects: number;
  followups_sent: number;
  meetings_booked: number;
  sales_closed: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Prospect {
  id: string;
  name: string;
  instagram_username: string;
  instagram_url: string | null;
  country: string | null;
  language: string | null;
  niche: string | null;
  assigned_user_id: string;
  status: ProspectStatus;
  first_contacted_at: string | null;
  last_contacted_at: string | null;
  next_followup_at: string | null;
  estimated_value: number | null;
  notes: string | null;
  archived_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProspectInteraction {
  id: string;
  prospect_id: string;
  user_id: string;
  interaction_type: InteractionType;
  notes: string | null;
  interaction_date: string;
  created_at: string;
}

export interface Deal {
  id: string;
  prospect_id: string | null;
  client_name: string;
  assigned_user_id: string;
  package: PackageCode;
  deal_amount: number;
  deal_status: DealStatus;
  payment_status: PaymentStatus;
  amount_paid: number;
  maintenance_active: boolean;
  won_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MessageTemplate {
  id: string;
  language_code: string;
  language_name: string;
  message_content: string;
  default_content: string | null;
  is_default: boolean;
  sort_order: number;
  is_rtl: boolean;
  updated_at: string;
  updated_by: string | null;
}

export interface PackagePrice {
  code: PackageCode;
  label: string;
  price: number;
  sort_order: number;
  updated_at: string;
}

export interface StudioSettings {
  id: boolean;
  studio_name: string;
  currency: string;
  maintenance_price: number;
  portfolio_url: string;
  updated_at: string;
}

export const PROSPECT_STATUSES: ProspectStatus[] = [
  "to_contact",
  "contacted",
  "followup",
  "replied",
  "interested",
  "negotiating",
  "won",
  "lost",
];

export const PACKAGE_CODES: PackageCode[] = ["START", "PRO", "PREMIUM"];
export const DEAL_STATUSES: DealStatus[] = ["proposed", "won", "lost"];
export const PAYMENT_STATUSES: PaymentStatus[] = ["unpaid", "partial", "paid"];
export const INTERACTION_TYPES: InteractionType[] = [
  "dm",
  "reply",
  "followup",
  "call",
  "meeting",
  "note",
  "sale",
];

/** Statuts qui comptent comme "lead actif" dans les tableaux de bord. */
export const ACTIVE_LEAD_STATUSES: ProspectStatus[] = [
  "contacted",
  "followup",
  "replied",
  "interested",
  "negotiating",
];

export const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "fr", label: "Français" },
  { code: "es", label: "Español" },
  { code: "de", label: "Deutsch" },
  { code: "it", label: "Italiano" },
  { code: "pt", label: "Português" },
  { code: "nl", label: "Nederlands" },
  { code: "ar", label: "العربية" },
  { code: "pl", label: "Polski" },
  { code: "tr", label: "Türkçe" },
];
