import { supabase } from "@/lib/supabase";
import type {
  DailyActivity,
  Deal,
  MessageTemplate,
  PackagePrice,
  Profile,
  Prospect,
  ProspectInteraction,
  StudioSettings,
  TeamInvite,
  TeamSettings,
} from "@/lib/types";

function num(value: unknown): number {
  if (value === null || value === undefined) return 0;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function nullableNum(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export const mapActivity = (row: DailyActivity): DailyActivity => ({
  ...row,
  dms_sent: num(row.dms_sent),
  replies_received: num(row.replies_received),
  interested_prospects: num(row.interested_prospects),
  followups_sent: num(row.followups_sent),
  meetings_booked: num(row.meetings_booked),
  sales_closed: num(row.sales_closed),
});

export const mapProspect = (row: Prospect): Prospect => ({
  ...row,
  estimated_value: nullableNum(row.estimated_value),
});

export const mapDeal = (row: Deal): Deal => ({
  ...row,
  deal_amount: num(row.deal_amount),
  amount_paid: num(row.amount_paid),
});

/* -------------------------------------------------------------------------- */
/* Profiles & settings                                                         */
/* -------------------------------------------------------------------------- */
export async function getProfiles(): Promise<Profile[]> {
  const { data, error } = await supabase.from("profiles").select("*").order("created_at");
  if (error) throw error;
  return (data ?? []) as Profile[];
}

export async function getProfile(userId: string): Promise<Profile> {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single();
  if (error) throw error;
  return data as Profile;
}

export async function getTeamSettings(): Promise<TeamSettings[]> {
  const { data, error } = await supabase.from("team_settings").select("*").order("created_at");
  if (error) throw error;
  return (data ?? []) as TeamSettings[];
}

export async function updateProfile(
  userId: string,
  patch: Partial<Pick<Profile, "display_name" | "role" | "is_active">>,
): Promise<void> {
  const { error } = await supabase.from("profiles").update(patch).eq("id", userId);
  if (error) throw error;
}

export async function updateTeamSettings(
  userId: string,
  patch: Partial<Pick<TeamSettings, "daily_dm_target" | "is_active" | "commission_rate">>,
): Promise<void> {
  const { error } = await supabase.from("team_settings").update(patch).eq("user_id", userId);
  if (error) throw error;
}

export async function getStudioSettings(): Promise<StudioSettings> {
  const { data, error } = await supabase.from("studio_settings").select("*").eq("id", true).maybeSingle();
  if (error) throw error;
  return (
    (data as StudioSettings | null) ?? {
      id: true,
      studio_name: "Studio",
      currency: "EUR",
      maintenance_price: 9.99,
      portfolio_url: "https://urlr.me/39XCEx",
      updated_at: new Date().toISOString(),
    }
  );
}

export async function updateStudioSettings(patch: Partial<StudioSettings>): Promise<void> {
  const { error } = await supabase.from("studio_settings").update(patch).eq("id", true);
  if (error) throw error;
}

export async function getPackagePricing(): Promise<PackagePrice[]> {
  const { data, error } = await supabase.from("package_pricing").select("*").order("sort_order");
  if (error) throw error;
  return ((data ?? []) as PackagePrice[]).map((row) => ({ ...row, price: num(row.price) }));
}

export async function updatePackagePrice(code: string, price: number): Promise<void> {
  const { error } = await supabase.from("package_pricing").update({ price }).eq("code", code);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/* Daily activity                                                             */
/* -------------------------------------------------------------------------- */
export async function getActivities(params: { from?: string; to?: string } = {}): Promise<DailyActivity[]> {
  let query = supabase.from("daily_activities").select("*").order("activity_date", { ascending: false });
  if (params.from) query = query.gte("activity_date", params.from);
  if (params.to) query = query.lte("activity_date", params.to);
  const { data, error } = await query;
  if (error) throw error;
  return ((data ?? []) as DailyActivity[]).map(mapActivity);
}

export async function upsertActivity(input: {
  userId: string;
  activityDate: string;
  dmsSent: number;
  repliesReceived: number;
  interestedProspects: number;
  followupsSent: number;
  meetingsBooked: number;
  salesClosed: number;
  notes: string | null;
}): Promise<DailyActivity> {
  const { data, error } = await supabase
    .from("daily_activities")
    .upsert(
      {
        user_id: input.userId,
        activity_date: input.activityDate,
        dms_sent: input.dmsSent,
        replies_received: input.repliesReceived,
        interested_prospects: input.interestedProspects,
        followups_sent: input.followupsSent,
        meetings_booked: input.meetingsBooked,
        sales_closed: input.salesClosed,
        notes: input.notes,
      },
      { onConflict: "user_id,activity_date" },
    )
    .select("*")
    .single();
  if (error) throw error;
  return mapActivity(data as DailyActivity);
}

export async function deleteActivity(id: string): Promise<void> {
  const { error } = await supabase.from("daily_activities").delete().eq("id", id);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/* Prospects                                                                  */
/* -------------------------------------------------------------------------- */
export async function getProspects(): Promise<Prospect[]> {
  const { data, error } = await supabase
    .from("prospects")
    .select("*")
    .order("next_followup_at", { ascending: true, nullsFirst: false })
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return ((data ?? []) as Prospect[]).map(mapProspect);
}

export async function getInteractions(prospectIds: string[]): Promise<ProspectInteraction[]> {
  if (prospectIds.length === 0) return [];
  const { data, error } = await supabase
    .from("prospect_interactions")
    .select("*")
    .in("prospect_id", prospectIds)
    .order("interaction_date", { ascending: false });
  if (error) throw error;
  return (data ?? []) as ProspectInteraction[];
}

export interface ProspectInput {
  name: string;
  instagram_username: string;
  instagram_url: string | null;
  country: string | null;
  language: string | null;
  niche: string | null;
  assigned_user_id: string;
  status: Prospect["status"];
  first_contacted_at: string | null;
  last_contacted_at: string | null;
  next_followup_at: string | null;
  estimated_value: number | null;
  notes: string | null;
}

export function toProspectInput(prospect: Prospect): ProspectInput {
  return {
    name: prospect.name,
    instagram_username: prospect.instagram_username,
    instagram_url: prospect.instagram_url,
    country: prospect.country,
    language: prospect.language,
    niche: prospect.niche,
    assigned_user_id: prospect.assigned_user_id,
    status: prospect.status,
    first_contacted_at: prospect.first_contacted_at,
    last_contacted_at: prospect.last_contacted_at,
    next_followup_at: prospect.next_followup_at,
    estimated_value: prospect.estimated_value,
    notes: prospect.notes,
  };
}

export async function createProspect(input: ProspectInput): Promise<Prospect> {
  const { data, error } = await supabase.from("prospects").insert(input).select("*").single();
  if (error) throw error;
  return mapProspect(data as Prospect);
}

export async function updateProspect(id: string, patch: Partial<ProspectInput> & { archived_at?: string | null }): Promise<void> {
  const { error } = await supabase.from("prospects").update(patch).eq("id", id);
  if (error) throw error;
}

export async function deleteProspect(id: string): Promise<void> {
  const { error } = await supabase.from("prospects").delete().eq("id", id);
  if (error) throw error;
}

export async function createInteraction(input: {
  prospectId: string;
  userId: string;
  type: ProspectInteraction["interaction_type"];
  notes: string | null;
  date: string;
}): Promise<void> {
  const { error } = await supabase.from("prospect_interactions").insert({
    prospect_id: input.prospectId,
    user_id: input.userId,
    interaction_type: input.type,
    notes: input.notes,
    interaction_date: input.date,
  });
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/* Deals                                                                      */
/* -------------------------------------------------------------------------- */
export async function getDeals(): Promise<Deal[]> {
  const { data, error } = await supabase.from("deals").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return ((data ?? []) as Deal[]).map(mapDeal);
}

export interface DealInput {
  prospect_id: string | null;
  client_name: string;
  assigned_user_id: string;
  package: Deal["package"];
  deal_amount: number;
  deal_status: Deal["deal_status"];
  payment_status: Deal["payment_status"];
  amount_paid: number;
  maintenance_active: boolean;
  won_at: string | null;
  notes: string | null;
}

export async function createDeal(input: DealInput): Promise<void> {
  const { error } = await supabase.from("deals").insert(input);
  if (error) throw error;
}

export async function updateDeal(id: string, patch: Partial<DealInput>): Promise<void> {
  const { error } = await supabase.from("deals").update(patch).eq("id", id);
  if (error) throw error;
}

export async function deleteDeal(id: string): Promise<void> {
  const { error } = await supabase.from("deals").delete().eq("id", id);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/* Messages                                                                   */
/* -------------------------------------------------------------------------- */
export async function getMessages(): Promise<MessageTemplate[]> {
  const { data, error } = await supabase.from("message_templates").select("*").order("sort_order");
  if (error) throw error;
  return (data ?? []) as MessageTemplate[];
}

export async function updateMessage(
  id: string,
  patch: { message_content?: string; language_name?: string; is_rtl?: boolean; updated_by?: string },
): Promise<void> {
  const { error } = await supabase.from("message_templates").update(patch).eq("id", id);
  if (error) throw error;
}

export async function resetMessage(id: string, updatedBy: string): Promise<void> {
  const { data, error } = await supabase
    .from("message_templates")
    .select("default_content, message_content")
    .eq("id", id)
    .single();
  if (error) throw error;
  const row = data as { default_content: string | null; message_content: string };
  await updateMessage(id, { message_content: row.default_content ?? row.message_content, updated_by: updatedBy });
}

export async function createMessage(input: {
  language_code: string;
  language_name: string;
  message_content: string;
  is_rtl: boolean;
  sort_order: number;
  updated_by: string;
}): Promise<void> {
  const { error } = await supabase.from("message_templates").insert({ ...input, is_default: true });
  if (error) throw error;
}

export async function deleteMessage(id: string): Promise<void> {
  const { error } = await supabase.from("message_templates").delete().eq("id", id);
  if (error) throw error;
}

/* -------------------------------------------------------------------------- */
/* Invites                                                                    */
/* -------------------------------------------------------------------------- */
export async function getInvites(): Promise<TeamInvite[]> {
  const { data, error } = await supabase.from("team_invites").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TeamInvite[];
}

export async function createInvite(input: {
  email: string;
  role: "admin" | "member";
  target: number;
  createdBy: string;
}): Promise<TeamInvite> {
  const { data, error } = await supabase
    .from("team_invites")
    .insert({
      email: input.email.trim().toLowerCase(),
      role: input.role,
      daily_dm_target: input.target,
      created_by: input.createdBy,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as TeamInvite;
}

export async function deleteInvite(id: string): Promise<void> {
  const { error } = await supabase.from("team_invites").delete().eq("id", id);
  if (error) throw error;
}

export async function claimInvite(token: string): Promise<{ role: string }> {
  const { data, error } = await supabase.rpc("claim_invite", { p_token: token });
  if (error) throw error;
  return data as { role: string };
}
