import { addDays, differenceInCalendarDays, parseISO } from "date-fns";
import type { DailyActivity, Deal, Prospect } from "@/lib/types";
import { ACTIVE_LEAD_STATUSES } from "@/lib/types";
import { computeStreak, dayRange, sumBy, toISODate, todayISO } from "@/lib/utils";

export const inRange = (date: string | null, from: string, to: string): boolean =>
  Boolean(date && date >= from && date <= to);

export function activitiesInRange(activities: DailyActivity[], from: string, to: string): DailyActivity[] {
  return activities.filter((row) => inRange(row.activity_date, from, to));
}

export function totals(activities: DailyActivity[]) {
  return {
    dms: sumBy(activities, (row) => row.dms_sent),
    replies: sumBy(activities, (row) => row.replies_received),
    interested: sumBy(activities, (row) => row.interested_prospects),
    followups: sumBy(activities, (row) => row.followups_sent),
    meetings: sumBy(activities, (row) => row.meetings_booked),
    sales: sumBy(activities, (row) => row.sales_closed),
    days: activities.filter((row) => row.dms_sent > 0).length,
  };
}

export function dailySeries(
  activities: DailyActivity[],
  from: string,
  to: string,
): { date: string; dms: number; replies: number; interested: number; followups: number }[] {
  const days = dayRange(from, to);
  const byDate = new Map<string, DailyActivity>();
  for (const row of activities) {
    const current = byDate.get(row.activity_date);
    if (current) {
      byDate.set(row.activity_date, {
        ...current,
        dms_sent: current.dms_sent + row.dms_sent,
        replies_received: current.replies_received + row.replies_received,
        interested_prospects: current.interested_prospects + row.interested_prospects,
        followups_sent: current.followups_sent + row.followups_sent,
      });
    } else {
      byDate.set(row.activity_date, row);
    }
  }
  return days.map((date) => {
    const row = byDate.get(date);
    return {
      date,
      dms: row?.dms_sent ?? 0,
      replies: row?.replies_received ?? 0,
      interested: row?.interested_prospects ?? 0,
      followups: row?.followups_sent ?? 0,
    };
  });
}

export interface MemberStats {
  userId: string;
  dmsToday: number;
  dmsWeek: number;
  dmsMonth: number;
  repliesWeek: number;
  interestedWeek: number;
  meetingsMonth: number;
  target: number;
  todayRate: number;
  lastActivityDate: string | null;
  loggedToday: boolean;
  streak: number;
  activitiesCount: number;
  dealsWon: number;
  revenue: number;
  signedValue: number;
  commission: number;
  commissionRate: number;
  conversion: number;
  status: "on_target" | "behind" | "none" | "inactive";
}

export function computeMemberStats(input: {
  userId: string;
  activities: DailyActivity[];
  deals: Deal[];
  prospects: Prospect[];
  target: number;
  commissionRate?: number;
  isActive: boolean;
}): MemberStats {
  const today = todayISO();
  const weekFrom = toISODate(addDays(new Date(), -6));
  const dbMonthFrom = toISODate(addDays(new Date(), -29));

  const own = input.activities.filter((row) => row.user_id === input.userId);
  const todayRow = own.find((row) => row.activity_date === today);
  const weekRows = activitiesInRange(own, weekFrom, today);
  const monthRows = activitiesInRange(own, dbMonthFrom, today);
  const week = totals(weekRows);

  const wonDeals = input.deals.filter((deal) => deal.assigned_user_id === input.userId && deal.deal_status === "won");
  const ownProspects = input.prospects.filter((prospect) => prospect.assigned_user_id === input.userId);
  const contacted = ownProspects.filter((prospect) => prospect.status !== "to_contact");
  const wonProspects = ownProspects.filter((prospect) => prospect.status === "won");

  const dmsToday = todayRow?.dms_sent ?? 0;
  const todayRate = input.target > 0 ? dmsToday / input.target : 0;

  const status: MemberStats["status"] = !input.isActive
    ? "inactive"
    : week.dms === 0 && own.length === 0
      ? "none"
      : todayRate >= 1
        ? "on_target"
        : "behind";

  return {
    userId: input.userId,
    dmsToday,
    dmsWeek: week.dms,
    dmsMonth: totals(monthRows).dms,
    repliesWeek: week.replies,
    interestedWeek: week.interested,
    meetingsMonth: totals(monthRows).meetings,
    target: input.target,
    todayRate,
    lastActivityDate: own.length > 0 ? own[0]!.activity_date : null,
    loggedToday: Boolean(todayRow),
    streak: computeStreak(own.map((row) => row.activity_date)),
    activitiesCount: own.length,
    dealsWon: wonDeals.length,
    revenue: sumBy(wonDeals, (deal) => deal.amount_paid),
    signedValue: sumBy(wonDeals, (deal) => deal.deal_amount),
    commission: (sumBy(wonDeals, (deal) => deal.amount_paid) * (input.commissionRate ?? 0)) / 100,
    commissionRate: input.commissionRate ?? 0,
    conversion: contacted.length > 0 ? wonProspects.length / contacted.length : 0,
    status,
  };
}

export function teamTotals(input: {
  activities: DailyActivity[];
  deals: Deal[];
  prospects: Prospect[];
  from: string;
  to: string;
}) {
  const rows = activitiesInRange(input.activities, input.from, input.to);
  const base = totals(rows);
  const wonInRange = input.deals.filter(
    (deal) => deal.deal_status === "won" && inRange(deal.won_at, input.from, input.to),
  );
  return {
    ...base,
    activeLeads: input.prospects.filter(
      (prospect) => !prospect.archived_at && ACTIVE_LEAD_STATUSES.includes(prospect.status),
    ).length,
    clients: wonInRange.length,
    revenue: sumBy(wonInRange, (deal) => deal.amount_paid),
    signedValue: sumBy(wonInRange, (deal) => deal.deal_amount),
  };
}

/** Variation en % entre la période courante et la précédente de même durée. */
export function trendBetween(current: number, previous: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return (current - previous) / previous;
}

export function shiftRange(from: string, to: string): { from: string; to: string } {
  const length = Math.max(differenceInCalendarDays(parseISO(to), parseISO(from)) + 1, 1);
  const previousTo = addDays(parseISO(from), -1);
  return { from: toISODate(addDays(previousTo, -(length - 1))), to: toISODate(previousTo) };
}

export function revenueSeries(
  deals: Deal[],
  from: string,
  to: string,
): { label: string; value: number }[] {
  const days = dayRange(from, to);
  const map = new Map<string, number>();
  for (const deal of deals) {
    if (deal.deal_status !== "won" || !deal.won_at) continue;
    map.set(deal.won_at, (map.get(deal.won_at) ?? 0) + deal.amount_paid);
  }
  return days.map((date) => ({ label: date, value: map.get(date) ?? 0 }));
}

export function prospectsByStatus(prospects: Prospect[]) {
  const counts = new Map<string, number>();
  for (const prospect of prospects) {
    counts.set(prospect.status, (counts.get(prospect.status) ?? 0) + 1);
  }
  return counts;
}
