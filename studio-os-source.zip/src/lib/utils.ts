import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { addDays, differenceInCalendarDays, eachDayOfInterval, format, parseISO, startOfMonth, startOfWeek, subDays } from "date-fns";
import { fr, enGB } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type Lang = "fr" | "en";

export const dateLocales = { fr, en: enGB } as const;

/** Date locale au format YYYY-MM-DD (évite les décalages UTC). */
export function toISODate(date: Date): string {
  return format(date, "yyyy-MM-dd");
}

export function todayISO(): string {
  return toISODate(new Date());
}

export function parseDate(value: string): Date {
  return parseISO(value);
}

export function weekStartISO(reference = new Date()): string {
  return toISODate(startOfWeek(reference, { weekStartsOn: 1 }));
}

export function monthStartISO(reference = new Date()): string {
  return toISODate(startOfMonth(reference));
}

export function dayRange(from: string, to: string): string[] {
  const start = parseDate(from);
  const end = parseDate(to);
  if (differenceInCalendarDays(end, start) < 0) return [];
  const capped = Math.min(differenceInCalendarDays(end, start), 366);
  return eachDayOfInterval({ start, end: addDays(start, capped) }).map(toISODate);
}

export function formatMoney(value: number, lang: Lang = "fr"): string {
  return new Intl.NumberFormat(lang === "fr" ? "fr-FR" : "en-GB", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatNumber(value: number, lang: Lang = "fr"): string {
  return new Intl.NumberFormat(lang === "fr" ? "fr-FR" : "en-GB").format(
    Number.isFinite(value) ? value : 0,
  );
}

export function formatPercent(value: number, lang: Lang = "fr"): string {
  return new Intl.NumberFormat(lang === "fr" ? "fr-FR" : "en-GB", {
    style: "percent",
    maximumFractionDigits: 1,
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatDate(value: string | Date | null | undefined, lang: Lang = "fr"): string {
  if (!value) return "—";
  const date = typeof value === "string" ? parseISO(value) : value;
  return format(date, lang === "fr" ? "d MMM yyyy" : "d MMM yyyy", { locale: dateLocales[lang] });
}

export function formatDateShort(value: string | Date | null | undefined, lang: Lang = "fr"): string {
  if (!value) return "—";
  const date = typeof value === "string" ? parseISO(value) : value;
  return format(date, "d MMM", { locale: dateLocales[lang] });
}

export function formatDayLabel(value: string, lang: Lang = "fr"): string {
  const date = parseISO(value);
  return format(date, lang === "fr" ? "EEE d" : "EEE d", { locale: dateLocales[lang] });
}

export function relativeDays(value: string | null | undefined, lang: Lang = "fr"): string {
  if (!value) return "—";
  const diff = differenceInCalendarDays(new Date(), parseISO(value));
  if (lang === "fr") {
    if (diff === 0) return "aujourd'hui";
    if (diff === 1) return "hier";
    if (diff === -1) return "demain";
    if (diff > 0) return `il y a ${diff} j`;
    return `dans ${Math.abs(diff)} j`;
  }
  if (diff === 0) return "today";
  if (diff === 1) return "yesterday";
  if (diff === -1) return "tomorrow";
  if (diff > 0) return `${diff}d ago`;
  return `in ${Math.abs(diff)}d`;
}

export function isOverdue(value: string | null | undefined): boolean {
  if (!value) return false;
  return parseISO(value) < parseISO(todayISO());
}

/** Série de jours consécutifs avec activité, en remontant depuis aujourd'hui. */
export function computeStreak(dates: string[]): number {
  const set = new Set(dates);
  let cursor = new Date();
  if (!set.has(toISODate(cursor))) {
    cursor = subDays(cursor, 1);
    if (!set.has(toISODate(cursor))) return 0;
  }
  let streak = 0;
  while (set.has(toISODate(cursor))) {
    streak += 1;
    cursor = subDays(cursor, 1);
  }
  return streak;
}

export function sumBy<T>(rows: T[], pick: (row: T) => number): number {
  return rows.reduce((total, row) => total + (pick(row) || 0), 0);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function slugifyUsername(value: string): string {
  return value
    .trim()
    .replace(/^@+/, "")
    .replace(/\s+/g, "")
    .toLowerCase();
}

export function instagramUrlFromUsername(username: string): string {
  return `https://instagram.com/${slugifyUsername(username)}`;
}

/** Base de l'app, compatible file:// (double-clic) et hébergement HTTP. */
export function appBaseUrl(): string {
  if (window.location.protocol === "file:") return decodeURI(window.location.pathname);
  return `${window.location.origin}${window.location.pathname}`;
}

export function inviteUrl(token: string): string {
  return `${appBaseUrl()}#/invitation/${token}`;
}

/** Extrait l'UUID d'un lien d'invitation collé ou d'un code brut. */
export function extractInviteToken(value: string): string | null {
  const match = value.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  return match ? match[0] : null;
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // fallback ci-dessous
  }
  try {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(area);
    return ok;
  } catch {
    return false;
  }
}

/** Convertit une erreur Supabase/Postgres en message lisible. */
export function readableError(error: unknown): string {
  if (!error) return "";
  const message =
    typeof error === "string"
      ? error
      : (error as { message?: string }).message ?? "Erreur inconnue";
  const map: Record<string, string> = {
    "Invalid login credentials": "auth.invalidCredentials",
    "Email not confirmed": "auth.emailNotConfirmed",
    "User already registered": "auth.emailTaken",
    "Password should be at least 6 characters": "auth.weakPassword",
    "duplicate key value violates unique constraint \"daily_activities_user_date_key\"": "errors.duplicateActivity",
    "duplicate key value violates unique constraint \"prospects_instagram_unique\"": "errors.duplicateProspect",
    "new row violates row-level security policy for table \"daily_activities\"": "errors.rlsDenied",
    "new row violates row-level security policy for table \"prospects\"": "errors.rlsDenied",
    "new row violates row-level security policy for table \"deals\"": "errors.rlsDenied",
    "INVALID_INVITE": "errors.invalidInvite",
    "Failed to fetch": "errors.network",
    "NetworkError when attempting to fetch resource.": "errors.network",
  };
  return map[message] ?? message;
}
