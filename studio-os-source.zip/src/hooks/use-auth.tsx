import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isConfigured } from "@/lib/supabase";
import { getProfile, getTeamSettings } from "@/lib/api";
import type { Profile, TeamSettings } from "@/lib/types";

interface AuthState {
  session: Session | null;
  profile: Profile | null;
  settings: TeamSettings | null;
  loading: boolean;
  isAdmin: boolean;
  configured: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: { email: string; password: string; displayName: string }) => Promise<{ needsConfirmation: boolean }>;
  signOut: () => Promise<void>;
  reload: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

async function loadProfile(userId: string): Promise<{ profile: Profile | null; settings: TeamSettings | null }> {
  // Le trigger SQL crée le profil juste après l'inscription : on retente brièvement.
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const [profiles, settings] = await Promise.all([getProfile(userId), getTeamSettings()]);
    if (profiles) return { profile: profiles, settings: settings.find((row) => row.user_id === userId) ?? null };
    await new Promise((resolve) => setTimeout(resolve, 400));
  }
  return { profile: null, settings: null };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [settings, setSettings] = useState<TeamSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const bootstrap = useCallback(async (nextSession: Session | null) => {
    setSession(nextSession);
    if (!nextSession?.user) {
      setProfile(null);
      setSettings(null);
      setLoading(false);
      return;
    }
    try {
      const result = await loadProfile(nextSession.user.id);
      setProfile(result.profile);
      setSettings(result.settings);
    } catch {
      setProfile(null);
      setSettings(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!isConfigured) {
      setLoading(false);
      return;
    }
    let active = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (active) void bootstrap(data.session);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((event, nextSession) => {
      if (!active) return;
      if (event === "SIGNED_OUT") {
        setSession(null);
        setProfile(null);
        setSettings(null);
        return;
      }
      if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED" || event === "INITIAL_SESSION") {
        void bootstrap(nextSession);
      }
    });
    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, [bootstrap]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error) throw error;
  }, []);

  const signUp = useCallback(
    async ({ email, password, displayName }: { email: string; password: string; displayName: string }) => {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: { display_name: displayName.trim() },
          // Pas de redirection possible en file:// (origine opaque).
          emailRedirectTo:
            window.location.protocol === "file:" ? undefined : `${window.location.origin}/`,
        },
      });
      if (error) throw error;
      return { needsConfirmation: !data.session };
    },
    [],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setProfile(null);
    setSettings(null);
  }, []);

  const reload = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session?.user) {
      const result = await loadProfile(data.session.user.id);
      setProfile(result.profile);
      setSettings(result.settings);
    }
  }, []);

  const value = useMemo<AuthState>(
    () => ({
      session,
      profile,
      settings,
      loading,
      isAdmin: profile?.role === "admin" && profile.is_active,
      configured: isConfigured,
      signIn,
      signUp,
      signOut,
      reload,
    }),
    [session, profile, settings, loading, signIn, signUp, signOut, reload],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
