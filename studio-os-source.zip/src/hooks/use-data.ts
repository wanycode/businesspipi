import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { addDays } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import * as api from "@/lib/api";
import type { DealInput, ProspectInput } from "@/lib/api";
import type { Deal, Prospect, TeamMember } from "@/lib/types";
import { toISODate } from "@/lib/utils";

export const qk = {
  members: ["members"] as const,
  activities: ["activities"] as const,
  prospects: ["prospects"] as const,
  interactions: (ids: string[]) => ["interactions", ids.join(",")] as const,
  deals: ["deals"] as const,
  messages: ["messages"] as const,
  pricing: ["pricing"] as const,
  studio: ["studio"] as const,
  invites: ["invites"] as const,
};

const HISTORY_DAYS = 400;

export function useMembers() {
  const { profile } = useAuth();
  return useQuery<TeamMember[]>({
    queryKey: qk.members,
    enabled: Boolean(profile),
    queryFn: async () => {
      const [profiles, settings] = await Promise.all([api.getProfiles(), api.getTeamSettings()]);
      return profiles
        .map((row) => {
          const own = settings.find((item) => item.user_id === row.id);
          return {
            ...row,
            daily_dm_target: own?.daily_dm_target ?? 30,
            commission_rate: Number(own?.commission_rate ?? 20),
          };
        })
        .sort((a, b) => a.display_name.localeCompare(b.display_name));
    },
  });
}

export function useActivities() {
  const { profile } = useAuth();
  const from = toISODate(addDays(new Date(), -HISTORY_DAYS));
  return useQuery({
    queryKey: qk.activities,
    enabled: Boolean(profile),
    queryFn: () => api.getActivities({ from }),
  });
}

export function useProspects() {
  const { profile } = useAuth();
  return useQuery({
    queryKey: qk.prospects,
    enabled: Boolean(profile),
    queryFn: () => api.getProspects(),
  });
}

export function useInteractions(prospectIds: string[]) {
  return useQuery({
    queryKey: qk.interactions(prospectIds),
    enabled: prospectIds.length > 0,
    queryFn: () => api.getInteractions(prospectIds),
  });
}

export function useDeals() {
  const { profile } = useAuth();
  return useQuery({
    queryKey: qk.deals,
    enabled: Boolean(profile),
    queryFn: () => api.getDeals(),
  });
}

export function useMessages() {
  const { profile } = useAuth();
  return useQuery({
    queryKey: qk.messages,
    enabled: Boolean(profile),
    queryFn: () => api.getMessages(),
  });
}

export function usePricing() {
  const { profile } = useAuth();
  return useQuery({
    queryKey: qk.pricing,
    enabled: Boolean(profile),
    queryFn: () => api.getPackagePricing(),
  });
}

export function useStudioSettings() {
  const { profile } = useAuth();
  return useQuery({
    queryKey: qk.studio,
    enabled: Boolean(profile),
    queryFn: () => api.getStudioSettings(),
  });
}

export function useInvites() {
  const { profile, isAdmin } = useAuth();
  return useQuery({
    queryKey: qk.invites,
    enabled: Boolean(profile) && isAdmin,
    queryFn: () => api.getInvites(),
  });
}

/* -------------------------------------------------------------------------- */
/* Mutations                                                                  */
/* -------------------------------------------------------------------------- */
function useInvalidate() {
  const client = useQueryClient();
  return (keys: readonly (readonly unknown[])[]) => {
    for (const key of keys) void client.invalidateQueries({ queryKey: key });
  };
}

export function useSaveActivity() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: api.upsertActivity,
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.activities });
    },
  });
}

export function useDeleteActivity() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.deleteActivity(id),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.activities });
    },
  });
}

export function useSaveProspect() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, input }: { id?: string; input: ProspectInput }) => {
      if (id) {
        await api.updateProspect(id, input);
        return null;
      }
      return api.createProspect(input);
    },
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.prospects });
    },
  });
}

export function useArchiveProspect() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, archived }: { id: string; archived: boolean }) =>
      api.updateProspect(id, { archived_at: archived ? new Date().toISOString() : null }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.prospects });
    },
  });
}

export function useDeleteProspect() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.deleteProspect(id),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.prospects });
    },
  });
}

export function useLogInteraction() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: api.createInteraction,
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.prospects });
      void client.invalidateQueries({ queryKey: ["interactions"] });
    },
  });
}

export function useSaveDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, input }: { id?: string; input: DealInput }) => {
      if (id) return api.updateDeal(id, input);
      return api.createDeal(input);
    },
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.deals });
      void client.invalidateQueries({ queryKey: qk.prospects });
    },
  });
}

export function useDeleteDeal() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.deleteDeal(id),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.deals });
    },
  });
}

export function useUpdateMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, content, updatedBy }: { id: string; content: string; updatedBy: string }) =>
      api.updateMessage(id, { message_content: content, updated_by: updatedBy }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.messages });
    },
  });
}

export function useResetMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({ id, updatedBy }: { id: string; updatedBy: string }) => api.resetMessage(id, updatedBy),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.messages });
    },
  });
}

export function useAddMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: api.createMessage,
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.messages });
    },
  });
}

export function useDeleteMessage() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.deleteMessage(id),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: qk.messages });
    },
  });
}

export function useUpdateTarget() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: ({ userId, target }: { userId: string; target: number }) =>
      api.updateTeamSettings(userId, { daily_dm_target: target }),
    onSuccess: () => invalidate([qk.members]),
  });
}

export function useUpdateCommission() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: ({ userId, rate }: { userId: string; rate: number }) =>
      api.updateTeamSettings(userId, { commission_rate: Math.max(0, Math.min(100, rate)) }),
    onSuccess: () => invalidate([qk.members]),
  });
}

export function useSetMemberActive() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: ({ userId, active }: { userId: string; active: boolean }) =>
      api.updateProfile(userId, { is_active: active }),
    onSuccess: () => invalidate([qk.members]),
  });
}

export function useCreateInvite() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: api.createInvite,
    onSuccess: () => invalidate([qk.invites]),
  });
}

export function useDeleteInvite() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: (id: string) => api.deleteInvite(id),
    onSuccess: () => invalidate([qk.invites]),
  });
}

export function useUpdateProfile() {
  const invalidate = useInvalidate();
  const { reload } = useAuth();
  return useMutation({
    mutationFn: ({ userId, displayName }: { userId: string; displayName: string }) =>
      api.updateProfile(userId, { display_name: displayName }),
    onSuccess: async () => {
      invalidate([qk.members]);
      await reload();
    },
  });
}

export function useUpdateStudio() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async (input: {
      studio_name: string;
      maintenance_price: number;
      portfolio_url: string;
      prices: { code: string; price: number }[];
    }) => {
      await api.updateStudioSettings({
        studio_name: input.studio_name,
        maintenance_price: input.maintenance_price,
        portfolio_url: input.portfolio_url,
      });
      await Promise.all(input.prices.map((item) => api.updatePackagePrice(item.code, item.price)));
    },
    onSuccess: () => invalidate([qk.studio, qk.pricing]),
  });
}

/** Helpers de lecture synchrones sur les données déjà chargées. */
export function groupByUser<T extends { user_id?: string; assigned_user_id?: string }>(
  rows: T[],
  key: "user_id" | "assigned_user_id",
): Map<string, T[]> {
  const map = new Map<string, T[]>();
  for (const row of rows) {
    const id = (row[key] as string | undefined) ?? "";
    const list = map.get(id);
    if (list) list.push(row);
    else map.set(id, [row]);
  }
  return map;
}

export type { Deal, Prospect };
