import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  BarChart3,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquareText,
  Settings,
  Users,
  UsersRound,
  Wallet,
  X,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import type { TranslationKey } from "@/lib/i18n";
import { cn, initials } from "@/lib/utils";
import { Badge } from "@/components/ui";

interface NavItem {
  to: string;
  labelKey: TranslationKey;
  icon: typeof LayoutDashboard;
  adminOnly?: boolean;
  end?: boolean;
}

const workspaceNav: NavItem[] = [
  { to: "/", labelKey: "nav.overview", icon: LayoutDashboard, end: true },
  { to: "/activite", labelKey: "nav.myActivity", icon: ClipboardList },
  { to: "/prospects", labelKey: "nav.prospects", icon: Users },
  { to: "/ventes", labelKey: "nav.sales", icon: Wallet },
  { to: "/messages", labelKey: "nav.messages", icon: MessageSquareText },
];

const adminNav: NavItem[] = [
  { to: "/equipe", labelKey: "nav.team", icon: UsersRound, adminOnly: true },
  { to: "/analytique", labelKey: "nav.analytics", icon: BarChart3, adminOnly: true },
];

export function AppShell() {
  const { profile, isAdmin, signOut } = useAuth();
  const { t, lang, setLang } = useI18n();
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!mobileOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [mobileOpen]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/connexion", { replace: true });
  };

  const renderLink = (item: NavItem) => {
    const Icon = item.icon;
    return (
      <NavLink
        key={item.to}
        to={item.to}
        end={item.end}
        className={({ isActive }) =>
          cn(
            "group flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium transition-colors",
            isActive
              ? "bg-surface-3 text-fg shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]"
              : "text-muted hover:bg-surface-2 hover:text-fg",
          )
        }
      >
        {({ isActive }) => (
          <>
            <Icon
              className={cn(
                "size-4 shrink-0 transition-colors",
                isActive ? "text-brand-400" : "text-faint group-hover:text-muted",
              )}
            />
            <span className="truncate">{t(item.labelKey)}</span>
          </>
        )}
      </NavLink>
    );
  };

  const sidebarContent = (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center gap-2.5 px-3.5">
        <div className="flex size-7 items-center justify-center rounded-lg bg-brand-500 text-[13px] font-bold text-white shadow-[0_6px_16px_-6px_rgba(110,86,248,0.9)]">
          S
        </div>
        <div className="min-w-0">
          <p className="truncate text-[13px] font-semibold tracking-tight text-fg">{t("app.name")}</p>
          <p className="truncate text-[10px] uppercase tracking-wider text-faint">{t("app.tagline")}</p>
        </div>
      </div>

      <nav className="flex-1 space-y-5 overflow-y-auto px-2 py-2">
        <div className="space-y-0.5">
          <p className="px-2.5 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-faint">
            {t("nav.workspaceGroup")}
          </p>
          {workspaceNav.map(renderLink)}
        </div>

        {isAdmin ? (
          <div className="space-y-0.5">
            <p className="px-2.5 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-faint">
              {t("nav.adminGroup")}
            </p>
            {adminNav.map(renderLink)}
          </div>
        ) : null}

        <div className="space-y-0.5">
          <p className="px-2.5 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-faint">
            {t("nav.accountGroup")}
          </p>
          {renderLink({ to: "/reglages", labelKey: "nav.settings", icon: Settings })}
        </div>
      </nav>

      <div className="border-t border-line p-2">
        <div className="flex items-center gap-2.5 rounded-lg px-1.5 py-1.5">
          <span className="flex size-7 shrink-0 items-center justify-center rounded-full border border-line-strong bg-surface-3 text-[10px] font-semibold text-muted">
            {initials(profile?.display_name ?? "?")}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[12px] font-medium text-fg">{profile?.display_name}</p>
            <p className="truncate text-[10px] text-faint">{profile?.email}</p>
          </div>
          <button
            type="button"
            onClick={handleSignOut}
            className="rounded-md p-1.5 text-faint transition-colors hover:bg-surface-3 hover:text-danger"
            aria-label={t("common.logout")}
            title={t("common.logout")}
          >
            <LogOut className="size-3.5" />
          </button>
        </div>
        <div className="mt-1.5 flex items-center justify-between gap-2 px-1.5">
          <div className="inline-flex items-center rounded-md border border-line bg-surface-2 p-0.5">
            {(["fr", "en"] as const).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                className={cn(
                  "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase transition-colors",
                  lang === code ? "bg-surface-3 text-fg" : "text-faint hover:text-muted",
                )}
              >
                {code}
              </button>
            ))}
          </div>
          {isAdmin ? (
            <Badge tone="brand" className="text-[10px]">
              {t("common.admin")}
            </Badge>
          ) : null}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh bg-canvas">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[232px] border-r border-line bg-surface/60 backdrop-blur-sm lg:block">
        {sidebarContent}
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-[2px] animate-fade-in"
            onClick={() => setMobileOpen(false)}
            aria-hidden
          />
          <aside className="relative z-10 h-full w-[264px] border-r border-line bg-surface animate-fade-in">
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              className="absolute right-3 top-4 rounded-md p-1.5 text-faint hover:bg-surface-3 hover:text-fg"
              aria-label={t("common.close")}
            >
              <X className="size-4" />
            </button>
            {sidebarContent}
          </aside>
        </div>
      ) : null}

      <div className="lg:pl-[232px]">
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-line bg-canvas/85 px-4 backdrop-blur-md lg:hidden">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="rounded-md p-1.5 text-muted hover:bg-surface-3 hover:text-fg"
              aria-label="Menu"
            >
              <Menu className="size-4.5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex size-6 items-center justify-center rounded-md bg-brand-500 text-[11px] font-bold text-white">
                S
              </div>
              <span className="text-[13px] font-semibold tracking-tight">{t("app.name")}</span>
            </div>
          </div>
          <div className="inline-flex items-center rounded-md border border-line bg-surface-2 p-0.5">
            {(["fr", "en"] as const).map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                className={cn(
                  "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase transition-colors",
                  lang === code ? "bg-surface-3 text-fg" : "text-faint hover:text-muted",
                )}
              >
                {code}
              </button>
            ))}
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1400px] px-4 py-5 sm:px-6 sm:py-7">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
