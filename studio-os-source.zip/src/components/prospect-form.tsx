import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { useAuth } from "@/hooks/use-auth";
import { useSaveProspect, useMembers } from "@/hooks/use-data";
import type { ProspectInput } from "@/lib/api";
import { PROSPECT_STATUSES, LANGUAGES, type Prospect, type ProspectStatus } from "@/lib/types";
import { Button, Field, Input, Select, Textarea } from "@/components/ui";
import { instagramUrlFromUsername, slugifyUsername, todayISO } from "@/lib/utils";

export function ProspectForm({
  prospect,
  onDone,
  onCancel,
}: {
  prospect?: Prospect | null;
  onDone: () => void;
  onCancel: () => void;
}) {
  const { t } = useI18n();
  const { profile, isAdmin } = useAuth();
  const errorText = useErrorText();
  const save = useSaveProspect();
  const membersQuery = useMembers();

  const [form, setForm] = useState<ProspectInput>({
    name: prospect?.name ?? "",
    instagram_username: prospect?.instagram_username ?? "",
    instagram_url: prospect?.instagram_url ?? "",
    country: prospect?.country ?? "",
    language: prospect?.language ?? "fr",
    niche: prospect?.niche ?? "",
    assigned_user_id: prospect?.assigned_user_id ?? profile?.id ?? "",
    status: prospect?.status ?? "to_contact",
    first_contacted_at: prospect?.first_contacted_at ?? todayISO(),
    last_contacted_at: prospect?.last_contacted_at ?? null,
    next_followup_at: prospect?.next_followup_at ?? null,
    estimated_value: prospect?.estimated_value ?? null,
    notes: prospect?.notes ?? "",
  });
  const [error, setError] = useState<string | null>(null);

  const update = <K extends keyof ProspectInput>(key: K, value: ProspectInput[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const submit = async () => {
    setError(null);
    if (!form.name.trim()) return setError(t("errors.required"));
    const username = slugifyUsername(form.instagram_username);
    if (!username) return setError(t("errors.required"));
    if (form.estimated_value !== null && form.estimated_value < 0) return setError(t("errors.positive"));
    if (!form.assigned_user_id) return setError(t("errors.required"));

    try {
      await save.mutateAsync({
        id: prospect?.id,
        input: {
          ...form,
          name: form.name.trim(),
          instagram_username: username,
          instagram_url: form.instagram_url?.trim() || instagramUrlFromUsername(username),
          country: form.country?.trim() || null,
          niche: form.niche?.trim() || null,
          language: form.language || null,
          notes: form.notes?.trim() || null,
          first_contacted_at: form.first_contacted_at || null,
          last_contacted_at: form.last_contacted_at || null,
          next_followup_at: form.next_followup_at || null,
          estimated_value: form.estimated_value === null || Number.isNaN(form.estimated_value) ? null : form.estimated_value,
        },
      });
      onDone();
    } catch (caught) {
      setError(errorText(caught));
    }
  };

  return (
    <form
      className="space-y-3"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
      noValidate
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={t("common.name")} htmlFor="p-name">
          <Input id="p-name" value={form.name} onChange={(event) => update("name", event.target.value)} placeholder="Coach Karim" autoFocus />
        </Field>
        <Field label={t("prospects.instagramUsername")} htmlFor="p-username">
          <Input
            id="p-username"
            value={form.instagram_username}
            onChange={(event) => update("instagram_username", event.target.value)}
            placeholder="coach.karim"
            autoCapitalize="none"
          />
        </Field>
        <Field label={t("prospects.niche")} htmlFor="p-niche">
          <Input id="p-niche" value={form.niche ?? ""} onChange={(event) => update("niche", event.target.value)} placeholder="Coach sportif" />
        </Field>
        <Field label={t("prospects.country")} htmlFor="p-country">
          <Input id="p-country" value={form.country ?? ""} onChange={(event) => update("country", event.target.value)} placeholder="France" />
        </Field>
        <Field label={t("prospects.language")} htmlFor="p-language">
          <Select id="p-language" value={form.language ?? "fr"} onChange={(event) => update("language", event.target.value)}>
            {LANGUAGES.map((language) => (
              <option key={language.code} value={language.code}>
                {language.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t("common.status")} htmlFor="p-status">
          <Select
            id="p-status"
            value={form.status}
            onChange={(event) => update("status", event.target.value as ProspectStatus)}
          >
            {PROSPECT_STATUSES.map((status) => (
              <option key={status} value={status}>
                {t(`status.${status}`)}
              </option>
            ))}
          </Select>
        </Field>

        {isAdmin ? (
          <Field label={t("prospects.assigned")} htmlFor="p-assigned" className="sm:col-span-2">
            <Select
              id="p-assigned"
              value={form.assigned_user_id}
              onChange={(event) => update("assigned_user_id", event.target.value)}
            >
              {(membersQuery.data ?? []).map((member) => (
                <option key={member.id} value={member.id}>
                  {member.display_name}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}

        <Field label={t("prospects.firstContact")} htmlFor="p-first">
          <Input
            id="p-first"
            type="date"
            value={form.first_contacted_at ?? ""}
            onChange={(event) => update("first_contacted_at", event.target.value || null)}
          />
        </Field>
        <Field label={t("prospects.lastContact")} htmlFor="p-last">
          <Input
            id="p-last"
            type="date"
            value={form.last_contacted_at ?? ""}
            onChange={(event) => update("last_contacted_at", event.target.value || null)}
          />
        </Field>
        <Field label={t("prospects.nextFollowup")} htmlFor="p-followup">
          <Input
            id="p-followup"
            type="date"
            value={form.next_followup_at ?? ""}
            onChange={(event) => update("next_followup_at", event.target.value || null)}
          />
        </Field>
        <Field label={t("prospects.estimatedValue")} htmlFor="p-value" hint="€">
          <Input
            id="p-value"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            value={form.estimated_value ?? ""}
            onChange={(event) =>
              update("estimated_value", event.target.value === "" ? null : Number(event.target.value))
            }
            placeholder="59.99"
          />
        </Field>
      </div>

      <Field label={t("common.notes")} htmlFor="p-notes" hint={t("common.optional")}>
        <Textarea id="p-notes" rows={3} value={form.notes ?? ""} onChange={(event) => update("notes", event.target.value)} />
      </Field>

      {error ? (
        <p className="rounded-lg border border-danger/25 bg-danger/10 px-3 py-2 text-[12px] text-danger">{error}</p>
      ) : null}

      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="ghost" size="sm" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" variant="primary" size="sm" loading={save.isPending}>
          {t("common.save")}
        </Button>
      </div>
    </form>
  );
}
