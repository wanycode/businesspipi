import { useEffect, useMemo, useState } from "react";
import { Check, Minus, Plus } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { useSaveActivity } from "@/hooks/use-data";
import { useToast } from "@/components/ui/toast";
import { Button, Field, Input, Textarea } from "@/components/ui";
import { cn, todayISO } from "@/lib/utils";
import type { DailyActivity } from "@/lib/types";

interface FormState {
  date: string;
  dms: number;
  replies: number;
  interested: number;
  followups: number;
  meetings: number;
  sales: number;
  notes: string;
}

const emptyState = (date: string): FormState => ({
  date,
  dms: 0,
  replies: 0,
  interested: 0,
  followups: 0,
  meetings: 0,
  sales: 0,
  notes: "",
});

function fromActivity(activity: DailyActivity): FormState {
  return {
    date: activity.activity_date,
    dms: activity.dms_sent,
    replies: activity.replies_received,
    interested: activity.interested_prospects,
    followups: activity.followups_sent,
    meetings: activity.meetings_booked,
    sales: activity.sales_closed,
    notes: activity.notes ?? "",
  };
}

function Counter({
  label,
  value,
  onChange,
  max,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  max?: number;
}) {
  const clamp = (next: number) => {
    const numeric = Number.isFinite(next) ? Math.round(next) : 0;
    return Math.max(0, Math.min(max ?? 9999, numeric));
  };
  return (
    <div className="rounded-lg border border-line bg-surface-2 px-2.5 py-2">
      <p className="mb-1.5 text-[11px] font-medium text-muted">{label}</p>
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => onChange(clamp(value - 1))}
          className="flex size-7 shrink-0 items-center justify-center rounded-md border border-line-strong text-muted transition-colors hover:bg-surface-3 hover:text-fg active:scale-95"
          aria-label={`${label} -1`}
        >
          <Minus className="size-3" />
        </button>
        <input
          type="number"
          inputMode="numeric"
          min={0}
          max={max}
          value={value}
          onChange={(event) => onChange(clamp(Number(event.target.value)))}
          onFocus={(event) => event.currentTarget.select()}
          className="num h-7 w-full min-w-0 rounded-md border border-transparent bg-transparent text-center text-[15px] font-semibold text-fg outline-none focus:border-brand-500/50 focus:bg-surface"
          aria-label={label}
        />
        <button
          type="button"
          onClick={() => onChange(clamp(value + 1))}
          className="flex size-7 shrink-0 items-center justify-center rounded-md border border-line-strong text-muted transition-colors hover:bg-surface-3 hover:text-fg active:scale-95"
          aria-label={`${label} +1`}
        >
          <Plus className="size-3" />
        </button>
      </div>
    </div>
  );
}

export function ActivityForm({
  userId,
  activities,
  initialDate,
  onSaved,
  compact,
}: {
  userId: string;
  activities: DailyActivity[];
  initialDate?: string;
  onSaved?: () => void;
  compact?: boolean;
}) {
  const { t, lang } = useI18n();
  const errorText = useErrorText();
  const toast = useToast();
  const save = useSaveActivity();

  const [state, setState] = useState<FormState>(() => emptyState(initialDate ?? todayISO()));
  const [error, setError] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState(false);

  const existing = useMemo(
    () => activities.find((row) => row.activity_date === state.date),
    [activities, state.date],
  );

  useEffect(() => {
    const found = activities.find((row) => row.activity_date === state.date);
    setState((current) => (found ? fromActivity(found) : { ...current, dms: 0, replies: 0, interested: 0, followups: 0, meetings: 0, sales: 0, notes: "" }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.date, activities.length]);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setState((current) => ({ ...current, [key]: value }));
    setJustSaved(false);
    setError(null);
  };

  const submit = async () => {
    setError(null);
    if (state.replies > state.dms + state.followups) return setError(t("errors.repliesTooMany"));
    if (state.interested > state.replies) return setError(t("errors.interestedTooMany"));
    if (state.date > todayISO()) return setError(t("errors.noFuture"));

    try {
      await save.mutateAsync({
        userId,
        activityDate: state.date,
        dmsSent: state.dms,
        repliesReceived: state.replies,
        interestedProspects: state.interested,
        followupsSent: state.followups,
        meetingsBooked: state.meetings,
        salesClosed: state.sales,
        notes: state.notes.trim() || null,
      });
      setJustSaved(true);
      toast.success(t("dash.activitySaved"), t("common.saved"));
      onSaved?.();
    } catch (caught) {
      setError(errorText(caught));
    }
  };

  return (
    <form
      className="space-y-3"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
      noValidate
    >
      <div className={cn("grid gap-2.5", compact ? "grid-cols-2" : "grid-cols-2 sm:grid-cols-3")}>
        <Field label={t("common.date")} htmlFor="activity-date" className="col-span-2 sm:col-span-3">
          <Input
            id="activity-date"
            type="date"
            value={state.date}
            max={todayISO()}
            onChange={(event) => update("date", event.target.value || todayISO())}
            className="max-w-[180px]"
          />
        </Field>

        <Counter label={t("dash.dmsSent")} value={state.dms} onChange={(value) => update("dms", value)} />
        <Counter label={t("dash.repliesReceived")} value={state.replies} onChange={(value) => update("replies", value)} max={state.dms + state.followups} />
        <Counter label={t("dash.interested")} value={state.interested} onChange={(value) => update("interested", value)} max={state.replies} />
        <Counter label={t("dash.followups")} value={state.followups} onChange={(value) => update("followups", value)} />
        <Counter label={t("dash.meetingsBooked")} value={state.meetings} onChange={(value) => update("meetings", value)} />
        <Counter label={t("dash.salesClosed")} value={state.sales} onChange={(value) => update("sales", value)} />
      </div>

      <Field label={t("common.notes")} htmlFor="activity-notes" hint={t("common.optional")}>
        <Textarea
          id="activity-notes"
          value={state.notes}
          onChange={(event) => update("notes", event.target.value)}
          placeholder={t("dash.notesPlaceholder")}
          rows={2}
        />
      </Field>

      {error ? (
        <p className="rounded-lg border border-danger/25 bg-danger/10 px-3 py-2 text-[12px] text-danger">{error}</p>
      ) : null}

      <div className="flex items-center justify-between gap-3">
        <p className="text-[11px] text-faint">
          {existing
            ? t("dash.activityFormHint")
            : t("dash.activityForm", {
                date: new Intl.DateTimeFormat(lang === "fr" ? "fr-FR" : "en-GB", {
                  day: "numeric",
                  month: "long",
                }).format(new Date(`${state.date}T12:00:00`)),
              })}
        </p>
        <Button type="submit" variant="primary" size="sm" loading={save.isPending} disabled={justSaved && Boolean(existing)}>
          {justSaved ? <Check className="size-3.5" /> : null}
          {justSaved ? t("common.saved") : t("dash.saveActivity")}
        </Button>
      </div>
    </form>
  );
}
