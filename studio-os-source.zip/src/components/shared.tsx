import type { ReactNode } from "react";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import { cn, formatMoney, formatNumber, formatPercent, type Lang } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";
import type { ProspectStatus } from "@/lib/types";
import { Badge, Input, Segmented, Skeleton } from "@/components/ui";

export function Stat({
  label,
  value,
  hint,
  icon,
  trend,
  tone = "neutral",
  loading,
  className,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  trend?: number | null;
  tone?: "neutral" | "positive" | "warning";
  loading?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("rounded-xl border border-line bg-surface p-4", className)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] font-medium uppercase tracking-wide text-faint">{label}</p>
        {icon ? <span className="text-faint">{icon}</span> : null}
      </div>
      {loading ? (
        <Skeleton className="mt-2 h-6 w-16" />
      ) : (
        <p
          className={cn(
            "num mt-1.5 text-[22px] font-semibold leading-none tracking-tight",
            tone === "positive" && "text-positive",
            tone === "warning" && "text-warning",
            tone === "neutral" && "text-fg",
          )}
        >
          {value}
        </p>
      )}
      <div className="mt-1.5 flex min-h-4 items-center gap-1.5">
        {typeof trend === "number" && Number.isFinite(trend) ? (
          <span
            className={cn(
              "inline-flex items-center gap-0.5 text-[11px] font-medium",
              trend > 0 ? "text-positive" : trend < 0 ? "text-danger" : "text-faint",
            )}
          >
            {trend > 0 ? (
              <ArrowUpRight className="size-3" />
            ) : trend < 0 ? (
              <ArrowDownRight className="size-3" />
            ) : (
              <Minus className="size-3" />
            )}
            {formatPercent(Math.abs(trend), "en")}
          </span>
        ) : null}
        {hint ? <span className="truncate text-[11px] text-muted">{hint}</span> : null}
      </div>
    </div>
  );
}

const statusTones: Record<ProspectStatus, "neutral" | "brand" | "positive" | "warning" | "danger" | "info"> = {
  to_contact: "neutral",
  contacted: "info",
  followup: "warning",
  replied: "brand",
  interested: "brand",
  negotiating: "warning",
  won: "positive",
  lost: "danger",
};

export function ProspectStatusBadge({ status }: { status: ProspectStatus }) {
  const { t } = useI18n();
  return (
    <Badge tone={statusTones[status]} dot>
      {t(`status.${status}`)}
    </Badge>
  );
}

export function ActivityStatusBadge({
  status,
}: {
  status: "on_target" | "behind" | "none" | "inactive";
}) {
  const { t } = useI18n();
  const map = {
    on_target: { tone: "positive" as const, label: t("overview.statusOnTarget") },
    behind: { tone: "warning" as const, label: t("overview.statusBehind") },
    none: { tone: "neutral" as const, label: t("overview.statusNone") },
    inactive: { tone: "danger" as const, label: t("overview.statusInactive") },
  };
  return (
    <Badge tone={map[status].tone} dot>
      {map[status].label}
    </Badge>
  );
}

export type PeriodPreset = "today" | "week" | "month" | "custom";

export interface Period {
  preset: PeriodPreset;
  from: string;
  to: string;
}

export function PeriodFilter({
  period,
  onChange,
  className,
}: {
  period: Period;
  onChange: (period: Period) => void;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <Segmented
        value={period.preset}
        onChange={(preset) => onChange({ ...period, preset })}
        options={[
          { value: "today", label: t("common.today") },
          { value: "week", label: t("common.week") },
          { value: "month", label: t("common.month") },
          { value: "custom", label: t("overview.custom") },
        ]}
      />
      {period.preset === "custom" ? (
        <div className="flex items-center gap-1.5">
          <Input
            type="date"
            value={period.from}
            max={period.to}
            onChange={(event) => onChange({ ...period, from: event.target.value })}
            className="h-8 w-[140px] text-xs"
            aria-label={t("common.from")}
          />
          <span className="text-xs text-faint">→</span>
          <Input
            type="date"
            value={period.to}
            min={period.from}
            onChange={(event) => onChange({ ...period, to: event.target.value })}
            className="h-8 w-[140px] text-xs"
            aria-label={t("common.to")}
          />
        </div>
      ) : null}
    </div>
  );
}

export function MetricInline({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "positive" | "danger" | "warning";
}) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-faint">{label}</p>
      <p
        className={cn(
          "num mt-0.5 text-sm font-semibold",
          tone === "positive" && "text-positive",
          tone === "danger" && "text-danger",
          tone === "warning" && "text-warning",
          tone === "neutral" && "text-fg",
        )}
      >
        {value}
      </p>
    </div>
  );
}

export function money(value: number, lang: Lang): string {
  return formatMoney(value, lang);
}

export function count(value: number, lang: Lang): string {
  return formatNumber(value, lang);
}
