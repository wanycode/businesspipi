import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Archive, ArchiveRestore, ExternalLink, Pencil, Plus, Trash2, Wallet } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { useAuth } from "@/hooks/use-auth";
import {
  useArchiveProspect,
  useDeleteProspect,
  useInteractions,
  useLogInteraction,
  useMembers,
  useSaveProspect,
} from "@/hooks/use-data";
import { toProspectInput } from "@/lib/api";
import { INTERACTION_TYPES, PROSPECT_STATUSES, type InteractionType, type Prospect, type ProspectStatus } from "@/lib/types";
import { Badge, Button, Field, Modal, Select, Textarea } from "@/components/ui";
import { ProspectStatusBadge } from "@/components/shared";
import { useToast } from "@/components/ui/toast";
import { formatDate, instagramUrlFromUsername, isOverdue, todayISO } from "@/lib/utils";

export function ProspectDetail({
  prospect,
  open,
  onClose,
  onEdit,
}: {
  prospect: Prospect | null;
  open: boolean;
  onClose: () => void;
  onEdit: () => void;
}) {
  const { t, lang } = useI18n();
  const errorText = useErrorText();
  const { profile, isAdmin } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const membersQuery = useMembers();
  const interactionsQuery = useInteractions(prospect ? [prospect.id] : []);
  const logInteraction = useLogInteraction();
  const saveProspect = useSaveProspect();
  const archiveProspect = useArchiveProspect();
  const deleteProspect = useDeleteProspect();

  const [type, setType] = useState<InteractionType>("dm");
  const [notes, setNotes] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const interactions = useMemo(() => interactionsQuery.data ?? [], [interactionsQuery.data]);

  if (!prospect) return null;

  const assignedName =
    membersQuery.data?.find((member) => member.id === prospect.assigned_user_id)?.display_name ??
    (prospect.assigned_user_id === profile?.id ? t("prospects.ownerYou") : "—");

  const addInteraction = async () => {
    setError(null);
    if (!profile) return;
    try {
      await logInteraction.mutateAsync({
        prospectId: prospect.id,
        userId: profile.id,
        type,
        notes: notes.trim() || null,
        date: new Date().toISOString(),
      });
      if (type !== "note") {
        await saveProspect.mutateAsync({
          id: prospect.id,
          input: {
            ...toProspectInput(prospect),
            last_contacted_at: todayISO(),
            first_contacted_at: prospect.first_contacted_at ?? todayISO(),
          },
        });
      }
      setNotes("");
      toast.success(t("prospects.interactionSaved"));
    } catch (caught) {
      setError(errorText(caught));
    }
  };

  const changeStatus = async (status: ProspectStatus) => {
    try {
      await saveProspect.mutateAsync({
        id: prospect.id,
        input: {
          ...toProspectInput(prospect),
          status,
          first_contacted_at: prospect.first_contacted_at ?? todayISO(),
        },
      });
      toast.success(t("prospects.updated"));
    } catch (caught) {
      setError(errorText(caught));
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={prospect.name} description={`@${prospect.instagram_username}`} size="lg">
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <ProspectStatusBadge status={prospect.status} />
          {isOverdue(prospect.next_followup_at) ? <Badge tone="danger">{t("prospects.overdue")}</Badge> : null}
          {prospect.archived_at ? <Badge tone="neutral">{t("prospects.archived")}</Badge> : null}
          {prospect.instagram_url || prospect.instagram_username ? (
            <a
              href={prospect.instagram_url || instagramUrlFromUsername(prospect.instagram_username)}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1 text-[11px] text-brand-400 hover:underline"
            >
              {t("prospects.viewProfile")}
              <ExternalLink className="size-3" />
            </a>
          ) : null}
        </div>

        <div className="grid grid-cols-2 gap-3 rounded-lg border border-line bg-surface-2 p-3 text-[12px] sm:grid-cols-4">
          <Info label={t("prospects.niche")} value={prospect.niche || "—"} />
          <Info label={t("prospects.country")} value={prospect.country || "—"} />
          <Info label={t("prospects.language")} value={prospect.language?.toUpperCase() || "—"} />
          <Info label={t("prospects.assigned")} value={assignedName} />
          <Info label={t("prospects.firstContact")} value={formatDate(prospect.first_contacted_at, lang)} />
          <Info label={t("prospects.lastContact")} value={formatDate(prospect.last_contacted_at, lang)} />
          <Info label={t("prospects.nextFollowup")} value={formatDate(prospect.next_followup_at, lang)} />
          <Info
            label={t("prospects.estimatedValue")}
            value={prospect.estimated_value != null ? `${prospect.estimated_value.toFixed(2)} €` : "—"}
          />
        </div>

        {prospect.notes ? (
          <div>
            <p className="mb-1 text-[10px] uppercase tracking-wide text-faint">{t("common.notes")}</p>
            <p className="whitespace-pre-wrap rounded-lg border border-line bg-surface-2 px-3 py-2 text-[12px] leading-relaxed text-muted">
              {prospect.notes}
            </p>
          </div>
        ) : null}

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" size="sm" onClick={onEdit}>
            <Pencil className="size-3" />
            {t("common.edit")}
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => navigate(`/ventes?prospect=${prospect.id}`)}
            disabled={prospect.archived_at !== null}
          >
            <Wallet className="size-3" />
            {t("prospects.convertToDeal")}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={async () => {
              try {
                await archiveProspect.mutateAsync({ id: prospect.id, archived: !prospect.archived_at });
                toast.success(prospect.archived_at ? t("prospects.archivedTitle") : t("common.archive"));
                onClose();
              } catch (caught) {
                toast.error(errorText(caught));
              }
            }}
          >
            {prospect.archived_at ? <ArchiveRestore className="size-3" /> : <Archive className="size-3" />}
            {prospect.archived_at ? t("common.restore") : t("common.archive")}
          </Button>
          {isAdmin ? (
            <Button variant="danger" size="sm" onClick={() => setConfirmDelete(true)}>
              <Trash2 className="size-3" />
              {t("common.delete")}
            </Button>
          ) : null}
        </div>

        <div className="rounded-lg border border-line">
          <div className="border-b border-line px-3 py-2">
            <p className="text-[11px] font-medium text-fg">{t("prospects.interactions")}</p>
            <p className="text-[10px] text-faint">{t("prospects.interactionHint")}</p>
          </div>
          <div className="max-h-56 space-y-2 overflow-y-auto px-3 py-2">
            {interactionsQuery.isLoading ? (
              <p className="text-[11px] text-faint">{t("common.loading")}</p>
            ) : interactions.length === 0 ? (
              <p className="text-[11px] text-faint">{t("prospects.noInteractions")}</p>
            ) : (
              interactions.map((item) => (
                <div key={item.id} className="flex items-start gap-2.5 border-b border-line/50 pb-2 last:border-0 last:pb-0">
                  <span className="mt-1 size-1.5 shrink-0 rounded-full bg-brand-400" />
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-fg">
                      {t(`interaction.${item.interaction_type}`)}
                      <span className="ml-2 font-normal text-faint">{formatDate(item.interaction_date.slice(0, 10), lang)}</span>
                    </p>
                    {item.notes ? <p className="text-[11px] leading-relaxed text-muted">{item.notes}</p> : null}
                  </div>
                </div>
              ))
            )}
          </div>
          <div className="space-y-2 border-t border-line px-3 py-2.5">
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-[160px_1fr]">
              <Field label={t("prospects.addInteraction")}>
                <Select value={type} onChange={(event) => setType(event.target.value as InteractionType)}>
                  {INTERACTION_TYPES.map((item) => (
                    <option key={item} value={item}>
                      {t(`interaction.${item}`)}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label={t("prospects.interactionNote")} hint={t("common.optional")}>
                <Textarea rows={1} value={notes} onChange={(event) => setNotes(event.target.value)} className="min-h-9" />
              </Field>
            </div>
            <div className="flex items-center justify-between gap-2">
              <Select
                value={prospect.status}
                onChange={(event) => void changeStatus(event.target.value as ProspectStatus)}
                className="h-8 max-w-[180px] text-[11px]"
                aria-label={t("common.status")}
              >
                {PROSPECT_STATUSES.map((status) => (
                  <option key={status} value={status}>
                    {t(`status.${status}`)}
                  </option>
                ))}
              </Select>
              <Button variant="secondary" size="sm" onClick={() => void addInteraction()} loading={logInteraction.isPending}>
                <Plus className="size-3" />
                {t("common.add")}
              </Button>
            </div>
            {error ? <p className="text-[11px] text-danger">{error}</p> : null}
          </div>
        </div>
      </div>

      <Modal
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        title={t("prospects.deleteTitle")}
        description={t("prospects.deleteBody")}
        size="sm"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(false)}>
              {t("common.cancel")}
            </Button>
            <Button
              variant="danger"
              size="sm"
              loading={deleteProspect.isPending}
              onClick={async () => {
                try {
                  await deleteProspect.mutateAsync(prospect.id);
                  setConfirmDelete(false);
                  onClose();
                } catch (caught) {
                  toast.error(errorText(caught));
                }
              }}
            >
              {t("common.delete")}
            </Button>
          </>
        }
      >
        <p className="text-xs text-muted">{t("prospects.deleteBody")}</p>
      </Modal>
    </Modal>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <p className="text-[10px] uppercase tracking-wide text-faint">{label}</p>
      <p className="mt-0.5 truncate text-[12px] text-fg">{value}</p>
    </div>
  );
}
