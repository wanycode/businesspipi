import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { addDays } from "date-fns";
import { Handshake, MessageCircle, MousePointerClick, Target, TrendingUp, Users, Wallet } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useActivities, useDeals, useMembers, useProspects } from "@/hooks/use-data";
import { activitiesInRange, computeMemberStats, dailySeries, revenueSeries, teamTotals, totals } from "@/lib/stats";
import {
  formatDate,
  formatDayLabel,
  formatMoney,
  formatPercent,
  toISODate,
  todayISO,
} from "@/lib/utils";
import { ChartCard, CHART_COLORS, GroupedBarChart, MultiLineChart, RevenueBarChart, TrendAreaChart } from "@/components/charts";
import { Avatar, Card, CardHeader, EmptyState, Skeleton } from "@/components/ui";
import { ActivityStatusBadge, PeriodFilter, Stat, type Period } from "@/components/shared";
import { useAuth } from "@/hooks/use-auth";

export function AdminOverview() {
  const { t, lang } = useI18n();
  const { profile } = useAuth();
  const activitiesQuery = useActivities();
  const membersQuery = useMembers();
  const prospectsQuery = useProspects();
  const dealsQuery = useDeals();

  const today = todayISO();
  const [period, setPeriod] = useState<Period>({ preset: "month", from: toISODate(addDays(new Date(), -29)), to: today });

  const activities = activitiesQuery.data ?? [];
  const members = membersQuery.data ?? [];
  const prospects = prospectsQuery.data ?? [];
  const deals = dealsQuery.data ?? [];

  const range = useMemo(() => {
    if (period.preset === "today") return { from: today, to: today };
    if (period.preset === "week") return { from: toISODate(addDays(new Date(), -6)), to: today };
    if (period.preset === "month") return { from: toISODate(addDays(new Date(), -29)), to: today };
    return { from: period.from, to: period.to };
  }, [period, today]);

  const weekFrom = toISODate(addDays(new Date(), -6));
  const monthFrom = toISODate(addDays(new Date(), -29));

  const kpis = useMemo(
    () => ({
      today: activitiesInRange(activities, today, today).reduce((sum, row) => sum + row.dms_sent, 0),
      week: activitiesInRange(activities, weekFrom, today).reduce((sum, row) => sum + row.dms_sent, 0),
      month: activitiesInRange(activities, monthFrom, today).reduce((sum, row) => sum + row.dms_sent, 0),
    }),
    [activities, today, weekFrom, monthFrom],
  );

  const scoped = useMemo(
    () => teamTotals({ activities, deals, prospects, from: range.from, to: range.to }),
    [activities, deals, prospects, range],
  );

  const memberStats = useMemo(
    () =>
      members.map((member) => {
        const scopedRows = activitiesInRange(activities, range.from, range.to).filter(
          (row) => row.user_id === member.id,
        );
        const scopedMemberTotals = totals(scopedRows);
        return {
          member,
          stats: computeMemberStats({
            userId: member.id,
            activities,
            deals,
            prospects,
            target: member.daily_dm_target,
            commissionRate: member.commission_rate,
            isActive: member.is_active,
          }),
          periodDms: scopedMemberTotals.dms,
          periodReplies: scopedMemberTotals.replies,
          periodInterested: scopedMemberTotals.interested,
        };
      }),
    [members, activities, deals, prospects, range],
  );

  const series = useMemo(
    () => dailySeries(activities, range.from, range.to),
    [activities, range],
  );

  const chartSeries = useMemo(
    () => series.map((row) => ({ label: formatDayLabel(row.date, lang), ...row })),
    [series, lang],
  );

  const memberBars = useMemo(
    () =>
      memberStats.map(({ member, periodDms, periodReplies }) => ({
        label: member.display_name.split(" ")[0] ?? member.display_name,
        dms: periodDms,
        replies: periodReplies,
      })),
    [memberStats],
  );

  const leadBars = useMemo(
    () =>
      memberStats.map(({ member }) => ({
        label: member.display_name.split(" ")[0] ?? member.display_name,
        leads: prospects.filter(
          (prospect) =>
            prospect.assigned_user_id === member.id &&
            !prospect.archived_at &&
            ["contacted", "followup", "replied", "interested", "negotiating"].includes(prospect.status),
        ).length,
        clients: prospects.filter(
          (prospect) => prospect.assigned_user_id === member.id && prospect.status === "won",
        ).length,
      })),
    [memberStats, prospects],
  );

  const revenueData = useMemo(
    () =>
      revenueSeries(deals, range.from, range.to).map((row) => ({
        label: formatDayLabel(row.label, lang),
        value: row.value,
      })),
    [deals, range, lang],
  );

  const loading = activitiesQuery.isLoading || membersQuery.isLoading;
  const activeMembers = members.filter((member) => member.is_active);

  if (membersQuery.isSuccess && activeMembers.length === 0) {
    return (
      <Card>
        <EmptyState
          icon={<Users className="size-4" />}
          title={t("overview.noMembers")}
          description={t("overview.noMembersBody")}
          action={
            <Link
              to="/equipe"
              className="inline-flex h-8 items-center rounded-md bg-brand-500 px-3 text-xs font-medium text-white hover:bg-brand-600"
            >
              {t("nav.team")}
            </Link>
          }
        />
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">{t("overview.title")}</h1>
          <p className="mt-0.5 text-[13px] text-muted">
            {t("overview.subtitle")}{" "}
            <span className="text-faint">
              · {t("overview.teamOf", { n: activeMembers.length || members.length })}
            </span>
          </p>
        </div>
        <PeriodFilter
          period={period}
          onChange={(next) =>
            setPeriod(
              next.preset === "custom" && (!next.from || !next.to) ? { ...next, from: range.from, to: range.to } : next,
            )
          }
        />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("overview.dmsToday")} value={kpis.today} loading={loading} icon={<MousePointerClick className="size-3.5" />} />
        <Stat label={t("overview.dmsWeek")} value={kpis.week} loading={loading} icon={<MousePointerClick className="size-3.5" />} />
        <Stat label={t("overview.dmsMonth")} value={kpis.month} loading={loading} icon={<Target className="size-3.5" />} />
        <Stat
          label={t("overview.activeLeads")}
          value={scoped.activeLeads}
          loading={loading}
          icon={<Users className="size-3.5" />}
          hint={`${t("common.period")}`}
        />
        <Stat label={t("overview.replies")} value={scoped.replies} loading={loading} icon={<MessageCircle className="size-3.5" />} />
        <Stat
          label={t("overview.interested")}
          value={scoped.interested}
          loading={loading}
          tone="positive"
          icon={<TrendingUp className="size-3.5" />}
        />
        <Stat
          label={t("overview.clients")}
          value={scoped.clients}
          loading={loading}
          tone="positive"
          icon={<Handshake className="size-3.5" />}
        />
        <Stat
          label={t("overview.revenue")}
          value={formatMoney(scoped.revenue, lang)}
          loading={loading}
          icon={<Wallet className="size-3.5" />}
          hint={`${t("overview.signedValue")} · ${formatMoney(scoped.signedValue, lang)}`}
        />
      </div>

      <Card className="overflow-hidden">
        <CardHeader title={t("overview.teamTable")} subtitle={`${formatDate(range.from, lang)} → ${formatDate(range.to, lang)}`} />
        {loading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2].map((index) => (
              <Skeleton key={index} className="h-10 w-full" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1040px] text-left text-[12px]">
              <thead>
                <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                  <th className="sticky left-0 z-10 bg-surface px-4 py-2 font-medium">{t("overview.member")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.todayDms")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.target")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.weekDms")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.monthDms")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.replies")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.interested")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.conversion")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.sales")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("overview.revenue")}</th>
                  <th className="px-2 py-2 font-medium">{t("overview.lastActivity")}</th>
                  <th className="px-4 py-2 font-medium">{t("common.status")}</th>
                </tr>
              </thead>
              <tbody>
                {memberStats.map(({ member, stats, periodReplies, periodInterested }) => (
                  <tr key={member.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                    <td className="sticky left-0 z-10 bg-surface px-4 py-2">
                      <div className="flex items-center gap-2">
                        <Avatar name={member.display_name} />
                        <div className="min-w-0">
                          <p className="truncate text-[12px] font-medium text-fg">
                            {member.display_name}
                            {member.id === profile?.id ? (
                              <span className="ml-1.5 text-[10px] text-faint">({t("team.you")})</span>
                            ) : null}
                          </p>
                          <p className="truncate text-[10px] text-faint">{member.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="num px-2 py-2 text-right font-medium">{stats.dmsToday}</td>
                    <td className="num px-2 py-2 text-right text-muted">{stats.target}</td>
                    <td className="num px-2 py-2 text-right text-muted">{stats.dmsWeek}</td>
                    <td className="num px-2 py-2 text-right text-muted">{stats.dmsMonth}</td>
                    <td className="num px-2 py-2 text-right text-muted">{periodReplies}</td>
                    <td className="num px-2 py-2 text-right text-muted">{periodInterested}</td>
                    <td className="num px-2 py-2 text-right text-muted">{formatPercent(stats.conversion, lang)}</td>
                    <td className="num px-2 py-2 text-right text-muted">{stats.dealsWon}</td>
                    <td className="num px-2 py-2 text-right text-muted">{formatMoney(stats.revenue, lang)}</td>
                    <td className="px-2 py-2 text-muted">
                      {stats.lastActivityDate ? formatDate(stats.lastActivityDate, lang) : t("common.never")}
                    </td>
                    <td className="px-4 py-2">
                      <ActivityStatusBadge status={stats.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <div className="grid gap-3 lg:grid-cols-2">
        <ChartCard
          title={t("overview.chartDms")}
          subtitle={`${formatDate(range.from, lang)} → ${formatDate(range.to, lang)}`}
          empty={series.every((row) => row.dms === 0)}
        >
          <TrendAreaChart data={chartSeries.map((row) => ({ label: row.label, value: row.dms }))} label={t("overview.dms")} />
        </ChartCard>

        <ChartCard
          title={t("overview.chartFunnel")}
          subtitle={t("overview.last30")}
          empty={series.every((row) => row.replies === 0 && row.interested === 0)}
        >
          <MultiLineChart
            data={chartSeries.map((row) => ({ label: row.label, replies: row.replies, interested: row.interested }))}
            series={[
              { key: "replies", name: t("overview.replies"), color: CHART_COLORS.info },
              { key: "interested", name: t("overview.interested"), color: CHART_COLORS.positive },
            ]}
          />
        </ChartCard>

        <ChartCard title={t("overview.chartMembers")} empty={memberBars.length === 0}>
          <GroupedBarChart
            data={memberBars}
            series={[
              { key: "dms", name: t("overview.dms"), color: CHART_COLORS.brand },
              { key: "replies", name: t("overview.replies"), color: CHART_COLORS.info },
            ]}
          />
        </ChartCard>

        <ChartCard title={t("overview.chartLeads")} empty={leadBars.length === 0}>
          <GroupedBarChart
            data={leadBars}
            series={[
              { key: "leads", name: t("overview.leads"), color: CHART_COLORS.warning },
              { key: "clients", name: t("overview.won"), color: CHART_COLORS.positive },
            ]}
          />
        </ChartCard>

        <ChartCard
          title={t("overview.chartRevenue")}
          subtitle={`${t("overview.revenue")} · ${formatMoney(scoped.revenue, lang)}`}
          className="lg:col-span-2"
          empty={revenueData.every((row) => row.value === 0)}
        >
          <RevenueBarChart data={revenueData} label={t("overview.revenue")} lang={lang} />
        </ChartCard>
      </div>
    </div>
  );
}
