import { useMemo, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { useAuth } from "@/hooks/use-auth";
import { useMembers, usePricing, useProspects, useSaveDeal, useStudioSettings } from "@/hooks/use-data";
import { updateProspect } from "@/lib/api";
import type { DealInput } from "@/lib/api";
import { DEAL_STATUSES, PACKAGE_CODES, PAYMENT_STATUSES, type Deal, type DealStatus, type PackageCode, type PaymentStatus } from "@/lib/types";
import { Button, Field, Input, Select, Textarea, Switch } from "@/components/ui";
import { formatMoney, todayISO } from "@/lib/utils";

export function DealForm({
  deal,
  presetProspectId,
  onDone,
  onCancel,
}: {
  deal?: Deal | null;
  presetProspectId?: string | null;
  onDone: () => void;
  onCancel: () => void;
}) {
  const { t, lang } = useI18n();
  const { profile, isAdmin } = useAuth();
  const errorText = useErrorText();
  const save = useSaveDeal();
  const membersQuery = useMembers();
  const pricingQuery = usePricing();
  const prospectsQuery = useProspects();
  const studioQuery = useStudioSettings();

  const pricing = pricingQuery.data ?? [];
  const maintenancePrice = studioQuery.data?.maintenance_price ?? 9.99;
  const presetProspect = prospectsQuery.data?.find((row) => row.id === presetProspectId) ?? null;
  const defaultPackage: PackageCode = "PRO";
  const defaultPrice = pricing.find((row) => row.code === defaultPackage)?.price ?? 59.99;

  const [form, setForm] = useState<DealInput>(() => ({
    prospect_id: deal?.prospect_id ?? presetProspectId ?? null,
    client_name: deal?.client_name ?? presetProspect?.name ?? "",
    assigned_user_id: deal?.assigned_user_id ?? presetProspect?.assigned_user_id ?? profile?.id ?? "",
    package: deal?.package ?? defaultPackage,
    deal_amount: deal?.deal_amount ?? presetProspect?.estimated_value ?? defaultPrice,
    deal_status: deal?.deal_status ?? "won",
    payment_status: deal?.payment_status ?? "paid",
    amount_paid: deal?.amount_paid ?? presetProspect?.estimated_value ?? defaultPrice,
    maintenance_active: deal?.maintenance_active ?? false,
    won_at: deal?.won_at ?? todayISO(),
    notes: deal?.notes ?? "",
  }));
  const [error, setError] = useState<string | null>(null);

  const packageOptions = useMemo(
    () => PACKAGE_CODES.map((code) => ({ code, price: pricing.find((row) => row.code === code)?.price })),
    [pricing],
  );

  const update = <K extends keyof DealInput>(key: K, value: DealInput[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const applyPackage = (code: PackageCode) => {
    const price = pricing.find((row) => row.code === code)?.price;
    setForm((current) => ({
      ...current,
      package: code,
      deal_amount: price ?? current.deal_amount,
      amount_paid:
        current.payment_status === "paid" ? (price ?? current.amount_paid) : current.payment_status === "unpaid" ? 0 : current.amount_paid,
    }));
  };

  const applyPayment = (status: PaymentStatus) => {
    setForm((current) => ({
      ...current,
      payment_status: status,
      amount_paid: status === "paid" ? current.deal_amount : status === "unpaid" ? 0 : current.amount_paid,
    }));
  };

  const submit = async () => {
    setError(null);
    if (!form.client_name.trim()) return setError(t("errors.required"));
    if (!form.assigned_user_id) return setError(t("errors.required"));
    if (form.deal_amount < 0) return setError(t("errors.positive"));
    if (form.deal_status === "won" && !form.won_at) return setError(t("sales.wonDateRequired"));

    const payload: DealInput = {
      ...form,
      client_name: form.client_name.trim(),
      won_at: form.deal_status === "won" ? form.won_at ?? todayISO() : form.won_at,
      amount_paid: form.payment_status === "paid" ? form.deal_amount : form.payment_status === "unpaid" ? 0 : form.amount_paid,
      notes: form.notes?.trim() || null,
    };

    if (payload.payment_status === "partial" && (payload.amount_paid <= 0 || payload.amount_paid >= payload.deal_amount)) {
      return setError(t("sales.paidEqualsAmount"));
    }

    try {
      await save.mutateAsync({ id: deal?.id, input: payload });
      if (payload.deal_status === "won" && payload.prospect_id) {
        await updateProspect(payload.prospect_id, { status: "won" });
      }
      onDone();
    } catch (caught) {
      setError(errorText(caught));
    }
  };

  const won = form.deal_status === "won";

  return (
    <form
      className="space-y-3"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
      noValidate
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={t("sales.client")} htmlFor="d-client">
          <Input
            id="d-client"
            value={form.client_name}
            onChange={(event) => update("client_name", event.target.value)}
            placeholder="Coach Karim"
            autoFocus
          />
        </Field>

        <Field label={t("sales.linkedProspect")} htmlFor="d-prospect" hint={t("common.optional")}>
          <Select
            id="d-prospect"
            value={form.prospect_id ?? ""}
            onChange={(event) => {
              const id = event.target.value || null;
              const prospect = prospectsQuery.data?.find((row) => row.id === id);
              setForm((current) => ({
                ...current,
                prospect_id: id,
                client_name: current.client_name || prospect?.name || "",
                assigned_user_id: prospect?.assigned_user_id ?? current.assigned_user_id,
              }));
            }}
          >
            <option value="">{t("sales.noProspect")}</option>
            {(prospectsQuery.data ?? []).map((prospect) => (
              <option key={prospect.id} value={prospect.id}>
                {prospect.name} (@{prospect.instagram_username})
              </option>
            ))}
          </Select>
        </Field>

        <Field label={t("sales.package")} htmlFor="d-package">
          <Select id="d-package" value={form.package} onChange={(event) => applyPackage(event.target.value as PackageCode)}>
            {packageOptions.map((item) => (
              <option key={item.code} value={item.code}>
                {item.code}
                {item.price != null ? ` — ${formatMoney(item.price, lang)}` : ""}
              </option>
            ))}
          </Select>
        </Field>

        <Field label={t("sales.amount")} htmlFor="d-amount" hint="€">
          <Input
            id="d-amount"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            value={Number.isFinite(form.deal_amount) ? form.deal_amount : 0}
            onChange={(event) => {
              const amount = Number(event.target.value);
              setForm((current) => ({
                ...current,
                deal_amount: amount,
                amount_paid: current.payment_status === "paid" ? amount : current.amount_paid,
              }));
            }}
          />
        </Field>

        <Field label={t("sales.dealStatus")} htmlFor="d-status">
          <Select
            id="d-status"
            value={form.deal_status}
            onChange={(event) => {
              const next = event.target.value as DealStatus;
              setForm((current) => ({
                ...current,
                deal_status: next,
                won_at: next === "won" ? current.won_at ?? todayISO() : current.won_at,
              }));
            }}
          >
            {DEAL_STATUSES.map((status) => (
              <option key={status} value={status}>
                {status === "won" ? t("sales.dealWon") : status === "lost" ? t("sales.dealLost") : t("sales.dealProposed")}
              </option>
            ))}
          </Select>
        </Field>

        <Field label={t("sales.paymentStatus")} htmlFor="d-payment">
          <Select id="d-payment" value={form.payment_status} onChange={(event) => applyPayment(event.target.value as PaymentStatus)}>
            {PAYMENT_STATUSES.map((status) => (
              <option key={status} value={status}>
                {status === "paid" ? t("sales.paymentPaid") : status === "partial" ? t("sales.paymentPartial") : t("sales.paymentUnpaid")}
              </option>
            ))}
          </Select>
        </Field>

        <Field label={t("sales.amountPaid")} htmlFor="d-paid" hint="€">
          <Input
            id="d-paid"
            type="number"
            inputMode="decimal"
            min={0}
            max={form.deal_amount}
            step="0.01"
            value={form.payment_status === "paid" ? form.deal_amount : form.amount_paid}
            disabled={form.payment_status !== "partial"}
            onChange={(event) => update("amount_paid", Number(event.target.value))}
          />
        </Field>

        <Field label={t("sales.wonAt")} htmlFor="d-wonat">
          <Input
            id="d-wonat"
            type="date"
            value={form.won_at ?? ""}
            disabled={!won}
            onChange={(event) => update("won_at", event.target.value || null)}
          />
        </Field>

        {isAdmin ? (
          <Field label={t("prospects.assigned")} htmlFor="d-assigned">
            <Select id="d-assigned" value={form.assigned_user_id} onChange={(event) => update("assigned_user_id", event.target.value)}>
              {(membersQuery.data ?? []).map((member) => (
                <option key={member.id} value={member.id}>
                  {member.display_name}
                </option>
              ))}
            </Select>
          </Field>
        ) : null}

        <div className="sm:col-span-2">
          <div className="rounded-lg border border-line bg-surface-2 px-3 py-2.5">
            <Switch
              checked={form.maintenance_active}
              onChange={(value) => update("maintenance_active", value)}
              label={t("sales.maintenance")}
              description={t("sales.maintenancePrice", { price: formatMoney(maintenancePrice, lang) })}
            />
          </div>
        </div>
      </div>

      <Field label={t("common.notes")} htmlFor="d-notes" hint={t("common.optional")}>
        <Textarea id="d-notes" rows={2} value={form.notes ?? ""} onChange={(event) => update("notes", event.target.value)} />
      </Field>

      {error ? (
        <p className="rounded-lg border border-danger/25 bg-danger/10 px-3 py-2 text-[12px] text-danger">{error}</p>
      ) : null}

      <div className="flex justify-end gap-2 pt-1">
        <Button type="button" variant="ghost" size="sm" onClick={onCancel}>
          {t("common.cancel")}
        </Button>
        <Button type="submit" variant="primary" size="sm" loading={save.isPending}>
          {t("common.save")}
        </Button>
      </div>
    </form>
  );
}
