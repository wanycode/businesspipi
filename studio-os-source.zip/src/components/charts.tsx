import type { ReactNode } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardHeader, EmptyState } from "@/components/ui";
import { formatMoney, type Lang } from "@/lib/utils";

export const CHART_COLORS = {
  brand: "#6e56f8",
  brandSoft: "#9b84ff",
  positive: "#34d399",
  warning: "#f5b544",
  info: "#56a8f5",
  danger: "#f2555a",
  grid: "#1e1e26",
  axis: "#62626e",
};

const axisProps = {
  stroke: CHART_COLORS.axis,
  tick: { fill: CHART_COLORS.axis, fontSize: 10 },
  tickLine: false,
  axisLine: false,
} as const;

interface TooltipPayloadItem {
  name?: string;
  value?: number | string;
  color?: string;
  dataKey?: string | number;
}

function ChartTooltip({
  active,
  payload,
  label,
  moneyKeys = [],
  lang,
}: {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string | number;
  moneyKeys?: string[];
  lang: Lang;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-line-strong bg-surface-2/95 px-2.5 py-2 shadow-xl backdrop-blur">
      {label !== undefined ? (
        <p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-faint">{label}</p>
      ) : null}
      <div className="space-y-0.5">
        {payload.map((item, index) => {
          const isMoney = moneyKeys.includes(String(item.dataKey));
          const value = typeof item.value === "number" ? item.value : Number(item.value ?? 0);
          return (
            <div key={index} className="flex items-center justify-between gap-4 text-[11px]">
              <span className="flex items-center gap-1.5 text-muted">
                <span className="size-1.5 rounded-full" style={{ backgroundColor: item.color }} />
                {item.name}
              </span>
              <span className="num font-medium text-fg">
                {isMoney ? formatMoney(value, lang) : value}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ChartCard({
  title,
  subtitle,
  action,
  children,
  empty,
  height = 220,
  className,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  empty?: boolean;
  height?: number;
  className?: string;
}) {
  return (
    <Card className={`overflow-hidden ${className ?? ""}`}>
      <CardHeader title={title} subtitle={subtitle} action={action} />
      {empty ? (
        <EmptyState title="—" className="py-10" />
      ) : (
        <div className="px-1.5 py-3" style={{ height }}>
          {children}
        </div>
      )}
    </Card>
  );
}

export function TrendAreaChart({
  data,
  dataKey = "value",
  label,
  color = CHART_COLORS.brand,
}: {
  data: { label: string; value: number }[];
  dataKey?: string;
  label: string;
  color?: string;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 6, right: 12, bottom: 0, left: -18 }}>
        <defs>
          <linearGradient id={`grad-${dataKey}-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.32} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke={CHART_COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" minTickGap={18} />
        <YAxis {...axisProps} width={36} allowDecimals={false} />
        <Tooltip
          content={<ChartTooltip lang="fr" />}
          cursor={{ stroke: CHART_COLORS.brandSoft, strokeOpacity: 0.35 }}
        />
        <Area
          type="monotone"
          dataKey="value"
          name={label}
          stroke={color}
          strokeWidth={1.75}
          fill={`url(#grad-${dataKey}-${label})`}
          dot={false}
          activeDot={{ r: 3, strokeWidth: 0 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function MultiLineChart({
  data,
  series,
}: {
  data: Record<string, string | number>[];
  series: { key: string; name: string; color: string }[];
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 6, right: 12, bottom: 0, left: -18 }}>
        <CartesianGrid stroke={CHART_COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" minTickGap={18} />
        <YAxis {...axisProps} width={36} allowDecimals={false} />
        <Tooltip content={<ChartTooltip lang="fr" />} cursor={{ stroke: CHART_COLORS.brandSoft, strokeOpacity: 0.3 }} />
        <Legend
          verticalAlign="top"
          height={24}
          iconType="circle"
          iconSize={6}
          wrapperStyle={{ fontSize: 10, color: CHART_COLORS.axis }}
        />
        {series.map((item) => (
          <Line
            key={item.key}
            type="monotone"
            dataKey={item.key}
            name={item.name}
            stroke={item.color}
            strokeWidth={1.75}
            dot={false}
            activeDot={{ r: 3, strokeWidth: 0 }}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}

export function GroupedBarChart({
  data,
  series,
  stacked,
}: {
  data: Record<string, string | number>[];
  series: { key: string; name: string; color: string }[];
  stacked?: boolean;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 6, right: 12, bottom: 0, left: -18 }} barCategoryGap="22%">
        <CartesianGrid stroke={CHART_COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval={0} tick={{ fill: CHART_COLORS.axis, fontSize: 9 }} />
        <YAxis {...axisProps} width={36} allowDecimals={false} />
        <Tooltip content={<ChartTooltip lang="fr" />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
        {series.length > 1 ? (
          <Legend
            verticalAlign="top"
            height={24}
            iconType="circle"
            iconSize={6}
            wrapperStyle={{ fontSize: 10, color: CHART_COLORS.axis }}
          />
        ) : null}
        {series.map((item) => (
          <Bar
            key={item.key}
            dataKey={item.key}
            name={item.name}
            fill={item.color}
            radius={[3, 3, 0, 0]}
            stackId={stacked ? "a" : undefined}
            maxBarSize={34}
          />
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
}

export function RevenueBarChart({
  data,
  label,
  lang,
}: {
  data: { label: string; value: number }[];
  label: string;
  lang: Lang;
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 6, right: 12, bottom: 0, left: -6 }}>
        <CartesianGrid stroke={CHART_COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" minTickGap={18} />
        <YAxis
          {...axisProps}
          width={52}
          tickFormatter={(value: number) => `${Math.round(value)} €`}
        />
        <Tooltip content={<ChartTooltip lang={lang} moneyKeys={["value"]} />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
        <Bar dataKey="value" name={label} fill={CHART_COLORS.brand} radius={[3, 3, 0, 0]} maxBarSize={26} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function PackageDonut({
  data,
  lang,
}: {
  data: { name: string; value: number }[];
  lang: Lang;
}) {
  const colors = [CHART_COLORS.brand, CHART_COLORS.info, CHART_COLORS.positive];
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius="58%"
          outerRadius="82%"
          paddingAngle={2}
          stroke="none"
        >
          {data.map((_, index) => (
            <Cell key={index} fill={colors[index % colors.length]} />
          ))}
        </Pie>
        <Tooltip content={<ChartTooltip lang={lang} moneyKeys={["value"]} />} />
        <Legend
          verticalAlign="bottom"
          height={22}
          iconType="circle"
          iconSize={6}
          wrapperStyle={{ fontSize: 10, color: CHART_COLORS.axis }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
