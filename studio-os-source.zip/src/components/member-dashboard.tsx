import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { addDays } from "date-fns";
import {
  ArrowRight,
  CalendarCheck,
  Flame,
  Handshake,
  MessageCircle,
  MousePointerClick,
  Pencil,
  Target,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useActivities, useDeals, useMembers, useProspects } from "@/hooks/use-data";
import { computeMemberStats, dailySeries, totals } from "@/lib/stats";
import { formatDateShort, formatDayLabel, formatMoney, formatPercent, toISODate, todayISO } from "@/lib/utils";
import { ActivityForm } from "@/components/activity-form";
import { ChartCard, TrendAreaChart } from "@/components/charts";
import { Button, Card, CardHeader, EmptyState, Modal, Progress, Skeleton } from "@/components/ui";
import { Stat } from "@/components/shared";

export function MemberDashboard() {
  const { profile, settings } = useAuth();
  const { t, lang } = useI18n();
  const activitiesQuery = useActivities();
  const prospectsQuery = useProspects();
  const dealsQuery = useDeals();
  const membersQuery = useMembers();
  const [open, setOpen] = useState(false);
  const [editDate, setEditDate] = useState<string | null>(null);

  const activities = activitiesQuery.data ?? [];
  const prospects = prospectsQuery.data ?? [];
  const deals = dealsQuery.data ?? [];

  const ownMembership = membersQuery.data?.find((member) => member.id === profile?.id);
  const target = ownMembership?.daily_dm_target ?? settings?.daily_dm_target ?? 30;
  const commissionRate = ownMembership?.commission_rate ?? Number(settings?.commission_rate ?? 0);

  const stats = useMemo(
    () =>
      computeMemberStats({
        userId: profile?.id ?? "",
        activities,
        deals,
        prospects,
        target,
        commissionRate,
        isActive: profile?.is_active ?? true,
      }),
    [activities, deals, prospects, profile, target, commissionRate],
  );

  const today = todayISO();
  const weekFrom = toISODate(addDays(new Date(), -6));
  const monthFrom = toISODate(addDays(new Date(), -29));

  const monthSeries = useMemo(
    () =>
      dailySeries(
        activities.filter((row) => row.user_id === profile?.id),
        monthFrom,
        today,
      ).map((row) => ({ label: formatDayLabel(row.date, lang), ...row })),
    [activities, profile, monthFrom, today, lang],
  );

  const weekTotals = useMemo(
    () =>
      totals(
        activities.filter(
          (row) => row.user_id === profile?.id && row.activity_date >= weekFrom && row.activity_date <= today,
        ),
      ),
    [activities, profile, weekFrom, today],
  );

  const history = activities
    .filter((row) => row.user_id === profile?.id)
    .slice()
    .sort((a, b) => (a.activity_date < b.activity_date ? 1 : -1))
    .slice(0, 30);

  const loading = activitiesQuery.isLoading || prospectsQuery.isLoading;
  const progress = target > 0 ? Math.round(stats.todayRate * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">
            {t("auth.welcomeBack")}, {profile?.display_name?.split(" ")[0]}
          </h1>
          <p className="mt-0.5 text-[13px] text-muted">{t("overview.memberSubtitle")}</p>
        </div>
        <Button variant="primary" onClick={() => setOpen(true)} className="h-9 shrink-0">
          {stats.loggedToday ? <Pencil className="size-3.5" /> : <Target className="size-3.5" />}
          {stats.loggedToday ? t("dash.editToday") : t("dash.logToday")}
        </Button>
      </div>

      <div className="grid gap-3 lg:grid-cols-[1.25fr_2fr]">
        <Card className="relative overflow-hidden p-4">
          <div className="pointer-events-none absolute inset-0 surface-grain" aria-hidden />
          <div className="relative">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] font-medium uppercase tracking-wide text-faint">{t("dash.dmsToday")}</p>
                {loading ? (
                  <Skeleton className="mt-2 h-8 w-20" />
                ) : (
                  <p className="num mt-1 text-[30px] font-semibold leading-none tracking-tight">{stats.dmsToday}</p>
                )}
                <p className="mt-1.5 text-[11px] text-muted">{t("dash.ofTarget", { target })}</p>
              </div>
              <div className="flex size-9 items-center justify-center rounded-lg border border-brand-500/25 bg-brand-500/10 text-brand-300">
                <Target className="size-4" />
              </div>
            </div>

            <div className="mt-3.5">
              <div className="mb-1.5 flex items-center justify-between text-[11px]">
                <span className="text-muted">{t("dash.progress")}</span>
                <span className="num font-semibold text-fg">{progress}%</span>
              </div>
              <Progress value={progress} tone={progress >= 100 ? "positive" : progress >= 60 ? "brand" : "warning"} />
              <p className="mt-2 text-[11px] text-faint">
                {stats.dmsToday >= target ? t("dash.targetReached") : t("dash.remaining", { n: Math.max(target - stats.dmsToday, 0) })}
              </p>
            </div>

            <div className="mt-3.5 flex items-center gap-4 border-t border-line pt-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("dash.streak")}</p>
                <p className="num mt-0.5 flex items-center gap-1 text-sm font-semibold text-fg">
                  <Flame className="size-3.5 text-warning" />
                  {t("dash.streakUnit", { n: stats.streak })}
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("dash.conversion")}</p>
                <p className="num mt-0.5 text-sm font-semibold text-fg">{formatPercent(stats.conversion, lang)}</p>
              </div>
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Stat
            label={t("dash.contactsWeek")}
            value={weekTotals.dms}
            icon={<MousePointerClick className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("dash.repliesWeek")}
            value={weekTotals.replies}
            icon={<MessageCircle className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("dash.interestedWeek")}
            value={weekTotals.interested}
            tone="positive"
            icon={<TrendingUp className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("dash.meetings")}
            value={weekTotals.meetings}
            icon={<CalendarCheck className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("dash.clients")}
            value={stats.dealsWon}
            tone="positive"
            icon={<Handshake className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("sales.revenue")}
            value={formatMoney(stats.revenue, lang)}
            icon={<Wallet className="size-3.5" />}
            loading={loading}
          />
          <Stat
            label={t("sales.commission", { rate: commissionRate })}
            value={formatMoney(stats.commission, lang)}
            hint={formatPercent(commissionRate / 100, lang)}
            tone="positive"
            icon={<Handshake className="size-3.5" />}
            loading={loading}
          />
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-[2fr_1fr]">
        <ChartCard title={t("dash.last30")} subtitle={t("overview.chartDms")} empty={monthSeries.every((row) => row.dms === 0)}>
          <TrendAreaChart data={monthSeries.map((row) => ({ label: row.label, value: row.dms }))} label={t("overview.dms")} />
        </ChartCard>

        <Card className="overflow-hidden">
          <CardHeader title={t("dash.last7")} subtitle={t("dash.weeklyGoal")} />
          <div className="px-4 py-3">
            <div className="flex items-baseline justify-between">
              <p className="num text-xl font-semibold">{weekTotals.dms}</p>
              <p className="text-[11px] text-muted">
                {t("dash.avg")} · {Math.round(weekTotals.dms / 7)}
              </p>
            </div>
            <Progress className="mt-2" value={target > 0 ? (weekTotals.dms / (target * 7)) * 100 : 0} />
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("dash.followupsSent")}</p>
                <p className="num text-sm font-semibold">{weekTotals.followups}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("dash.salesClosed")}</p>
                <p className="num text-sm font-semibold">{weekTotals.sales}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("analytics.daysActive")}</p>
                <p className="num text-sm font-semibold">{weekTotals.days}/7</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wide text-faint">{t("overview.activeLeads")}</p>
                <p className="num text-sm font-semibold">
                  {prospects.filter((prospect) => prospect.status !== "to_contact" && prospect.status !== "lost" && !prospect.archived_at).length}
                </p>
              </div>
            </div>
            <Link
              to="/prospects"
              className="mt-4 flex items-center justify-between rounded-lg border border-line bg-surface-2 px-3 py-2 text-[11px] text-muted transition-colors hover:text-fg"
            >
              {t("prospects.title")}
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <CardHeader
          title={t("dash.history")}
          subtitle={t("dash.historyHint")}
          action={
            <Button variant="ghost" size="sm" onClick={() => setOpen(true)}>
              {t("dash.logToday")}
            </Button>
          }
        />
        {loading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2].map((index) => (
              <Skeleton key={index} className="h-9 w-full" />
            ))}
          </div>
        ) : history.length === 0 ? (
          <EmptyState
            icon={<CalendarCheck className="size-4" />}
            title={t("dash.noHistory")}
            description={t("dash.noHistoryBody")}
            action={
              <Button variant="primary" size="sm" onClick={() => setOpen(true)}>
                {t("dash.logToday")}
              </Button>
            }
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-left text-[12px]">
              <thead>
                <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                  <th className="px-4 py-2 font-medium">{t("common.date")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.dmsShort")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.repliesReceived")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.interested")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.followupsSent")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.meetingsBooked")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.salesClosed")}</th>
                  <th className="px-4 py-2 text-right font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {history.map((row) => (
                  <tr key={row.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/50">
                    <td className="px-4 py-2 text-fg">
                      {formatDateShort(row.activity_date, lang)}
                      {row.notes ? (
                        <span className="ml-2 text-[10px] text-faint" title={row.notes}>
                          {row.notes.length > 32 ? `${row.notes.slice(0, 32)}…` : row.notes}
                        </span>
                      ) : null}
                    </td>
                    <td className="num px-2 py-2 text-right font-medium">{row.dms_sent}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.replies_received}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.interested_prospects}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.followups_sent}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.meetings_booked}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.sales_closed}</td>
                    <td className="px-4 py-2 text-right">
                      <button
                        type="button"
                        onClick={() => {
                          setEditDate(row.activity_date);
                          setOpen(true);
                        }}
                        className="rounded-md p-1 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                        aria-label={t("common.edit")}
                      >
                        <Pencil className="size-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          setEditDate(null);
        }}
        title={t("dash.activityForm", {
          date: new Intl.DateTimeFormat(lang === "fr" ? "fr-FR" : "en-GB", {
            day: "numeric",
            month: "long",
          }).format(new Date(`${editDate ?? today}T12:00:00`)),
        })}
        description={t("dash.activityFormHint")}
      >
        {profile ? (
          <ActivityForm
            key={editDate ?? today}
            userId={profile.id}
            activities={activities}
            initialDate={editDate ?? today}
            compact
            onSaved={() => {
              setOpen(false);
              setEditDate(null);
            }}
          />
        ) : null}
      </Modal>
    </div>
  );
}
