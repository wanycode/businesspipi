import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, AlertTriangle, Info, X } from "lucide-react";
import { cn } from "@/lib/utils";

type ToastTone = "success" | "error" | "info";

interface ToastItem {
  id: number;
  title: string;
  description?: string;
  tone: ToastTone;
}

interface ToastApi {
  toast: (title: string, options?: { description?: string; tone?: ToastTone }) => void;
  success: (title: string, description?: string) => void;
  error: (title: string, description?: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

let nextId = 1;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const dismiss = useCallback((id: number) => {
    setItems((current) => current.filter((item) => item.id !== id));
  }, []);

  const toast = useCallback<ToastApi["toast"]>((title, options) => {
    const id = nextId++;
    setItems((current) => [
      ...current.slice(-3),
      { id, title, description: options?.description, tone: options?.tone ?? "info" },
    ]);
  }, []);

  const success = useCallback<ToastApi["success"]>(
    (title, description) => toast(title, { description, tone: "success" }),
    [toast],
  );
  const error = useCallback<ToastApi["error"]>(
    (title, description) => toast(title, { description, tone: "error" }),
    [toast],
  );

  const api = useMemo(() => ({ toast, success, error }), [toast, success, error]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      {createPortal(
        <div
          className="pointer-events-none fixed inset-x-0 bottom-0 z-[100] flex flex-col items-center gap-2 p-4 sm:items-end sm:p-6"
          aria-live="polite"
          aria-atomic="false"
        >
          {items.map((item) => (
            <ToastCard key={item.id} item={item} onDismiss={() => dismiss(item.id)} />
          ))}
        </div>,
        document.body,
      )}
    </ToastContext.Provider>
  );
}

function ToastCard({ item, onDismiss }: { item: ToastItem; onDismiss: () => void }) {
  useEffect(() => {
    const timeout = window.setTimeout(onDismiss, item.tone === "error" ? 6000 : 4000);
    return () => window.clearTimeout(timeout);
  }, [item.tone, onDismiss]);

  const Icon = item.tone === "success" ? CheckCircle2 : item.tone === "error" ? AlertTriangle : Info;

  return (
    <div
      className={cn(
        "pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-xl border bg-surface-2/95 px-3.5 py-3 shadow-[0_16px_40px_-12px_rgba(0,0,0,0.8)] backdrop-blur animate-scale-in",
        item.tone === "success" && "border-positive/30",
        item.tone === "error" && "border-danger/30",
        item.tone === "info" && "border-line-strong",
      )}
      role="status"
    >
      <Icon
        className={cn(
          "mt-0.5 size-4 shrink-0",
          item.tone === "success" && "text-positive",
          item.tone === "error" && "text-danger",
          item.tone === "info" && "text-brand-400",
        )}
      />
      <div className="min-w-0 flex-1">
        <p className="text-[13px] font-medium leading-snug text-fg">{item.title}</p>
        {item.description ? (
          <p className="mt-0.5 text-xs leading-snug text-muted">{item.description}</p>
        ) : null}
      </div>
      <button
        type="button"
        onClick={onDismiss}
        className="rounded-md p-1 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
        aria-label="Fermer"
      >
        <X className="size-3.5" />
      </button>
    </div>
  );
}

export function useToast(): ToastApi {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast must be used inside ToastProvider");
  return context;
}
