import { Navigate, Outlet, Route, Routes, useLocation } from "react-router-dom";
import { ShieldAlert } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { AppShell } from "@/components/layout/AppShell";
import { Button, Spinner } from "@/components/ui";
import AuthPage from "@/pages/AuthPage";
import InvitePage from "@/pages/InvitePage";
import OverviewPage from "@/pages/OverviewPage";
import ActivityPage from "@/pages/ActivityPage";
import ProspectsPage from "@/pages/ProspectsPage";
import SalesPage from "@/pages/SalesPage";
import MessagesPage from "@/pages/MessagesPage";
import TeamPage from "@/pages/TeamPage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import SettingsPage from "@/pages/SettingsPage";
import SetupPage from "@/pages/SetupPage";

function Splash() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-canvas">
      <div className="flex size-9 items-center justify-center rounded-xl bg-brand-500 text-sm font-bold text-white">
        S
      </div>
      <Spinner />
    </div>
  );
}

function RequireAuth() {
  const { session, profile, loading, signOut } = useAuth();
  const { t } = useI18n();
  const location = useLocation();

  if (loading) return <Splash />;
  if (!session) return <Navigate to="/connexion" replace state={{ from: location.pathname }} />;

  if (!profile) {
    return (
      <div className="flex min-h-dvh items-center justify-center px-6">
        <div className="max-w-sm text-center">
          <div className="mx-auto mb-3 flex size-10 items-center justify-center rounded-xl border border-warning/30 bg-warning/10 text-warning">
            <ShieldAlert className="size-4" />
          </div>
          <h1 className="text-sm font-semibold">{t("auth.inactiveTitle")}</h1>
          <p className="mt-1.5 text-xs leading-relaxed text-muted">{t("auth.inactiveBody")}</p>
          <div className="mt-4 flex justify-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => window.location.reload()}>
              {t("common.retry")}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => void signOut()}>
              {t("common.logout")}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!profile.is_active) {
    return (
      <div className="flex min-h-dvh items-center justify-center px-6">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-3 flex size-10 items-center justify-center rounded-xl border border-warning/30 bg-warning/10 text-warning">
            <ShieldAlert className="size-4" />
          </div>
          <h1 className="text-sm font-semibold">{t("auth.inactiveTitle")}</h1>
          <p className="mt-1.5 text-xs leading-relaxed text-muted">{t("auth.inactiveBody")}</p>
          <p className="mt-1 text-xs text-faint">{t("auth.inactiveHowTo")}</p>
          <Button variant="secondary" size="sm" className="mt-4" onClick={() => void signOut()}>
            {t("common.logout")}
          </Button>
        </div>
      </div>
    );
  }

  return <Outlet />;
}

function RequireAdmin() {
  const { isAdmin } = useAuth();
  if (!isAdmin) return <Navigate to="/" replace />;
  return <Outlet />;
}

function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-2 bg-canvas">
      <p className="text-sm font-semibold">404</p>
      <a href="/" className="text-xs text-brand-400 hover:underline">
        Retour à l'accueil
      </a>
    </div>
  );
}

export default function App() {
  const { configured } = useAuth();

  if (!configured) return <SetupPage />;

  return (
    <Routes>
      <Route path="/connexion" element={<AuthPage mode="signin" />} />
      <Route path="/inscription" element={<AuthPage mode="signup" />} />
      <Route path="/invitation/:token" element={<InvitePage />} />

      <Route element={<RequireAuth />}>
        <Route element={<AppShell />}>
          <Route index element={<OverviewPage />} />
          <Route path="activite" element={<ActivityPage />} />
          <Route path="prospects" element={<ProspectsPage />} />
          <Route path="ventes" element={<SalesPage />} />
          <Route path="messages" element={<MessagesPage />} />
          <Route path="reglages" element={<SettingsPage />} />
          <Route element={<RequireAdmin />}>
            <Route path="equipe" element={<TeamPage />} />
            <Route path="analytique" element={<AnalyticsPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
