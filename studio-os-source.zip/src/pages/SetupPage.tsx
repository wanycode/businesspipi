import { Database, FileCode2, KeyRound } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function SetupPage() {
  const { t } = useI18n();
  const steps = [
    { icon: Database, text: t("setup.step1") },
    { icon: FileCode2, text: t("setup.step2") },
    { icon: KeyRound, text: t("setup.step3") },
  ];

  return (
    <div className="flex min-h-dvh items-center justify-center bg-canvas px-5">
      <div className="w-full max-w-md rounded-xl border border-line bg-surface p-6">
        <div className="mb-4 flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-brand-500 text-[13px] font-bold text-white">
            S
          </div>
          <span className="text-[13px] font-semibold tracking-tight">{t("app.name")}</span>
        </div>
        <h1 className="text-sm font-semibold">{t("setup.title")}</h1>
        <p className="mt-1 text-xs leading-relaxed text-muted">{t("setup.body")}</p>

        <ol className="mt-4 space-y-2.5">
          {steps.map((step, index) => (
            <li key={index} className="flex items-start gap-2.5 rounded-lg border border-line bg-surface-2 px-3 py-2.5">
              <step.icon className="mt-0.5 size-3.5 shrink-0 text-brand-400" />
              <p className="text-[12px] leading-relaxed text-muted">{step.text}</p>
            </li>
          ))}
        </ol>

        <pre className="mt-4 overflow-x-auto rounded-lg border border-line bg-canvas px-3 py-2 text-[11px] leading-relaxed text-muted">
          {`VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_xxx`}
        </pre>

        <p className="mt-4 text-[11px] text-faint">
          <a href="/README.md" className="text-brand-400 hover:underline">
            {t("setup.docs")}
          </a>
        </p>
      </div>
    </div>
  );
}
