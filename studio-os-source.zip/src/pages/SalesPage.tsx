import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { addDays } from "date-fns";
import { Handshake, Plus, Repeat, Trash2, Wallet, AlertTriangle, Pencil } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useDeleteDeal, useDeals, useMembers, useStudioSettings } from "@/hooks/use-data";
import { revenueSeries } from "@/lib/stats";
import { PACKAGE_CODES, type Deal } from "@/lib/types";
import { formatDate, formatDayLabel, formatMoney, formatPercent, sumBy, toISODate, todayISO } from "@/lib/utils";
import { DealForm } from "@/components/deal-form";
import { ChartCard, CHART_COLORS, GroupedBarChart, PackageDonut, RevenueBarChart } from "@/components/charts";
import { Badge, Button, Card, CardHeader, ConfirmDialog, EmptyState, Modal, PageHeader, Skeleton } from "@/components/ui";
import { PeriodFilter, Stat, type Period } from "@/components/shared";
import { useToast } from "@/components/ui/toast";

export default function SalesPage() {
  const { t, lang } = useI18n();
  const { isAdmin } = useAuth();
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const dealsQuery = useDeals();
  const membersQuery = useMembers();
  const studioQuery = useStudioSettings();
  const deleteDeal = useDeleteDeal();

  const today = todayISO();
  const [period, setPeriod] = useState<Period>({ preset: "month", from: toISODate(addDays(new Date(), -29)), to: today });
  const [formOpen, setFormOpen] = useState(Boolean(params.get("prospect")));
  const [editing, setEditing] = useState<Deal | null>(null);
  const [confirming, setConfirming] = useState<Deal | null>(null);

  const deals = dealsQuery.data ?? [];
  const members = membersQuery.data ?? [];
  const maintenancePrice = studioQuery.data?.maintenance_price ?? 9.99;

  const range = useMemo(() => {
    if (period.preset === "today") return { from: today, to: today };
    if (period.preset === "week") return { from: toISODate(addDays(new Date(), -6)), to: today };
    if (period.preset === "month") return { from: toISODate(addDays(new Date(), -29)), to: today };
    return { from: period.from, to: period.to };
  }, [period, today]);

  const wonInRange = useMemo(
    () => deals.filter((deal) => deal.deal_status === "won" && deal.won_at && deal.won_at >= range.from && deal.won_at <= range.to),
    [deals, range],
  );

  const rateFor = (userId: string) => members.find((member) => member.id === userId)?.commission_rate ?? 0;
  const commissionFor = (deal: Deal) => (deal.amount_paid * rateFor(deal.assigned_user_id)) / 100;

  const revenue = sumBy(wonInRange, (deal) => deal.amount_paid);
  const signedValue = sumBy(wonInRange, (deal) => deal.deal_amount);
  const commissions = sumBy(wonInRange, commissionFor);
  const outstanding = signedValue - revenue;
  const maintenanceCount = deals.filter((deal) => deal.deal_status === "won" && deal.maintenance_active).length;

  const packageData = useMemo(
    () =>
      PACKAGE_CODES.map((code) => ({
        name: code,
        value: sumBy(
          wonInRange.filter((deal) => deal.package === code),
          (deal) => deal.amount_paid,
        ),
      })).filter((row) => row.value > 0),
    [wonInRange],
  );

  const memberBars = useMemo(
    () =>
      members.map((member) => ({
        label: member.display_name.split(" ")[0] ?? member.display_name,
        revenue: Math.round(
          sumBy(
            wonInRange.filter((deal) => deal.assigned_user_id === member.id),
            (deal) => deal.amount_paid,
          ),
        ),
      })),
    [members, wonInRange],
  );

  const revenueData = useMemo(
    () =>
      revenueSeries(deals, range.from, range.to).map((row) => ({
        label: formatDayLabel(row.label, lang),
        value: row.value,
      })),
    [deals, range, lang],
  );

  const closeForm = () => {
    setFormOpen(false);
    setEditing(null);
    if (params.get("prospect")) {
      params.delete("prospect");
      setParams(params, { replace: true });
    }
  };

  const packageLabel = (code: Deal["package"]) => code;

  return (
    <div className="space-y-4">
      <PageHeader
        title={t("sales.title")}
        subtitle={isAdmin ? t("sales.adminSubtitle") : t("sales.subtitle")}
        actions={
          <Button
            variant="primary"
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            <Plus className="size-3.5" />
            {t("sales.addDeal")}
          </Button>
        }
      />

      <div className="flex flex-wrap items-center justify-between gap-2">
        <PeriodFilter period={period} onChange={setPeriod} />
        <p className="text-[11px] text-faint">
          {formatDate(range.from, lang)} → {formatDate(range.to, lang)}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <Stat label={t("sales.closedDeals")} value={wonInRange.length} icon={<Handshake className="size-3.5" />} loading={dealsQuery.isLoading} />
        <Stat
          label={t("sales.revenue")}
          value={formatMoney(revenue, lang)}
          tone="positive"
          icon={<Wallet className="size-3.5" />}
          loading={dealsQuery.isLoading}
          hint={`${t("sales.signed")} · ${formatMoney(signedValue, lang)}`}
        />
        <Stat
          label={t("sales.outstanding")}
          value={formatMoney(outstanding, lang)}
          tone={outstanding > 0 ? "warning" : "neutral"}
          icon={<AlertTriangle className="size-3.5" />}
          loading={dealsQuery.isLoading}
        />
        <Stat label={t("sales.maintenanceActive")} value={maintenanceCount} icon={<Repeat className="size-3.5" />} loading={dealsQuery.isLoading} />
        <Stat
          label={t("sales.mrr")}
          value={formatMoney(maintenanceCount * maintenancePrice, lang)}
          icon={<Repeat className="size-3.5" />}
          loading={dealsQuery.isLoading}
        />
        <Stat
          label={t("sales.commissions")}
          value={formatMoney(commissions, lang)}
          icon={<Handshake className="size-3.5" />}
          loading={dealsQuery.isLoading}
          hint={
            members.length > 0
              ? formatPercent(
                  members.reduce((sum, member) => sum + member.commission_rate, 0) / members.length / 100,
                  lang,
                )
              : undefined
          }
        />
      </div>
      <p className="text-[11px] text-faint">{t("sales.revenueNote")}</p>

      <div className="grid gap-3 lg:grid-cols-3">
        <ChartCard title={t("sales.byPackage")} empty={packageData.length === 0} height={200}>
          <PackageDonut data={packageData} lang={lang} />
        </ChartCard>
        {isAdmin ? (
          <ChartCard title={t("sales.byMember")} className="lg:col-span-2" empty={memberBars.every((row) => row.revenue === 0)}>
            <GroupedBarChart data={memberBars} series={[{ key: "revenue", name: t("sales.revenue"), color: CHART_COLORS.brand }]} />
          </ChartCard>
        ) : (
          <ChartCard title={t("overview.chartRevenue")} className="lg:col-span-2" empty={revenueData.every((row) => row.value === 0)}>
            <RevenueBarChart data={revenueData} label={t("sales.revenue")} lang={lang} />
          </ChartCard>
        )}
      </div>

      {isAdmin ? (
        <ChartCard title={t("overview.chartRevenue")} empty={revenueData.every((row) => row.value === 0)}>
          <RevenueBarChart data={revenueData} label={t("sales.revenue")} lang={lang} />
        </ChartCard>
      ) : null}

      <Card className="overflow-hidden">
        <CardHeader title={t("sales.title")} subtitle={`${deals.length} ${t("common.total").toLowerCase()}`} />
        {dealsQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2].map((index) => (
              <Skeleton key={index} className="h-10 w-full" />
            ))}
          </div>
        ) : deals.length === 0 ? (
          <EmptyState
            icon={<Wallet className="size-4" />}
            title={t("sales.emptyTitle")}
            description={t("sales.emptyBody")}
            action={
              <Button size="sm" variant="primary" onClick={() => setFormOpen(true)}>
                {t("sales.addDeal")}
              </Button>
            }
          />
        ) : (
          <>
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full min-w-[940px] text-left text-[12px]">
                <thead>
                  <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                    <th className="px-4 py-2 font-medium">{t("sales.client")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.package")}</th>
                    {isAdmin ? <th className="px-2 py-2 font-medium">{t("prospects.assigned")}</th> : null}
                    <th className="px-2 py-2 text-right font-medium">{t("sales.amount")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.dealStatus")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.paymentStatus")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("sales.amountPaid")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("sales.commission")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.wonAt")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.maintenance")}</th>
                    <th className="px-4 py-2 text-right font-medium">{t("common.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {deals.map((deal) => (
                    <tr key={deal.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                      <td className="px-4 py-2.5 font-medium text-fg">{deal.client_name}</td>
                      <td className="px-2 py-2.5">
                        <Badge tone="brand">{packageLabel(deal.package)}</Badge>
                      </td>
                      {isAdmin ? (
                        <td className="px-2 py-2.5 text-muted">
                          {members.find((member) => member.id === deal.assigned_user_id)?.display_name ?? "—"}
                        </td>
                      ) : null}
                      <td className="num px-2 py-2.5 text-right text-muted">{formatMoney(deal.deal_amount, lang)}</td>
                      <td className="px-2 py-2.5">
                        <Badge
                          tone={deal.deal_status === "won" ? "positive" : deal.deal_status === "lost" ? "danger" : "neutral"}
                          dot
                        >
                          {deal.deal_status === "won"
                            ? t("sales.dealWon")
                            : deal.deal_status === "lost"
                              ? t("sales.dealLost")
                              : t("sales.dealProposed")}
                        </Badge>
                      </td>
                      <td className="px-2 py-2.5">
                        <Badge
                          tone={
                            deal.payment_status === "paid" ? "positive" : deal.payment_status === "partial" ? "warning" : "neutral"
                          }
                        >
                          {deal.payment_status === "paid"
                            ? t("sales.paymentPaid")
                            : deal.payment_status === "partial"
                              ? t("sales.paymentPartial")
                              : t("sales.paymentUnpaid")}
                        </Badge>
                      </td>
                      <td className="num px-2 py-2.5 text-right text-muted">{formatMoney(deal.amount_paid, lang)}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">
                        {deal.deal_status === "won" ? formatMoney(commissionFor(deal), lang) : "—"}
                      </td>
                      <td className="px-2 py-2.5 text-muted">{formatDate(deal.won_at, lang)}</td>
                      <td className="px-2 py-2.5">
                        {deal.maintenance_active ? (
                          <Badge tone="brand">{`${formatMoney(maintenancePrice, lang)}/m`}</Badge>
                        ) : (
                          <span className="text-faint">—</span>
                        )}
                      </td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditing(deal);
                              setFormOpen(true);
                            }}
                            className="rounded-md p-1 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                            aria-label={t("common.edit")}
                          >
                            <Pencil className="size-3" />
                          </button>
                          {isAdmin ? (
                            <button
                              type="button"
                              onClick={() => setConfirming(deal)}
                              className="rounded-md p-1 text-faint transition-colors hover:bg-danger/15 hover:text-danger"
                              aria-label={t("common.delete")}
                            >
                              <Trash2 className="size-3" />
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="divide-y divide-line md:hidden">
              {deals.map((deal) => (
                <button
                  key={deal.id}
                  type="button"
                  onClick={() => {
                    setEditing(deal);
                    setFormOpen(true);
                  }}
                  className="flex w-full flex-col gap-1.5 px-4 py-3 text-left active:bg-surface-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-fg">{deal.client_name}</p>
                      <p className="text-[11px] text-faint">
                        {deal.package} · {formatDate(deal.won_at, lang)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="num text-[13px] font-semibold text-fg">{formatMoney(deal.deal_amount, lang)}</p>
                      <p className="text-[10px] text-faint">{formatMoney(deal.amount_paid, lang)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Badge tone={deal.deal_status === "won" ? "positive" : deal.deal_status === "lost" ? "danger" : "neutral"}>
                      {deal.deal_status === "won" ? t("sales.dealWon") : deal.deal_status === "lost" ? t("sales.dealLost") : t("sales.dealProposed")}
                    </Badge>
                    <Badge tone={deal.payment_status === "paid" ? "positive" : deal.payment_status === "partial" ? "warning" : "neutral"}>
                      {deal.payment_status === "paid"
                        ? t("sales.paymentPaid")
                        : deal.payment_status === "partial"
                          ? t("sales.paymentPartial")
                          : t("sales.paymentUnpaid")}
                    </Badge>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}
      </Card>

      <Modal
        open={formOpen}
        onClose={closeForm}
        title={editing ? t("sales.editDeal") : t("sales.addDeal")}
        size="lg"
      >
        <DealForm
          deal={editing}
          presetProspectId={params.get("prospect")}
          onCancel={closeForm}
          onDone={() => {
            toast.success(editing ? t("sales.updated") : t("sales.created"));
            closeForm();
          }}
        />
      </Modal>

      <ConfirmDialog
        open={Boolean(confirming)}
        title={t("sales.deleteTitle")}
        description={t("sales.deleteBody")}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        destructive
        loading={deleteDeal.isPending}
        onCancel={() => setConfirming(null)}
        onConfirm={async () => {
          if (!confirming) return;
          try {
            await deleteDeal.mutateAsync(confirming.id);
            toast.success(t("common.saved"));
          } catch {
            toast.error(t("errors.saveFailed"));
          } finally {
            setConfirming(null);
          }
        }}
      />
    </div>
  );
}
