import { useMemo, useState } from "react";
import { addDays } from "date-fns";
import { BarChart3, Pencil, Plus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useActivities, useDeals, useMembers, useProspects } from "@/hooks/use-data";
import { activitiesInRange, dailySeries, totals, revenueSeries } from "@/lib/stats";
import { formatDate, formatDayLabel, formatMoney, formatPercent, toISODate, todayISO, sumBy } from "@/lib/utils";
import { ActivityForm } from "@/components/activity-form";
import { ChartCard, CHART_COLORS, GroupedBarChart, MultiLineChart, RevenueBarChart, TrendAreaChart } from "@/components/charts";
import { Button, Card, CardHeader, EmptyState, Modal, PageHeader, Select, Skeleton } from "@/components/ui";
import { PeriodFilter, Stat, type Period } from "@/components/shared";

export default function AnalyticsPage() {
  const { t, lang } = useI18n();
  const { isAdmin }
    = useAuth();
  const activitiesQuery = useActivities();
  const membersQuery = useMembers();
  const prospectsQuery = useProspects();
  const dealsQuery = useDeals();

  const today = todayISO();
  const [period, setPeriod] = useState<Period>({ preset: "month", from: toISODate(addDays(new Date(), -29)), to: today });
  const [selected, setSelected] = useState<string>("all");
  const [editingDate, setEditingDate] = useState<string | null>(null);

  const activities = activitiesQuery.data ?? [];
  const members = membersQuery.data ?? [];
  const prospects = prospectsQuery.data ?? [];
  const deals = dealsQuery.data ?? [];

  const range = useMemo(() => {
    if (period.preset === "today") return { from: today, to: today };
    if (period.preset === "week") return { from: toISODate(addDays(new Date(), -6)), to: today };
    if (period.preset === "month") return { from: toISODate(addDays(new Date(), -29)), to: today };
    return { from: period.from, to: period.to };
  }, [period, today]);

  const scopedActivities = useMemo(
    () =>
      activitiesInRange(
        selected === "all" ? activities : activities.filter((row) => row.user_id === selected),
        range.from,
        range.to,
      ),
    [activities, selected, range],
  );

  const scopedDeals = useMemo(
    () =>
      deals.filter(
        (deal) =>
          deal.deal_status === "won" &&
          deal.won_at &&
          deal.won_at >= range.from &&
          deal.won_at <= range.to &&
          (selected === "all" || deal.assigned_user_id === selected),
      ),
    [deals, selected, range],
  );

  const stats = totals(scopedActivities);
  const revenue = sumBy(scopedDeals, (deal) => deal.amount_paid);
  const signed = sumBy(scopedDeals, (deal) => deal.deal_amount);
  const activeMembers = members.filter((member) => member.is_active);
  const targetTotal =
    selected === "all"
      ? activeMembers.reduce((sum, member) => sum + member.daily_dm_target, 0)
      : (members.find((member) => member.id === selected)?.daily_dm_target ?? 0);

  const dayCount = Math.max(
    1,
    Math.round((new Date(`${range.to}T12:00:00`).getTime() - new Date(`${range.from}T12:00:00`).getTime()) / 86400000) + 1,
  );
  const targetRate = targetTotal > 0 ? stats.dms / (targetTotal * dayCount) : 0;
  const bestDay = scopedActivities.reduce(
    (best, row) => (row.dms_sent > (best?.dms_sent ?? 0) ? row : best),
    null as (typeof scopedActivities)[number] | null,
  );

  const series = useMemo(
    () =>
      dailySeries(scopedActivities, range.from, range.to).map((row) => ({
        label: formatDayLabel(row.date, lang),
        dms: row.dms,
        replies: row.replies,
        interested: row.interested,
        followups: row.followups,
      })),
    [scopedActivities, range, lang],
  );

  const periodActivities = useMemo(
    () => activitiesInRange(activities, range.from, range.to),
    [activities, range],
  );

  /** Agrégats strictement limités à la période sélectionnée. */
  const memberRows = useMemo(
    () =>
      members
        .map((member) => {
          const rows = periodActivities.filter((row) => row.user_id === member.id);
          const memberTotals = totals(rows);
          const memberDeals = deals.filter(
            (deal) =>
              deal.assigned_user_id === member.id &&
              deal.deal_status === "won" &&
              deal.won_at &&
              deal.won_at >= range.from &&
              deal.won_at <= range.to,
          );
          const ownProspects = prospects.filter((prospect) => prospect.assigned_user_id === member.id);
          const contacted = ownProspects.filter((prospect) => prospect.status !== "to_contact").length;
          const won = ownProspects.filter((prospect) => prospect.status === "won").length;
          return {
            member,
            dms: memberTotals.dms,
            replies: memberTotals.replies,
            interested: memberTotals.interested,
            meetings: memberTotals.meetings,
            days: rows.length,
            sales: memberDeals.length,
            revenue: sumBy(memberDeals, (deal) => deal.amount_paid),
            conversion: contacted > 0 ? won / contacted : 0,
            commissionRate: member.commission_rate,
          };
        })
        .filter((row) => row.days > 0 || row.member.is_active)
        .sort((a, b) => b.dms - a.dms),
    [members, periodActivities, deals, prospects, range],
  );

  const memberBars = useMemo(
    () =>
      memberRows.map((row) => ({
        label: row.member.display_name.split(" ")[0] ?? row.member.display_name,
        dms: row.dms,
        replies: row.replies,
        interested: row.interested,
      })),
    [memberRows],
  );

  const revenueData = useMemo(
    () =>
      revenueSeries(deals, range.from, range.to).map((row) => ({
        label: formatDayLabel(row.label, lang),
        value: row.value,
      })),
    [deals, range, lang],
  );

  const selectedMember = members.find((member) => member.id === selected) ?? null;
  const dailyRows = scopedActivities
    .slice()
    .sort((a, b) => (a.activity_date < b.activity_date ? 1 : -1));

  if (!isAdmin) return null;

  return (
    <div className="space-y-4">
      <PageHeader title={t("analytics.title")} subtitle={t("analytics.subtitle")} />

      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <Select
            value={selected}
            onChange={(event) => setSelected(event.target.value)}
            className="h-8 max-w-[220px] text-[11px]"
            aria-label={t("analytics.selectMember")}
          >
            <option value="all">{t("analytics.allTeam")}</option>
            {members.map((member) => (
              <option key={member.id} value={member.id}>
                {member.display_name}
              </option>
            ))}
          </Select>
          <PeriodFilter period={period} onChange={setPeriod} />
        </div>
        <p className="text-[11px] text-faint">
          {formatDate(range.from, lang)} → {formatDate(range.to, lang)}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label={t("analytics.totalDms")} value={stats.dms} loading={activitiesQuery.isLoading} />
        <Stat label={t("analytics.replies")} value={stats.replies} loading={activitiesQuery.isLoading} />
        <Stat label={t("analytics.interested")} value={stats.interested} tone="positive" loading={activitiesQuery.isLoading} />
        <Stat label={t("analytics.meetings")} value={stats.meetings} loading={activitiesQuery.isLoading} />
        <Stat label={t("analytics.sales")} value={scopedDeals.length} tone="positive" loading={dealsQuery.isLoading} />
        <Stat
          label={t("analytics.revenue")}
          value={formatMoney(revenue, lang)}
          hint={`${t("sales.signed")} · ${formatMoney(signed, lang)}`}
          loading={dealsQuery.isLoading}
        />
        <Stat label={t("analytics.targetRate")} value={formatPercent(targetRate, lang)} />
        <Stat
          label={t("analytics.bestDay")}
          value={bestDay ? `${bestDay.dms_sent}` : "—"}
          hint={bestDay ? formatDate(bestDay.activity_date, lang) : undefined}
        />
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        <ChartCard title={t("overview.chartDms")} empty={series.every((row) => row.dms === 0)}>
          <TrendAreaChart data={series.map((row) => ({ label: row.label, value: row.dms }))} label={t("overview.dms")} />
        </ChartCard>
        <ChartCard title={t("overview.chartFunnel")} empty={series.every((row) => row.replies === 0)}>
          <MultiLineChart
            data={series}
            series={[
              { key: "replies", name: t("overview.replies"), color: CHART_COLORS.info },
              { key: "interested", name: t("overview.interested"), color: CHART_COLORS.positive },
            ]}
          />
        </ChartCard>
        <ChartCard title={t("analytics.compare")} empty={memberBars.length === 0}>
          <GroupedBarChart
            data={memberBars}
            series={[
              { key: "dms", name: t("overview.dms"), color: CHART_COLORS.brand },
              { key: "replies", name: t("overview.replies"), color: CHART_COLORS.info },
              { key: "interested", name: t("overview.interested"), color: CHART_COLORS.positive },
            ]}
          />
        </ChartCard>
        <ChartCard title={t("overview.chartRevenue")} empty={revenueData.every((row) => row.value === 0)}>
          <RevenueBarChart data={revenueData} label={t("sales.revenue")} lang={lang} />
        </ChartCard>
      </div>

      {selected === "all" ? (
        <Card className="overflow-hidden">
          <CardHeader title={t("analytics.overview")} subtitle={t("analytics.exportHint")} />
          {membersQuery.isLoading ? (
            <div className="space-y-2 p-4">
              {[0, 1, 2].map((index) => (
                <Skeleton key={index} className="h-9 w-full" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[860px] text-left text-[12px]">
                <thead>
                  <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                    <th className="px-4 py-2 font-medium">{t("analytics.member")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.totalDms")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.replies")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.interested")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.meetings")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.daysActive")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("overview.conversion")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("analytics.sales")}</th>
                    <th className="px-4 py-2 text-right font-medium">{t("analytics.revenue")}</th>
                  </tr>
                </thead>
                <tbody>
                  {memberRows.map((row) => (
                    <tr key={row.member.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                      <td className="px-4 py-2.5">
                        <p className="font-medium text-fg">{row.member.display_name}</p>
                        <p className="text-[10px] text-faint">{row.member.email}</p>
                      </td>
                      <td className="num px-2 py-2.5 text-right">{row.dms}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{row.replies}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{row.interested}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{row.meetings}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{row.days}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{formatPercent(row.conversion, lang)}</td>
                      <td className="num px-2 py-2.5 text-right text-muted">{row.sales}</td>
                      <td className="num px-4 py-2.5 text-right text-muted">{formatMoney(row.revenue, lang)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <CardHeader
            title={`${t("analytics.daily")} · ${selectedMember?.display_name ?? ""}`}
            subtitle={t("analytics.exportHint")}
          />
          {dailyRows.length === 0 ? (
            <EmptyState icon={<BarChart3 className="size-4" />} title={t("analytics.noData")} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-left text-[12px]">
                <thead>
                  <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                    <th className="px-4 py-2 font-medium">{t("common.date")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("overview.dms")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("overview.replies")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("overview.interested")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("dash.followupsSent")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("dash.meetingsBooked")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("dash.salesClosed")}</th>
                    <th className="px-4 py-2 text-right font-medium">{t("common.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {dailyRows.map((row) => (
                    <tr key={row.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                      <td className="px-4 py-2 font-medium text-fg">{formatDate(row.activity_date, lang)}</td>
                      <td className="num px-2 py-2 text-right">{row.dms_sent}</td>
                      <td className="num px-2 py-2 text-right text-muted">{row.replies_received}</td>
                      <td className="num px-2 py-2 text-right text-muted">{row.interested_prospects}</td>
                      <td className="num px-2 py-2 text-right text-muted">{row.followups_sent}</td>
                      <td className="num px-2 py-2 text-right text-muted">{row.meetings_booked}</td>
                      <td className="num px-2 py-2 text-right text-muted">{row.sales_closed}</td>
                      <td className="px-4 py-2 text-right">
                        <button
                          type="button"
                          onClick={() => setEditingDate(row.activity_date)}
                          className="rounded-md p-1 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                          aria-label={t("common.edit")}
                        >
                          <Pencil className="size-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="flex items-center justify-end border-t border-line px-4 py-2.5">
            <Button variant="secondary" size="sm" onClick={() => setEditingDate(today)}>
              <Plus className="size-3" />
              {t("dash.logToday")}
            </Button>
          </div>
        </Card>
      )}

      <Modal
        open={Boolean(editingDate) && Boolean(selectedMember)}
        onClose={() => setEditingDate(null)}
        title={t("dash.activityForm", { date: editingDate ?? "" })}
        description={selectedMember ? `${t("analytics.member")} · ${selectedMember.display_name}` : undefined}
      >
        {selectedMember && editingDate ? (
          <ActivityForm
            key={`${selectedMember.id}-${editingDate}`}
            userId={selectedMember.id}
            activities={activities}
            initialDate={editingDate}
            compact
            onSaved={() => setEditingDate(null)}
          />
        ) : null}
      </Modal>
    </div>
  );
}
