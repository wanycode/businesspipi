import { useAuth } from "@/hooks/use-auth";
import { AdminOverview } from "@/components/admin-overview";
import { MemberDashboard } from "@/components/member-dashboard";
import { Spinner } from "@/components/ui";

export default function OverviewPage() {
  const { isAdmin, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Spinner />
      </div>
    );
  }
  return isAdmin ? <AdminOverview /> : <MemberDashboard />;
}
