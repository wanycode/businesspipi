import { useMemo, useState } from "react";
import { AlertCircle, CalendarClock, Plus, Search, Users } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useMembers, useProspects } from "@/hooks/use-data";
import { PROSPECT_STATUSES, type Prospect, type ProspectStatus } from "@/lib/types";
import { formatDate, formatMoney, isOverdue, todayISO } from "@/lib/utils";
import { ProspectForm } from "@/components/prospect-form";
import { ProspectDetail } from "@/components/prospect-detail";
import { ProspectStatusBadge } from "@/components/shared";
import {
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  Modal,
  PageHeader,
  Select,
  Skeleton,
} from "@/components/ui";
import { useToast } from "@/components/ui/toast";

type SortKey = "followup" | "recent";

export default function ProspectsPage() {
  const { t, lang } = useI18n();
  const { isAdmin } = useAuth();
  const toast = useToast();
  const prospectsQuery = useProspects();
  const membersQuery = useMembers();

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<ProspectStatus | "all">("all");
  const [member, setMember] = useState<string>("all");
  const [country, setCountry] = useState<string>("all");
  const [niche, setNiche] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("followup");
  const [showArchived, setShowArchived] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Prospect | null>(null);
  const [selected, setSelected] = useState<Prospect | null>(null);

  const prospects = prospectsQuery.data ?? [];
  const members = membersQuery.data ?? [];

  const countries = useMemo(
    () => Array.from(new Set(prospects.map((row) => row.country).filter((value): value is string => Boolean(value)))).sort(),
    [prospects],
  );
  const niches = useMemo(
    () => Array.from(new Set(prospects.map((row) => row.niche).filter((value): value is string => Boolean(value)))).sort(),
    [prospects],
  );

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    const rows = prospects.filter((row) => {
      if (!showArchived && row.archived_at) return false;
      if (showArchived && !row.archived_at) return false;
      if (status !== "all" && row.status !== status) return false;
      if (member !== "all" && row.assigned_user_id !== member) return false;
      if (country !== "all" && row.country !== country) return false;
      if (niche !== "all" && row.niche !== niche) return false;
      if (term) {
        const haystack = `${row.name} ${row.instagram_username} ${row.niche ?? ""} ${row.country ?? ""}`.toLowerCase();
        if (!haystack.includes(term)) return false;
      }
      return true;
    });
    return rows.sort((a, b) => {
      if (sort === "recent") return a.updated_at < b.updated_at ? 1 : -1;
      if (!a.next_followup_at && !b.next_followup_at) return a.name.localeCompare(b.name);
      if (!a.next_followup_at) return 1;
      if (!b.next_followup_at) return -1;
      return a.next_followup_at < b.next_followup_at ? -1 : 1;
    });
  }, [prospects, search, status, member, country, niche, sort, showArchived]);

  const today = todayISO();
  const overdue = prospects.filter((row) => !row.archived_at && isOverdue(row.next_followup_at)).length;
  const dueToday = prospects.filter((row) => !row.archived_at && row.next_followup_at === today).length;

  const memberName = (id: string) =>
    members.find((item) => item.id === id)?.display_name ?? (id ? t("common.member") : "—");

  const openNew = () => {
    setEditing(null);
    setFormOpen(true);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title={t("prospects.title")}
        subtitle={isAdmin ? t("prospects.adminSubtitle") : t("prospects.subtitle")}
        actions={
          <Button variant="primary" onClick={openNew}>
            <Plus className="size-3.5" />
            {t("prospects.add")}
          </Button>
        }
      />

      <div className="flex flex-wrap items-center gap-2 text-[11px]">
        <Badge tone="warning">
          <CalendarClock className="size-3" />
          {t("prospects.overdue")} · {overdue}
        </Badge>
        <Badge tone="brand">
          <AlertCircle className="size-3" />
          {t("prospects.dueToday")} · {dueToday}
        </Badge>
        <span className="text-faint">
          {visible.length} / {prospects.filter((row) => !row.archived_at).length}
        </span>
      </div>

      <Card className="p-3">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-faint" />
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder={t("prospects.searchPlaceholder")}
              className="pl-8"
              aria-label={t("common.search")}
            />
          </div>
          <Select value={status} onChange={(event) => setStatus(event.target.value as ProspectStatus | "all")} aria-label={t("common.status")}>
            <option value="all">{t("prospects.allStatuses")}</option>
            {PROSPECT_STATUSES.map((item) => (
              <option key={item} value={item}>
                {t(`status.${item}`)}
              </option>
            ))}
          </Select>
          {isAdmin ? (
            <Select value={member} onChange={(event) => setMember(event.target.value)} aria-label={t("prospects.assigned")}>
              <option value="all">{t("prospects.allMembers")}</option>
              {members.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.display_name}
                </option>
              ))}
            </Select>
          ) : null}
          <Select value={country} onChange={(event) => setCountry(event.target.value)} aria-label={t("prospects.country")}>
            <option value="all">{t("prospects.allCountries")}</option>
            {countries.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </Select>
          <Select value={niche} onChange={(event) => setNiche(event.target.value)} aria-label={t("prospects.niche")}>
            <option value="all">{t("prospects.allNiches")}</option>
            {niches.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </Select>
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
          <Select
            value={sort}
            onChange={(event) => setSort(event.target.value as SortKey)}
            className="h-8 max-w-[220px] text-[11px]"
            aria-label={t("common.search")}
          >
            <option value="followup">{t("prospects.followupFirst")}</option>
            <option value="recent">{t("prospects.recentFirst")}</option>
          </Select>
          <label className="flex items-center gap-2 text-[11px] text-muted">
            <input
              type="checkbox"
              checked={showArchived}
              onChange={(event) => setShowArchived(event.target.checked)}
              className="size-3.5 accent-[#6e56f8]"
            />
            {t("common.showArchived")}
          </label>
        </div>
      </Card>

      <Card className="overflow-hidden">
        {prospectsQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3, 4].map((index) => (
              <Skeleton key={index} className="h-10 w-full" />
            ))}
          </div>
        ) : prospectsQuery.isError ? (
          <EmptyState
            icon={<AlertCircle className="size-4" />}
            title={t("errors.loadFailed")}
            description={String(prospectsQuery.error)}
            action={
              <Button size="sm" variant="secondary" onClick={() => void prospectsQuery.refetch()}>
                {t("common.retry")}
              </Button>
            }
          />
        ) : visible.length === 0 ? (
          <EmptyState
            icon={<Users className="size-4" />}
            title={prospects.length === 0 ? t("prospects.emptyTitle") : t("common.noResults")}
            description={prospects.length === 0 ? t("prospects.emptyBody") : t("prospects.emptyFiltered")}
            action={
              prospects.length === 0 ? (
                <Button size="sm" variant="primary" onClick={openNew}>
                  {t("prospects.add")}
                </Button>
              ) : null
            }
          />
        ) : (
          <>
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full min-w-[900px] text-left text-[12px]">
                <thead>
                  <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                    <th className="px-4 py-2 font-medium">{t("common.name")}</th>
                    <th className="px-2 py-2 font-medium">{t("common.status")}</th>
                    <th className="px-2 py-2 font-medium">{t("prospects.niche")}</th>
                    <th className="px-2 py-2 font-medium">{t("prospects.country")}</th>
                    {isAdmin ? <th className="px-2 py-2 font-medium">{t("prospects.assigned")}</th> : null}
                    <th className="px-2 py-2 font-medium">{t("prospects.nextFollowup")}</th>
                    <th className="px-2 py-2 text-right font-medium">{t("prospects.estimatedValue")}</th>
                    <th className="px-4 py-2 font-medium">{t("prospects.lastContact")}</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((row) => (
                    <tr
                      key={row.id}
                      className="cursor-pointer border-b border-line/60 last:border-0 hover:bg-surface-2/50"
                      onClick={() => setSelected(row)}
                    >
                      <td className="px-4 py-2.5">
                        <p className="font-medium text-fg">{row.name}</p>
                        <p className="text-[10px] text-faint">@{row.instagram_username}</p>
                      </td>
                      <td className="px-2 py-2.5">
                        <ProspectStatusBadge status={row.status} />
                      </td>
                      <td className="max-w-[140px] truncate px-2 py-2.5 text-muted">{row.niche ?? "—"}</td>
                      <td className="px-2 py-2.5 text-muted">{row.country ?? "—"}</td>
                      {isAdmin ? <td className="px-2 py-2.5 text-muted">{memberName(row.assigned_user_id)}</td> : null}
                      <td className="px-2 py-2.5">
                        {row.next_followup_at ? (
                          <span className={isOverdue(row.next_followup_at) ? "font-medium text-danger" : "text-muted"}>
                            {formatDate(row.next_followup_at, lang)}
                          </span>
                        ) : (
                          <span className="text-faint">—</span>
                        )}
                      </td>
                      <td className="num px-2 py-2.5 text-right text-muted">
                        {row.estimated_value != null ? formatMoney(row.estimated_value, lang) : "—"}
                      </td>
                      <td className="px-4 py-2.5 text-muted">{formatDate(row.last_contacted_at, lang)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="divide-y divide-line md:hidden">
              {visible.map((row) => (
                <button
                  key={row.id}
                  type="button"
                  onClick={() => setSelected(row)}
                  className="flex w-full flex-col gap-1.5 px-4 py-3 text-left transition-colors active:bg-surface-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-medium text-fg">{row.name}</p>
                      <p className="truncate text-[11px] text-faint">@{row.instagram_username}</p>
                    </div>
                    <ProspectStatusBadge status={row.status} />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-muted">
                    <span>{row.niche ?? row.country ?? "—"}</span>
                    <span className={isOverdue(row.next_followup_at) ? "text-danger" : "text-faint"}>
                      {row.next_followup_at ? formatDate(row.next_followup_at, lang) : "—"}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </>
        )}
      </Card>

      <Modal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditing(null);
        }}
        title={editing ? t("prospects.edit") : t("prospects.add")}
        size="lg"
      >
        <ProspectForm
          prospect={editing}
          onCancel={() => {
            setFormOpen(false);
            setEditing(null);
          }}
          onDone={() => {
            toast.success(editing ? t("prospects.updated") : t("prospects.created"));
            setFormOpen(false);
            setEditing(null);
          }}
        />
      </Modal>

      <ProspectDetail
        prospect={selected}
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        onEdit={() => {
          setEditing(selected);
          setSelected(null);
          setFormOpen(true);
        }}
      />
    </div>
  );
}
