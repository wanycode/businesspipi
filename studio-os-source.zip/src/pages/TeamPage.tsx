import { useEffect, useState } from "react";
import { Check, Copy, Link2, Mail, Power, ShieldCheck, X } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import {
  useActivities,
  useCreateInvite,
  useDeleteInvite,
  useInvites,
  useMembers,
  useSetMemberActive,
  useUpdateCommission,
  useUpdateTarget,
} from "@/hooks/use-data";
import { updateProfile } from "@/lib/api";
import type { Role, TeamMember } from "@/lib/types";
import { copyToClipboard, formatDate, inviteUrl, todayISO } from "@/lib/utils";
import {
  Badge,
  Button,
  Card,
  CardHeader,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  PageHeader,
  Select,
  Skeleton,
} from "@/components/ui";
import { useToast } from "@/components/ui/toast";

function NumberCell({
  value: initial,
  max,
  suffix,
  ariaLabel,
  onSave,
}: {
  value: number;
  max: number;
  suffix?: string;
  ariaLabel: string;
  onSave: (value: number) => Promise<void>;
}) {
  const [value, setValue] = useState(initial);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setValue(initial);
    setDirty(false);
  }, [initial]);

  const commit = async () => {
    if (!dirty || busy) return;
    setBusy(true);
    try {
      await onSave(Math.max(0, Math.min(max, Math.round(value))));
      setDirty(false);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex items-center gap-1.5">
      <Input
        type="number"
        min={0}
        max={max}
        value={value}
        onChange={(event) => {
          setValue(Number(event.target.value));
          setDirty(true);
        }}
        onKeyDown={(event) => {
          if (event.key === "Enter") void commit();
        }}
        className="num h-7 w-16 px-1.5 text-center text-[11px]"
        aria-label={ariaLabel}
      />
      {suffix ? <span className="text-[10px] text-faint">{suffix}</span> : null}
      {dirty ? (
        <button
          type="button"
          onClick={() => void commit()}
          disabled={busy}
          className="rounded-md p-1 text-positive transition-colors hover:bg-positive/10"
          aria-label="Enregistrer"
        >
          <Check className="size-3" />
        </button>
      ) : null}
    </div>
  );
}

export default function TeamPage() {
  const { t, lang } = useI18n();
  const { profile, isAdmin } = useAuth();
  const toast = useToast();
  const errorText = useErrorText();
  const membersQuery = useMembers();
  const invitesQuery = useInvites();
  const activitiesQuery = useActivities();
  const updateTarget = useUpdateTarget();
  const updateCommission = useUpdateCommission();
  const setMemberActive = useSetMemberActive();
  const createInvite = useCreateInvite();
  const deleteInvite = useDeleteInvite();

  const [inviteForm, setInviteForm] = useState({ email: "", role: "member" as Role, target: 30 });
  const [inviteLink, setInviteLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [confirm, setConfirm] = useState<{ member: TeamMember; nextActive: boolean } | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const members = membersQuery.data ?? [];
  const invites = (invitesQuery.data ?? []).filter((invite) => !invite.accepted_at);
  const activities = activitiesQuery.data ?? [];

  if (!isAdmin) return null;

  const lastActivityFor = (userId: string) => {
    const rows = activities.filter((row) => row.user_id === userId);
    return rows.length > 0 ? rows[0]!.activity_date : null;
  };

  const submitInvite = async () => {
    setFormError(null);
    const email = inviteForm.email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setFormError(t("team.emailRequired"));
    if (members.some((member) => member.email.toLowerCase() === email)) {
      return setFormError(t("team.alreadyMember"));
    }
    try {
      const invite = await createInvite.mutateAsync({
        email,
        role: inviteForm.role,
        target: Math.max(0, Math.round(inviteForm.target)),
        createdBy: profile!.id,
      });
      setInviteLink(inviteUrl(invite.token));
      setCopied(false);
      setInviteForm({ email: "", role: "member", target: 30 });
      toast.success(t("team.inviteCreated"));
    } catch (caught) {
      setFormError(errorText(caught));
    }
  };

  const setRole = async (member: TeamMember, role: Role) => {
    try {
      await updateProfile(member.id, { role });
      await membersQuery.refetch();
      toast.success(t("common.saved"));
    } catch (caught) {
      toast.error(errorText(caught));
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader title={t("team.title")} subtitle={t("team.subtitle")} />

      <div className="grid gap-3 lg:grid-cols-[minmax(0,380px)_1fr]">
        <Card className="overflow-hidden">
          <CardHeader title={t("team.invite")} subtitle={t("team.inviteHint")} />
          <div className="space-y-3 px-4 py-4">
            <Field label={t("team.inviteEmail")} htmlFor="invite-email">
              <Input
                id="invite-email"
                type="email"
                inputMode="email"
                value={inviteForm.email}
                onChange={(event) => setInviteForm((current) => ({ ...current, email: event.target.value }))}
                placeholder="ami@studio.com"
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("team.inviteRole")} htmlFor="invite-role">
                <Select
                  id="invite-role"
                  value={inviteForm.role}
                  onChange={(event) => setInviteForm((current) => ({ ...current, role: event.target.value as Role }))}
                >
                  <option value="member">{t("team.roleMember")}</option>
                  <option value="admin">{t("team.roleAdmin")}</option>
                </Select>
              </Field>
              <Field label={t("team.inviteTarget")} htmlFor="invite-target">
                <Input
                  id="invite-target"
                  type="number"
                  min={0}
                  max={5000}
                  value={inviteForm.target}
                  onChange={(event) => setInviteForm((current) => ({ ...current, target: Number(event.target.value) }))}
                />
              </Field>
            </div>

            {formError ? (
              <p className="rounded-lg border border-danger/25 bg-danger/10 px-3 py-2 text-[11px] text-danger">{formError}</p>
            ) : null}

            <Button variant="primary" className="w-full" onClick={() => void submitInvite()} loading={createInvite.isPending}>
              <Mail className="size-3.5" />
              {t("team.createInvite")}
            </Button>

            {inviteLink ? (
              <div className="rounded-lg border border-brand-500/25 bg-brand-500/[0.06] p-3">
                <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-brand-300">
                  <Link2 className="size-3" />
                  {t("team.inviteLink")}
                </p>
                <p className="break-all rounded-md border border-line bg-canvas px-2 py-1.5 text-[10.5px] leading-relaxed text-muted">
                  {inviteLink}
                </p>
                <p className="mt-2 text-[10px] text-faint">
                  {t("team.inviteCode")} :{" "}
                  <span className="select-all font-mono text-[10px] text-muted">
                    {inviteLink.split("/invitation/")[1]}
                  </span>
                </p>
                <p className="mt-1 text-[10px] leading-relaxed text-faint">{t("team.fileHint")}</p>
                <Button
                  variant="secondary"
                  size="sm"
                  className="mt-2 w-full"
                  onClick={async () => {
                    const ok = await copyToClipboard(inviteLink);
                    setCopied(ok);
                    if (ok) toast.success(t("common.copied"));
                    else toast.error(t("messages.copyFailed"));
                  }}
                >
                  {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
                  {copied ? t("common.copied") : t("team.copyLink")}
                </Button>
              </div>
            ) : null}
          </div>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader title={t("team.members")} subtitle={`${members.length}`} />
          {membersQuery.isLoading ? (
            <div className="space-y-2 p-4">
              {[0, 1, 2].map((index) => (
                <Skeleton key={index} className="h-11 w-full" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-[12px]">
                <thead>
                  <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                    <th className="px-4 py-2 font-medium">{t("common.member")}</th>
                    <th className="px-2 py-2 font-medium">{t("settings.role")}</th>
                    <th className="px-2 py-2 font-medium">{t("team.editTarget")}</th>
                    <th className="px-2 py-2 font-medium">{t("sales.commission")}</th>
                    <th className="px-2 py-2 font-medium">{t("team.lastActivity")}</th>
                    <th className="px-2 py-2 font-medium">{t("common.status")}</th>
                    <th className="px-4 py-2 text-right font-medium">{t("common.actions")}</th>
                  </tr>
                </thead>
                <tbody>
                  {members.map((member) => {
                    const isSelf = member.id === profile?.id;
                    const last = lastActivityFor(member.id);
                    return (
                      <tr key={member.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                        <td className="px-4 py-2.5">
                          <p className="font-medium text-fg">
                            {member.display_name}
                            {isSelf ? <span className="ml-1.5 text-[10px] text-faint">({t("team.you")})</span> : null}
                          </p>
                          <p className="text-[10px] text-faint">{member.email}</p>
                          <p className="text-[10px] text-faint">
                            {t("team.memberSince", { date: formatDate(member.created_at, lang) })}
                          </p>
                        </td>
                        <td className="px-2 py-2.5">
                          {isSelf ? (
                            <Badge tone="brand">
                              <ShieldCheck className="size-3" />
                              {t("team.roleAdmin")}
                            </Badge>
                          ) : (
                            <Select
                              value={member.role}
                              onChange={(event) => void setRole(member, event.target.value as Role)}
                              className="h-7 max-w-[126px] text-[11px]"
                              aria-label={t("settings.role")}
                            >
                              <option value="member">{t("team.roleMember")}</option>
                              <option value="admin">{t("team.roleAdmin")}</option>
                            </Select>
                          )}
                        </td>
                        <td className="px-2 py-2.5">
                          <NumberCell
                            value={member.daily_dm_target}
                            max={5000}
                            ariaLabel={t("team.editTarget")}
                            onSave={async (value) => {
                              try {
                                await updateTarget.mutateAsync({ userId: member.id, target: value });
                                toast.success(t("team.targetUpdated"));
                              } catch (caught) {
                                toast.error(errorText(caught));
                              }
                            }}
                          />
                        </td>
                        <td className="px-2 py-2.5">
                          <NumberCell
                            value={member.commission_rate}
                            max={100}
                            suffix="%"
                            ariaLabel={t("sales.commission")}
                            onSave={async (value) => {
                              try {
                                await updateCommission.mutateAsync({ userId: member.id, rate: value });
                                toast.success(t("team.commissionUpdated"));
                              } catch (caught) {
                                toast.error(errorText(caught));
                              }
                            }}
                          />
                        </td>
                        <td className="px-2 py-2.5 text-muted">
                          {last ? (
                            <>
                              {formatDate(last, lang)}
                              {last === todayISO() ? <Badge tone="positive" className="ml-1.5">{t("common.today")}</Badge> : null}
                            </>
                          ) : (
                            t("team.neverConnected")
                          )}
                        </td>
                        <td className="px-2 py-2.5">
                          <Badge tone={member.is_active ? "positive" : "danger"} dot>
                            {member.is_active ? t("common.active") : t("common.inactive")}
                          </Badge>
                        </td>
                        <td className="px-4 py-2.5 text-right">
                          {isSelf ? (
                            <span className="text-[10px] text-faint">—</span>
                          ) : (
                            <Button
                              variant={member.is_active ? "danger" : "secondary"}
                              size="sm"
                              onClick={() => setConfirm({ member, nextActive: !member.is_active })}
                            >
                              <Power className="size-3" />
                              {member.is_active ? t("team.deactivate") : t("team.activate")}
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      <Card className="overflow-hidden">
        <CardHeader title={t("team.pendingInvites")} subtitle={`${invites.length}`} />
        {invitesQuery.isLoading ? (
          <div className="p-4">
            <Skeleton className="h-10 w-full" />
          </div>
        ) : invites.length === 0 ? (
          <EmptyState icon={<Mail className="size-4" />} title={t("team.noInvites")} />
        ) : (
          <ul className="divide-y divide-line">
            {invites.map((invite) => {
              const expired = new Date(invite.expires_at) < new Date();
              return (
                <li key={invite.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-[12px] font-medium text-fg">{invite.email}</p>
                    <p className="text-[10px] text-faint">
                      {expired ? t("team.expired") : t("team.expires", { date: formatDate(invite.expires_at, lang) })} ·{" "}
                      {invite.role === "admin" ? t("team.roleAdmin") : t("team.roleMember")} · {invite.daily_dm_target} DM
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={async () => {
                        const ok = await copyToClipboard(inviteUrl(invite.token));
                        if (ok) toast.success(t("common.copied"));
                        else toast.error(t("messages.copyFailed"));
                      }}
                    >
                      <Copy className="size-3" />
                      {t("team.copyLink")}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-danger/80 hover:text-danger"
                      onClick={async () => {
                        try {
                          await deleteInvite.mutateAsync(invite.id);
                          toast.success(t("team.inviteRevoked"));
                        } catch (caught) {
                          toast.error(errorText(caught));
                        }
                      }}
                    >
                      <X className="size-3" />
                      {t("team.cancelInvite")}
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      <ConfirmDialog
        open={Boolean(confirm)}
        title={confirm?.nextActive ? t("team.activateTitle") : t("team.deactivateTitle")}
        description={confirm?.nextActive ? t("team.activateBody") : t("team.deactivateBody")}
        confirmLabel={confirm?.nextActive ? t("team.activate") : t("team.deactivate")}
        cancelLabel={t("common.cancel")}
        destructive={!confirm?.nextActive}
        loading={setMemberActive.isPending}
        onCancel={() => setConfirm(null)}
        onConfirm={async () => {
          if (!confirm) return;
          try {
            await setMemberActive.mutateAsync({ userId: confirm.member.id, active: confirm.nextActive });
            toast.success(confirm.nextActive ? t("team.memberActivated") : t("team.memberDeactivated"));
          } catch (caught) {
            toast.error(errorText(caught));
          } finally {
            setConfirm(null);
          }
        }}
      />
    </div>
  );
}
