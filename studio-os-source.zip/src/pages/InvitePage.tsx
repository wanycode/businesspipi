import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { CheckCircle2, Loader2, ShieldAlert, UserPlus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { claimInvite } from "@/lib/api";
import { extractInviteToken } from "@/lib/utils";
import { Button, Field, Input } from "@/components/ui";

export default function InvitePage() {
  const { token: routeToken } = useParams<{ token: string }>();
  const { t } = useI18n();
  const { session, loading, reload } = useAuth();
  const navigate = useNavigate();
  const [state, setState] = useState<"idle" | "claiming" | "done" | "error">("idle");
  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState<string | null>(null);
  const started = useRef(false);

  const token = routeToken && extractInviteToken(routeToken) ? extractInviteToken(routeToken) : null;

  useEffect(() => {
    if (loading || !session || !token || started.current) return;
    started.current = true;
    setState("claiming");
    claimInvite(token)
      .then(async () => {
        await reload();
        setState("done");
        window.setTimeout(() => navigate("/", { replace: true }), 1200);
      })
      .catch(() => setState("error"));
  }, [loading, session, token, reload, navigate]);

  const next = encodeURIComponent(`/invitation/${token ?? ""}`);

  return (
    <div className="relative flex min-h-dvh items-center justify-center bg-canvas px-5">
      <div className="pointer-events-none absolute inset-0 surface-grain" aria-hidden />
      <div className="relative z-10 w-full max-w-[420px] rounded-xl border border-line bg-surface p-6 text-center">
        <div className="mx-auto mb-3 flex size-10 items-center justify-center rounded-xl border border-brand-500/25 bg-brand-500/10 text-brand-300">
          {state === "done" ? (
            <CheckCircle2 className="size-4" />
          ) : state === "error" ? (
            <ShieldAlert className="size-4" />
          ) : state === "claiming" ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <UserPlus className="size-4" />
          )}
        </div>

        <h1 className="text-sm font-semibold">
          {state === "error" ? t("auth.claimError") : t("auth.claimTitle")}
        </h1>
        <p className="mt-1.5 text-xs leading-relaxed text-muted">
          {state === "done" ? t("auth.claimSuccess") : t("auth.claimBody")}
        </p>

        {!session && !loading ? (
          <div className="mt-5 flex flex-col gap-2">
            <Button variant="primary" onClick={() => navigate(`/connexion?next=${next}`)}>
              {t("auth.signIn")}
            </Button>
            <Button variant="secondary" onClick={() => navigate(`/inscription?next=${next}`)}>
              {t("auth.signUp")}
            </Button>
          </div>
        ) : null}

        {!token ? (
          <form
            className="mt-5 space-y-2.5 text-left"
            onSubmit={(event) => {
              event.preventDefault();
              const extracted = extractInviteToken(code);
              if (!extracted) return setCodeError(t("auth.inviteCodeInvalid"));
              setCodeError(null);
              navigate(`/invitation/${extracted}`);
            }}
          >
            <Field label={t("auth.inviteCodeLabel")} htmlFor="invite-code" hint={t("common.optional")}>
              <Input
                id="invite-code"
                value={code}
                onChange={(event) => setCode(event.target.value)}
                placeholder="a1b2c3d4-…"
                autoCapitalize="none"
                spellCheck={false}
              />
            </Field>
            {codeError ? <p className="text-[11px] text-danger">{codeError}</p> : null}
            <Button type="submit" variant="secondary" className="w-full">
              {t("auth.activate")}
            </Button>
            <p className="text-[10px] leading-relaxed text-faint">{t("auth.inviteCodeHint")}</p>
          </form>
        ) : null}

        {state === "error" ? (
          <Link to="/" className="mt-4 inline-flex text-xs text-brand-400 hover:underline">
            {t("nav.overview")}
          </Link>
        ) : null}
      </div>
    </div>
  );
}
