import { useEffect, useState } from "react";
import { LogOut, ShieldCheck } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { usePricing, useStudioSettings, useUpdateProfile, useUpdateStudio } from "@/hooks/use-data";
import { supabase, isConfigured } from "@/lib/supabase";
import type { Lang } from "@/lib/utils";
import { formatDate } from "@/lib/utils";
import { Badge, Button, Card, CardHeader, Field, Input, PageHeader, Segmented, Skeleton } from "@/components/ui";
import { useToast } from "@/components/ui/toast";

export default function SettingsPage() {
  const { t, lang, setLang } = useI18n();
  const { profile, settings, isAdmin, signOut } = useAuth();
  const toast = useToast();
  const errorText = useErrorText();
  const updateProfile = useUpdateProfile();
  const studioQuery = useStudioSettings();
  const pricingQuery = usePricing();
  const updateStudio = useUpdateStudio();

  const [displayName, setDisplayName] = useState(profile?.display_name ?? "");
  const [password, setPassword] = useState("");
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [studio, setStudio] = useState({
    name: "",
    maintenance: 9.99,
    portfolio: "",
  });
  const [prices, setPrices] = useState<Record<string, number>>({});
  const [errors, setErrors] = useState<{ profile?: string; password?: string; studio?: string }>({});

  useEffect(() => {
    if (profile) setDisplayName(profile.display_name);
  }, [profile]);

  useEffect(() => {
    if (studioQuery.data) {
      setStudio({
        name: studioQuery.data.studio_name,
        maintenance: studioQuery.data.maintenance_price,
        portfolio: studioQuery.data.portfolio_url,
      });
    }
  }, [studioQuery.data]);

  useEffect(() => {
    if (pricingQuery.data) {
      setPrices(Object.fromEntries(pricingQuery.data.map((row) => [row.code, row.price])));
    }
  }, [pricingQuery.data]);

  const saveProfile = async () => {
    setErrors((current) => ({ ...current, profile: undefined }));
    if (!displayName.trim()) return setErrors((current) => ({ ...current, profile: t("errors.required") }));
    if (!profile) return;
    try {
      await updateProfile.mutateAsync({ userId: profile.id, displayName: displayName.trim() });
      toast.success(t("settings.profileSaved"));
    } catch (caught) {
      setErrors((current) => ({ ...current, profile: errorText(caught) }));
    }
  };

  const savePassword = async () => {
    setErrors((current) => ({ ...current, password: undefined }));
    if (password.length < 6) return setErrors((current) => ({ ...current, password: t("auth.weakPassword") }));
    setPasswordBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      setPassword("");
      toast.success(t("settings.passwordUpdated"));
    } catch (caught) {
      setErrors((current) => ({ ...current, password: errorText(caught) }));
    } finally {
      setPasswordBusy(false);
    }
  };

  const saveStudio = async () => {
    setErrors((current) => ({ ...current, studio: undefined }));
    if (!studio.name.trim()) return setErrors((current) => ({ ...current, studio: t("errors.required") }));
    if ([studio.maintenance, ...Object.values(prices)].some((value) => !Number.isFinite(value) || value < 0)) {
      return setErrors((current) => ({ ...current, studio: t("settings.invalidNumber") }));
    }
    try {
      await updateStudio.mutateAsync({
        studio_name: studio.name.trim(),
        maintenance_price: studio.maintenance,
        portfolio_url: studio.portfolio.trim(),
        prices: Object.entries(prices).map(([code, price]) => ({ code, price })),
      });
      toast.success(t("settings.studioSaved"));
    } catch (caught) {
      setErrors((current) => ({ ...current, studio: errorText(caught) }));
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader title={t("settings.title")} subtitle={t("settings.subtitle")} />

      <div className="grid gap-3 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <CardHeader title={t("settings.profile")} />
          <div className="space-y-3 px-4 py-4">
            <div className="flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-full border border-line-strong bg-surface-3 text-[12px] font-semibold text-muted">
                {profile?.display_name?.slice(0, 2).toUpperCase()}
              </span>
              <div>
                <p className="text-[13px] font-medium text-fg">{profile?.display_name}</p>
                <div className="mt-0.5 flex items-center gap-1.5">
                  {isAdmin ? (
                    <Badge tone="brand">
                      <ShieldCheck className="size-3" />
                      {t("common.admin")}
                    </Badge>
                  ) : (
                    <Badge tone="neutral">{t("common.member")}</Badge>
                  )}
                  <span className="text-[10px] text-faint">
                    {t("settings.memberSince", { date: formatDate(profile?.created_at ?? null, lang) })}
                  </span>
                </div>
              </div>
            </div>

            <Field label={t("settings.displayName")} htmlFor="s-name" error={errors.profile}>
              <Input id="s-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} />
            </Field>
            <Field label={t("settings.email")} htmlFor="s-email" hint={t("settings.emailLocked")}>
              <Input id="s-email" value={profile?.email ?? ""} readOnly disabled />
            </Field>
            <Field label={t("settings.dailyTarget")}>
              <Input value={settings?.daily_dm_target ?? 30} readOnly disabled />
            </Field>
            <div className="flex justify-end">
              <Button variant="primary" size="sm" onClick={() => void saveProfile()} loading={updateProfile.isPending}>
                {t("settings.saveProfile")}
              </Button>
            </div>
          </div>
        </Card>

        <div className="space-y-3">
          <Card className="overflow-hidden">
            <CardHeader title={t("settings.preferences")} />
            <div className="space-y-3 px-4 py-4">
              <div>
                <p className="mb-1.5 text-xs font-medium text-muted">{t("settings.interfaceLanguage")}</p>
                <Segmented
                  value={lang}
                  onChange={(value) => setLang(value as Lang)}
                  options={[
                    { value: "fr" as Lang, label: "Français" },
                    { value: "en" as Lang, label: "English" },
                  ]}
                />
                <p className="mt-1.5 text-[10px] text-faint">{t("settings.languageHint")}</p>
              </div>
            </div>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader title={t("settings.password")} />
            <div className="space-y-3 px-4 py-4">
              <Field label={t("settings.newPassword")} htmlFor="s-password" error={errors.password}>
                <Input
                  id="s-password"
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="••••••••"
                />
              </Field>
              <div className="flex justify-end">
                <Button variant="secondary" size="sm" onClick={() => void savePassword()} loading={passwordBusy}>
                  {t("settings.updatePassword")}
                </Button>
              </div>
            </div>
          </Card>

          <Card className="overflow-hidden">
            <CardHeader title={t("settings.session")} subtitle={t("settings.sessionHint")} />
            <div className="flex items-center justify-between px-4 py-4">
              <Badge tone={isConfigured ? "positive" : "danger"} dot>
                {isConfigured ? t("settings.database") : t("settings.databaseUnknown")}
              </Badge>
              <Button variant="danger" size="sm" onClick={() => void signOut()}>
                <LogOut className="size-3" />
                {t("common.logout")}
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {isAdmin ? (
        <Card className="overflow-hidden">
          <CardHeader title={t("settings.studio")} subtitle={t("settings.adminOnly")} />
          <div className="space-y-3 px-4 py-4">
            {studioQuery.isLoading || pricingQuery.isLoading ? (
              <Skeleton className="h-24 w-full" />
            ) : (
              <>
                <div className="grid gap-3 sm:grid-cols-3">
                  <Field label={t("settings.studioName")} htmlFor="st-name">
                    <Input id="st-name" value={studio.name} onChange={(event) => setStudio((current) => ({ ...current, name: event.target.value }))} />
                  </Field>
                  <Field label={t("settings.maintenancePrice")} htmlFor="st-maint" hint="€">
                    <Input
                      id="st-maint"
                      type="number"
                      inputMode="decimal"
                      min={0}
                      step="0.01"
                      value={studio.maintenance}
                      onChange={(event) => setStudio((current) => ({ ...current, maintenance: Number(event.target.value) }))}
                    />
                  </Field>
                  <Field label={t("settings.portfolioUrl")} htmlFor="st-url">
                    <Input id="st-url" value={studio.portfolio} onChange={(event) => setStudio((current) => ({ ...current, portfolio: event.target.value }))} />
                  </Field>
                </div>

                <div>
                  <p className="mb-1.5 text-xs font-medium text-muted">{t("settings.packagePrices")}</p>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {(pricingQuery.data ?? []).map((row) => (
                      <Field key={row.code} label={row.code} htmlFor={`price-${row.code}`} hint="€">
                        <Input
                          id={`price-${row.code}`}
                          type="number"
                          inputMode="decimal"
                          min={0}
                          step="0.01"
                          value={prices[row.code] ?? row.price}
                          onChange={(event) =>
                            setPrices((current) => ({ ...current, [row.code]: Number(event.target.value) }))
                          }
                        />
                      </Field>
                    ))}
                  </div>
                </div>

                {errors.studio ? <p className="text-[11px] text-danger">{errors.studio}</p> : null}

                <div className="flex items-center justify-between">
                  <p className="text-[10px] text-faint">{t("settings.version")}</p>
                  <Button variant="primary" size="sm" onClick={() => void saveStudio()} loading={updateStudio.isPending}>
                    {t("settings.saveStudio")}
                  </Button>
                </div>
              </>
            )}
          </div>
        </Card>
      ) : null}
    </div>
  );
}
