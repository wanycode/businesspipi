import { useMemo, useState } from "react";
import { Check, Copy, Languages, Pencil, Plus, RotateCcw, Search, Trash2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { useAddMessage, useDeleteMessage, useMessages, useResetMessage, useUpdateMessage } from "@/hooks/use-data";
import type { MessageTemplate } from "@/lib/types";
import { copyToClipboard, formatDate } from "@/lib/utils";
import {
  Badge,
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  Modal,
  PageHeader,
  Skeleton,
  Switch,
  Textarea,
} from "@/components/ui";
import { useToast } from "@/components/ui/toast";

export default function MessagesPage() {
  const { t, lang } = useI18n();
  const { isAdmin, profile } = useAuth();
  const toast = useToast();
  const errorText = useErrorText();
  const messagesQuery = useMessages();
  const updateMessage = useUpdateMessage();
  const resetMessage = useResetMessage();
  const addMessage = useAddMessage();
  const deleteMessage = useDeleteMessage();

  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [preview, setPreview] = useState<MessageTemplate | null>(null);
  const [editing, setEditing] = useState<MessageTemplate | null>(null);
  const [draft, setDraft] = useState("");
  const [confirmReset, setConfirmReset] = useState<MessageTemplate | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<MessageTemplate | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [newLang, setNewLang] = useState({ code: "", name: "", content: "", rtl: false });
  const [formError, setFormError] = useState<string | null>(null);

  const messages = messagesQuery.data ?? [];
  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return messages;
    return messages.filter(
      (item) => item.language_name.toLowerCase().includes(term) || item.language_code.toLowerCase().includes(term),
    );
  }, [messages, search]);

  const copy = async (message: MessageTemplate) => {
    const ok = await copyToClipboard(message.message_content);
    if (ok) {
      setCopiedId(message.id);
      toast.success(t("messages.copied"));
      window.setTimeout(() => setCopiedId((current) => (current === message.id ? null : current)), 2200);
    } else {
      toast.error(t("messages.copyFailed"));
    }
  };

  const openEdit = (message: MessageTemplate) => {
    setEditing(message);
    setDraft(message.message_content);
    setFormError(null);
  };

  const saveEdit = async () => {
    if (!editing || !profile) return;
    if (draft.trim().length < 20) return setFormError(t("errors.required"));
    try {
      await updateMessage.mutateAsync({ id: editing.id, content: draft, updatedBy: profile.id });
      toast.success(t("messages.saved"));
      setEditing(null);
    } catch (caught) {
      setFormError(errorText(caught));
    }
  };

  const submitNew = async () => {
    if (!profile) return;
    const code = newLang.code.trim().toLowerCase();
    if (!/^[a-z]{2,5}$/.test(code)) return setFormError(t("errors.required"));
    if (!newLang.name.trim()) return setFormError(t("errors.required"));
    if (newLang.content.trim().length < 20) return setFormError(t("errors.required"));
    try {
      await addMessage.mutateAsync({
        language_code: code,
        language_name: newLang.name.trim(),
        message_content: newLang.content,
        is_rtl: newLang.rtl,
        sort_order: messages.length + 1,
        updated_by: profile.id,
      });
      toast.success(t("messages.added"));
      setAddOpen(false);
      setNewLang({ code: "", name: "", content: "", rtl: false });
      setFormError(null);
    } catch (caught) {
      setFormError(errorText(caught));
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title={t("messages.title")}
        subtitle={t("messages.subtitle")}
        actions={
          isAdmin ? (
            <Button variant="secondary" onClick={() => setAddOpen(true)}>
              <Plus className="size-3.5" />
              {t("messages.addLanguage")}
            </Button>
          ) : null
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-full max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-faint" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder={t("messages.searchPlaceholder")}
            className="pl-8"
            aria-label={t("common.search")}
          />
        </div>
        <Badge tone="neutral">
          <Languages className="size-3" />
          {messages.length}
        </Badge>
        {!isAdmin ? <span className="text-[11px] text-faint">{t("messages.adminHint")}</span> : null}
      </div>

      {messagesQuery.isLoading ? (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((index) => (
            <Skeleton key={index} className="h-56 w-full rounded-xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Languages className="size-4" />}
            title={messages.length === 0 ? t("messages.emptyTitle") : t("common.noResults")}
            description={messages.length === 0 ? t("messages.emptyBody") : undefined}
            action={
              isAdmin && messages.length === 0 ? (
                <Button size="sm" variant="primary" onClick={() => setAddOpen(true)}>
                  {t("messages.addLanguage")}
                </Button>
              ) : null
            }
          />
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((message) => (
            <Card key={message.id} className="flex flex-col overflow-hidden transition-colors hover:border-line-strong">
              <div className="flex items-center justify-between gap-2 border-b border-line px-3.5 py-2.5">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="flex size-6 items-center justify-center rounded-md border border-line-strong bg-surface-2 text-[9px] font-bold uppercase text-muted">
                    {message.language_code}
                  </span>
                  <p className="truncate text-[13px] font-medium text-fg">{message.language_name}</p>
                  {message.language_code === "en" ? (
                    <Badge tone="brand" className="shrink-0 text-[9px]">
                      {t("messages.sourceOfTruth")}
                    </Badge>
                  ) : null}
                </div>
                <span className="shrink-0 text-[10px] text-faint">{t("messages.characters", { n: message.message_content.length })}</span>
              </div>

              <button
                type="button"
                onClick={() => setPreview(message)}
                className="group relative flex-1 px-3.5 py-3 text-left"
              >
                <p
                  dir={message.is_rtl ? "rtl" : "ltr"}
                  className="max-h-[132px] overflow-hidden whitespace-pre-wrap text-[11.5px] leading-relaxed text-muted"
                >
                  {message.message_content}
                </p>
                <div className="pointer-events-none absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-surface to-transparent" />
                <span className="mt-2 inline-block text-[11px] font-medium text-brand-400 group-hover:underline">
                  {t("messages.preview")}
                </span>
              </button>

              <div className="flex items-center justify-between gap-2 border-t border-line px-3.5 py-2.5">
                <p className="truncate text-[10px] text-faint">{t("messages.updated", { date: formatDate(message.updated_at, lang) })}</p>
                <div className="flex shrink-0 items-center gap-1">
                  {isAdmin ? (
                    <>
                      <button
                        type="button"
                        onClick={() => openEdit(message)}
                        className="rounded-md p-1.5 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                        aria-label={t("messages.edit")}
                      >
                        <Pencil className="size-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmReset(message)}
                        className="rounded-md p-1.5 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                        aria-label={t("messages.resetDefault")}
                      >
                        <RotateCcw className="size-3.5" />
                      </button>
                    </>
                  ) : null}
                  <Button
                    variant={copiedId === message.id ? "secondary" : "primary"}
                    size="sm"
                    onClick={() => void copy(message)}
                  >
                    {copiedId === message.id ? <Check className="size-3" /> : <Copy className="size-3" />}
                    {copiedId === message.id ? t("common.copied") : t("messages.copy")}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Aperçu complet */}
      <Modal
        open={Boolean(preview)}
        onClose={() => setPreview(null)}
        title={preview?.language_name ?? ""}
        description={preview ? t("messages.characters", { n: preview.message_content.length }) : undefined}
        size="lg"
        footer={
          preview ? (
            <>
              {isAdmin ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    openEdit(preview);
                    setPreview(null);
                  }}
                >
                  <Pencil className="size-3" />
                  {t("messages.edit")}
                </Button>
              ) : null}
              <Button variant="primary" size="sm" onClick={() => void copy(preview)}>
                <Copy className="size-3" />
                {t("messages.copy")}
              </Button>
            </>
          ) : null
        }
      >
        {preview ? (
          <div
            dir={preview.is_rtl ? "rtl" : "ltr"}
            className="whitespace-pre-wrap rounded-lg border border-line bg-surface-2 px-3.5 py-3 text-[12.5px] leading-relaxed text-fg"
          >
            {preview.message_content}
          </div>
        ) : null}
        {preview?.is_rtl ? <p className="mt-2 text-[10px] text-faint">{t("messages.rtl")}</p> : null}
      </Modal>

      {/* Édition */}
      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={t("messages.edit")}
        description={editing ? editing.language_name : undefined}
        size="lg"
        footer={
          <>
            {editing && messages.length > 1 ? (
              <Button
                variant="ghost"
                size="sm"
                className="mr-auto text-danger/80 hover:text-danger"
                onClick={() => {
                  setConfirmDelete(editing);
                  setEditing(null);
                }}
              >
                <Trash2 className="size-3" />
                {t("common.delete")}
              </Button>
            ) : null}
            <Button variant="ghost" size="sm" onClick={() => setEditing(null)}>
              {t("common.cancel")}
            </Button>
            <Button variant="primary" size="sm" onClick={() => void saveEdit()} loading={updateMessage.isPending}>
              {t("common.save")}
            </Button>
          </>
        }
      >
        <Textarea
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          rows={16}
          dir={editing?.is_rtl ? "rtl" : "ltr"}
          className="min-h-[320px] font-normal leading-relaxed"
        />
        {formError ? <p className="mt-2 text-[11px] text-danger">{formError}</p> : null}
      </Modal>

      {/* Nouvelle langue */}
      <Modal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title={t("messages.newLanguage")}
        description={t("messages.addHint")}
        size="md"
        footer={
          <>
            <Button variant="ghost" size="sm" onClick={() => setAddOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button variant="primary" size="sm" onClick={() => void submitNew()} loading={addMessage.isPending}>
              {t("common.add")}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label={t("messages.languageCode")} htmlFor="nl-code">
              <Input
                id="nl-code"
                value={newLang.code}
                onChange={(event) => setNewLang((current) => ({ ...current, code: event.target.value }))}
                placeholder="sv"
                maxLength={5}
              />
            </Field>
            <Field label={t("messages.languageName")} htmlFor="nl-name">
              <Input
                id="nl-name"
                value={newLang.name}
                onChange={(event) => setNewLang((current) => ({ ...current, name: event.target.value }))}
                placeholder="Svenska"
              />
            </Field>
          </div>
          <Field label={t("messages.content")} htmlFor="nl-content">
            <Textarea
              id="nl-content"
              rows={10}
              value={newLang.content}
              onChange={(event) => setNewLang((current) => ({ ...current, content: event.target.value }))}
              placeholder={t("messages.placeholderExample")}
            />
          </Field>
          <Switch
            checked={newLang.rtl}
            onChange={(value) => setNewLang((current) => ({ ...current, rtl: value }))}
            label={t("messages.rtl")}
          />
          {formError ? <p className="text-[11px] text-danger">{formError}</p> : null}
        </div>
      </Modal>

      <ConfirmDialog
        open={Boolean(confirmReset)}
        title={t("messages.resetTitle")}
        description={t("messages.resetBody")}
        confirmLabel={t("messages.resetDefault")}
        cancelLabel={t("common.cancel")}
        loading={resetMessage.isPending}
        onCancel={() => setConfirmReset(null)}
        onConfirm={async () => {
          if (!confirmReset || !profile) return;
          try {
            await resetMessage.mutateAsync({ id: confirmReset.id, updatedBy: profile.id });
            toast.success(t("messages.resetDone"));
          } catch (caught) {
            toast.error(errorText(caught));
          } finally {
            setConfirmReset(null);
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(confirmDelete)}
        title={t("messages.deleteTitle")}
        description={t("messages.deleteBody")}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        destructive
        loading={deleteMessage.isPending}
        onCancel={() => setConfirmDelete(null)}
        onConfirm={async () => {
          if (!confirmDelete) return;
          try {
            await deleteMessage.mutateAsync(confirmDelete.id);
            toast.success(t("common.saved"));
          } catch (caught) {
            toast.error(errorText(caught));
          } finally {
            setConfirmDelete(null);
          }
        }}
      />
    </div>
  );
}
