import { useMemo, useState } from "react";
import { addDays } from "date-fns";
import { CalendarClock, Pencil, Trash2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useActivities, useDeleteActivity } from "@/hooks/use-data";
import { dailySeries, totals } from "@/lib/stats";
import { computeStreak, formatDate, formatDayLabel, toISODate, todayISO } from "@/lib/utils";
import { ActivityForm } from "@/components/activity-form";
import { ChartCard, CHART_COLORS, MultiLineChart } from "@/components/charts";
import { Card, CardHeader, ConfirmDialog, EmptyState, Modal, PageHeader, Skeleton } from "@/components/ui";
import { Stat } from "@/components/shared";
import { useToast } from "@/components/ui/toast";

export default function ActivityPage() {
  const { profile, isAdmin } = useAuth();
  const { t, lang } = useI18n();
  const toast = useToast();
  const activitiesQuery = useActivities();
  const deleteActivity = useDeleteActivity();
  const [editing, setEditing] = useState<string | null>(null);
  const [confirming, setConfirming] = useState<string | null>(null);

  const today = todayISO();
  const activities = activitiesQuery.data ?? [];
  const mine = useMemo(
    () => activities.filter((row) => row.user_id === profile?.id),
    [activities, profile],
  );

  const weekFrom = toISODate(addDays(new Date(), -6));
  const monthFrom = toISODate(addDays(new Date(), -29));
  const week = totals(mine.filter((row) => row.activity_date >= weekFrom));
  const month = totals(mine.filter((row) => row.activity_date >= monthFrom));
  const streak = computeStreak(mine.map((row) => row.activity_date));

  const series = useMemo(
    () =>
      dailySeries(mine, monthFrom, today).map((row) => ({
        label: formatDayLabel(row.date, lang),
        dms: row.dms,
        replies: row.replies,
        interested: row.interested,
      })),
    [mine, monthFrom, today, lang],
  );

  const history = mine.slice().sort((a, b) => (a.activity_date < b.activity_date ? 1 : -1));

  return (
    <div className="space-y-4">
      <PageHeader title={t("nav.myActivity")} subtitle={t("dash.historyHint")} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label={t("dash.dmsToday")} value={mine.find((row) => row.activity_date === today)?.dms_sent ?? 0} />
        <Stat label={t("dash.last7")} value={week.dms} hint={`${week.replies} ${t("overview.replies").toLowerCase()}`} />
        <Stat label={t("dash.last30")} value={month.dms} hint={`${month.interested} ${t("overview.interested").toLowerCase()}`} tone="positive" />
        <Stat label={t("dash.streak")} value={t("dash.streakUnit", { n: streak })} />
      </div>

      <div className="grid gap-3 lg:grid-cols-[minmax(0,380px)_1fr]">
        <Card className="overflow-hidden">
          <CardHeader title={t("dash.logToday")} subtitle={t("dash.activityFormHint")} />
          <div className="px-4 py-4">
            {profile ? (
              <ActivityForm key={profile.id} userId={profile.id} activities={activities} />
            ) : (
              <Skeleton className="h-40 w-full" />
            )}
          </div>
        </Card>

        <ChartCard title={t("dash.last30")} subtitle={t("overview.chartFunnel")} empty={series.every((row) => row.dms === 0)} height={286}>
          <MultiLineChart
            data={series}
            series={[
              { key: "dms", name: t("overview.dms"), color: CHART_COLORS.brand },
              { key: "replies", name: t("overview.replies"), color: CHART_COLORS.info },
              { key: "interested", name: t("overview.interested"), color: CHART_COLORS.positive },
            ]}
          />
        </ChartCard>
      </div>

      <Card className="overflow-hidden">
        <CardHeader title={t("dash.history")} subtitle={`${history.length} ${t("common.total").toLowerCase()}`} />
        {activitiesQuery.isLoading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3].map((index) => (
              <Skeleton key={index} className="h-9 w-full" />
            ))}
          </div>
        ) : history.length === 0 ? (
          <EmptyState
            icon={<CalendarClock className="size-4" />}
            title={t("dash.noHistory")}
            description={t("dash.noHistoryBody")}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-[12px]">
              <thead>
                <tr className="border-b border-line text-[10px] uppercase tracking-wide text-faint">
                  <th className="px-4 py-2 font-medium">{t("common.date")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.dmsShort")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.repliesReceived")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.interested")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.followupsSent")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.meetingsBooked")}</th>
                  <th className="px-2 py-2 text-right font-medium">{t("dash.salesClosed")}</th>
                  <th className="px-4 py-2 font-medium">{t("common.notes")}</th>
                  <th className="px-4 py-2 text-right font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {history.map((row) => (
                  <tr key={row.id} className="border-b border-line/60 last:border-0 hover:bg-surface-2/40">
                    <td className="px-4 py-2 font-medium text-fg">{formatDate(row.activity_date, lang)}</td>
                    <td className="num px-2 py-2 text-right font-medium">{row.dms_sent}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.replies_received}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.interested_prospects}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.followups_sent}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.meetings_booked}</td>
                    <td className="num px-2 py-2 text-right text-muted">{row.sales_closed}</td>
                    <td className="max-w-[220px] truncate px-4 py-2 text-muted">{row.notes ?? "—"}</td>
                    <td className="px-4 py-2">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => setEditing(row.activity_date)}
                          className="rounded-md p-1 text-faint transition-colors hover:bg-surface-3 hover:text-fg"
                          aria-label={t("common.edit")}
                        >
                          <Pencil className="size-3" />
                        </button>
                        {isAdmin ? (
                          <button
                            type="button"
                            onClick={() => setConfirming(row.id)}
                            className="rounded-md p-1 text-faint transition-colors hover:bg-danger/15 hover:text-danger"
                            aria-label={t("common.delete")}
                          >
                            <Trash2 className="size-3" />
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={t("dash.activityForm", {
          date: editing
            ? new Intl.DateTimeFormat(lang === "fr" ? "fr-FR" : "en-GB", { day: "numeric", month: "long" })
                .format(new Date(`${editing}T12:00:00`))
            : "",
        })}
        description={t("dash.activityFormHint")}
      >
        {profile && editing ? (
          <ActivityForm
            key={editing}
            userId={profile.id}
            activities={activities}
            initialDate={editing}
            compact
            onSaved={() => setEditing(null)}
          />
        ) : null}
      </Modal>

      <ConfirmDialog
        open={Boolean(confirming)}
        title={t("common.confirmTitle")}
        description={t("dash.activityFormHint")}
        confirmLabel={t("common.delete")}
        cancelLabel={t("common.cancel")}
        destructive
        loading={deleteActivity.isPending}
        onCancel={() => setConfirming(null)}
        onConfirm={async () => {
          if (!confirming) return;
          try {
            await deleteActivity.mutateAsync(confirming);
            toast.success(t("common.saved"));
          } catch {
            toast.error(t("errors.saveFailed"));
          } finally {
            setConfirming(null);
          }
        }}
      />

    </div>
  );
}
