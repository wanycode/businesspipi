import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate, useSearchParams } from "react-router-dom";
import { ArrowRight, Loader2, Mail } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useI18n } from "@/lib/i18n";
import { useErrorText } from "@/lib/errors";
import { Button, Field, Input } from "@/components/ui";
import { cn } from "@/lib/utils";

export default function AuthPage({ mode }: { mode: "signin" | "signup" }) {
  const { t, lang, setLang } = useI18n();
  const { signIn, signUp, session, profile } = useAuth();
  const errorText = useErrorText();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = params.get("next") ?? "/";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  if (session && profile?.is_active) return <Navigate to={next} replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);

    if (!email.trim()) return setError(t("auth.emailRequired"));
    if (!password) return setError(t("auth.passwordRequired"));
    if (mode === "signup" && password !== confirm) return setError(t("auth.passwordMismatch"));

    setBusy(true);
    try {
      if (mode === "signin") {
        await signIn(email, password);
        navigate(next, { replace: true });
      } else {
        const result = await signUp({ email, password, displayName: displayName || email.split("@")[0]! });
        if (result.needsConfirmation) setSent(true);
        else navigate(next, { replace: true });
      }
    } catch (caught) {
      setError(errorText(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative flex min-h-dvh flex-col bg-canvas">
      <div className="pointer-events-none absolute inset-0 surface-grain" aria-hidden />
      <header className="relative z-10 flex items-center justify-between px-5 py-4 sm:px-8">
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-brand-500 text-[13px] font-bold text-white">
            S
          </div>
          <span className="text-[13px] font-semibold tracking-tight">{t("app.name")}</span>
        </div>
        <div className="inline-flex items-center rounded-md border border-line bg-surface-2 p-0.5">
          {(["fr", "en"] as const).map((code) => (
            <button
              key={code}
              type="button"
              onClick={() => setLang(code)}
              className={cn(
                "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase transition-colors",
                lang === code ? "bg-surface-3 text-fg" : "text-faint hover:text-muted",
              )}
            >
              {code}
            </button>
          ))}
        </div>
      </header>

      <div className="relative z-10 flex flex-1 items-center justify-center px-5 pb-16 pt-4">
        <div className="w-full max-w-[368px] animate-fade-up">
          {sent ? (
            <div className="rounded-xl border border-line bg-surface p-6 text-center">
              <div className="mx-auto mb-3 flex size-10 items-center justify-center rounded-xl border border-brand-500/25 bg-brand-500/10 text-brand-300">
                <Mail className="size-4" />
              </div>
              <h1 className="text-sm font-semibold">{t("auth.checkEmail")}</h1>
              <p className="mt-1.5 text-xs leading-relaxed text-muted">{t("auth.checkEmailBody")}</p>
              <Link
                to="/connexion"
                className="mt-4 inline-flex text-xs font-medium text-brand-400 hover:underline"
              >
                {t("auth.signIn")}
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h1 className="text-xl font-semibold tracking-tight">
                  {mode === "signin" ? t("auth.welcomeBack") : t("auth.signUp")}
                </h1>
                <p className="mt-1 text-[13px] text-muted">
                  {mode === "signin" ? t("auth.signInSubtitle") : t("auth.signUpSubtitle")}
                </p>
              </div>

              <form onSubmit={submit} className="space-y-3.5" noValidate>
                {mode === "signup" ? (
                  <Field label={t("auth.displayName")} htmlFor="displayName" hint={t("common.optional")}>
                    <Input
                      id="displayName"
                      value={displayName}
                      onChange={(event) => setDisplayName(event.target.value)}
                      autoComplete="name"
                      placeholder="Alex"
                    />
                  </Field>
                ) : null}

                <Field label={t("common.email")} htmlFor="email">
                  <Input
                    id="email"
                    type="email"
                    inputMode="email"
                    autoComplete="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="toi@studio.com"
                    required
                  />
                </Field>

                <Field label={t("auth.password")} htmlFor="password">
                  <Input
                    id="password"
                    type="password"
                    autoComplete={mode === "signin" ? "current-password" : "new-password"}
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    placeholder="••••••••"
                    required
                  />
                </Field>

                {mode === "signup" ? (
                  <Field label={t("auth.confirmPassword")} htmlFor="confirm">
                    <Input
                      id="confirm"
                      type="password"
                      autoComplete="new-password"
                      value={confirm}
                      onChange={(event) => setConfirm(event.target.value)}
                      placeholder="••••••••"
                      required
                    />
                  </Field>
                ) : null}

                {error ? (
                  <p className="rounded-lg border border-danger/25 bg-danger/10 px-3 py-2 text-[12px] text-danger">
                    {error}
                  </p>
                ) : null}

                <Button type="submit" variant="primary" className="h-10 w-full" disabled={busy}>
                  {busy ? <Loader2 className="size-4 animate-spin" /> : null}
                  {mode === "signin" ? t("auth.signIn") : t("auth.signUp")}
                  {!busy ? <ArrowRight className="size-3.5 opacity-70" /> : null}
                </Button>
              </form>

              <p className="mt-4 text-center text-xs text-muted">
                {mode === "signin" ? t("auth.noAccount") : t("auth.hasAccount")}{" "}
                <Link
                  to={mode === "signin" ? "/inscription" : "/connexion"}
                  className="font-medium text-brand-400 hover:underline"
                >
                  {mode === "signin" ? t("auth.signUp") : t("auth.signIn")}
                </Link>
              </p>

              {mode === "signup" ? (
                <p className="mt-4 rounded-lg border border-line bg-surface/60 px-3 py-2 text-[11px] leading-relaxed text-faint">
                  {t("auth.firstAccountNote")}
                </p>
              ) : null}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
