import { defineConfig, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath, URL } from "node:url";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

const projectRoot = fileURLToPath(new URL(".", import.meta.url));

/**
 * Sert index.html tel quel (sans transformation Vite) : l'aperçu en dev montre
 * exactement le fichier livré, ouvrable par double-clic.
 */
function serveStandaloneFile(): Plugin {
  return {
    name: "serve-standalone-file",
    apply: "serve",
    configureServer(server) {
      server.middlewares.use((request, response, next) => {
        const path = (request.url ?? "").split("?")[0];
        if (path !== "/" && path !== "/index.html") return next();
        const file = join(projectRoot, "index.html");
        if (!existsSync(file)) return next();
        response.setHeader("Content-Type", "text/html; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");
        response.end(readFileSync(file));
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  const standalone = mode === "standalone";

  return {
    plugins: [react(), tailwindcss(), serveStandaloneFile()],
    // En mode fichier unique, tous les chemins doivent être relatifs.
    base: standalone ? "./" : "/",
    resolve: {
      alias: {
        "@": fileURLToPath(new URL("./src", import.meta.url)),
      },
    },
    server: {
      port: 5199,
      strictPort: false,
    },
    build: {
      outDir: standalone ? "dist-standalone" : "dist",
      // Le fichier unique doit tout contenir : JS, CSS et polices en data URI.
      assetsInlineLimit: standalone ? 100_000_000 : 4096,
      cssCodeSplit: !standalone,
      rollupOptions: {
        input: standalone ? "app.html" : undefined,
        output: standalone
          ? { inlineDynamicImports: true, manualChunks: undefined }
          : {
              manualChunks: {
                react: ["react", "react-dom", "react-router-dom"],
                charts: ["recharts"],
                supabase: ["@supabase/supabase-js"],
              },
            },
      },
      chunkSizeWarningLimit: standalone ? 4000 : 500,
    },
  };
});
